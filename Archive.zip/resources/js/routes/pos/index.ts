import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import payment from './payment'
/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
export const terminal = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terminal.url(options),
    method: 'get',
})

terminal.definition = {
    methods: ["get","head"],
    url: '/pos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
terminal.url = (options?: RouteQueryOptions) => {
    return terminal.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
terminal.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terminal.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
terminal.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: terminal.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
const terminalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: terminal.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
terminalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: terminal.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
terminalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: terminal.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

terminal.form = terminalForm

/**
* @see \App\Http\Controllers\PosController::store
* @see app/Http/Controllers/PosController.php:365
* @route '/pos/store'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pos/store',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PosController::store
* @see app/Http/Controllers/PosController.php:365
* @route '/pos/store'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::store
* @see app/Http/Controllers/PosController.php:365
* @route '/pos/store'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::store
* @see app/Http/Controllers/PosController.php:365
* @route '/pos/store'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::store
* @see app/Http/Controllers/PosController.php:365
* @route '/pos/store'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\PosController::search
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
export const search = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

search.definition = {
    methods: ["get","head"],
    url: '/pos/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::search
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
search.url = (options?: RouteQueryOptions) => {
    return search.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::search
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
search.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::search
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
search.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::search
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
const searchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::search
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
searchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::search
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
searchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

search.form = searchForm

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
export const searchCustomers = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchCustomers.url(options),
    method: 'get',
})

searchCustomers.definition = {
    methods: ["get","head"],
    url: '/pos/search-customers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
searchCustomers.url = (options?: RouteQueryOptions) => {
    return searchCustomers.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
searchCustomers.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchCustomers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
searchCustomers.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: searchCustomers.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
const searchCustomersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchCustomers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
searchCustomersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchCustomers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
searchCustomersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchCustomers.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

searchCustomers.form = searchCustomersForm

/**
* @see \App\Http\Controllers\PosController::quickCustomer
* @see app/Http/Controllers/PosController.php:289
* @route '/pos/quick-customer'
*/
export const quickCustomer = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: quickCustomer.url(options),
    method: 'post',
})

quickCustomer.definition = {
    methods: ["post"],
    url: '/pos/quick-customer',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PosController::quickCustomer
* @see app/Http/Controllers/PosController.php:289
* @route '/pos/quick-customer'
*/
quickCustomer.url = (options?: RouteQueryOptions) => {
    return quickCustomer.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::quickCustomer
* @see app/Http/Controllers/PosController.php:289
* @route '/pos/quick-customer'
*/
quickCustomer.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: quickCustomer.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::quickCustomer
* @see app/Http/Controllers/PosController.php:289
* @route '/pos/quick-customer'
*/
const quickCustomerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: quickCustomer.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::quickCustomer
* @see app/Http/Controllers/PosController.php:289
* @route '/pos/quick-customer'
*/
quickCustomerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: quickCustomer.url(options),
    method: 'post',
})

quickCustomer.form = quickCustomerForm

/**
* @see \App\Http\Controllers\PosController::find
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
export const find = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: find.url(args, options),
    method: 'get',
})

find.definition = {
    methods: ["get","head"],
    url: '/pos/find/{identifier}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::find
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
find.url = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { identifier: args }
    }

    if (Array.isArray(args)) {
        args = {
            identifier: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        identifier: args.identifier,
    }

    return find.definition.url
            .replace('{identifier}', parsedArgs.identifier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::find
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
find.get = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: find.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::find
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
find.head = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: find.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::find
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
const findForm = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: find.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::find
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
findForm.get = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: find.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::find
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
findForm.head = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: find.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

find.form = findForm

/**
* @see \App\Http\Controllers\PosController::print
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
export const print = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/pos/print/{invoice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::print
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
print.url = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

    if (Array.isArray(args)) {
        args = {
            invoice: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        invoice: args.invoice,
    }

    return print.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::print
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
print.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::print
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
print.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::print
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
const printForm = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::print
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
printForm.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::print
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
printForm.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

print.form = printForm

/**
* @see \App\Http\Controllers\PosController::returnMethod
* @see app/Http/Controllers/PosController.php:694
* @route '/pos/return'
*/
export const returnMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: returnMethod.url(options),
    method: 'post',
})

returnMethod.definition = {
    methods: ["post"],
    url: '/pos/return',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PosController::returnMethod
* @see app/Http/Controllers/PosController.php:694
* @route '/pos/return'
*/
returnMethod.url = (options?: RouteQueryOptions) => {
    return returnMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::returnMethod
* @see app/Http/Controllers/PosController.php:694
* @route '/pos/return'
*/
returnMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: returnMethod.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::returnMethod
* @see app/Http/Controllers/PosController.php:694
* @route '/pos/return'
*/
const returnMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: returnMethod.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::returnMethod
* @see app/Http/Controllers/PosController.php:694
* @route '/pos/return'
*/
returnMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: returnMethod.url(options),
    method: 'post',
})

returnMethod.form = returnMethodForm

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
export const history = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/sales-history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
history.url = (options?: RouteQueryOptions) => {
    return history.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
history.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
history.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
const historyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
historyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
historyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

history.form = historyForm

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
export const show = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/pos/sale/{invoice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
show.url = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

    if (Array.isArray(args)) {
        args = {
            invoice: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        invoice: args.invoice,
    }

    return show.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
show.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
show.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
const showForm = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
showForm.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
showForm.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\PosController::destroy
* @see app/Http/Controllers/PosController.php:907
* @route '/pos/sale/{id}'
*/
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/pos/sale/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PosController::destroy
* @see app/Http/Controllers/PosController.php:907
* @route '/pos/sale/{id}'
*/
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::destroy
* @see app/Http/Controllers/PosController.php:907
* @route '/pos/sale/{id}'
*/
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\PosController::destroy
* @see app/Http/Controllers/PosController.php:907
* @route '/pos/sale/{id}'
*/
const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::destroy
* @see app/Http/Controllers/PosController.php:907
* @route '/pos/sale/{id}'
*/
destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
export const returns = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: returns.url(options),
    method: 'get',
})

returns.definition = {
    methods: ["get","head"],
    url: '/returns',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
returns.url = (options?: RouteQueryOptions) => {
    return returns.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
returns.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: returns.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
returns.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: returns.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
const returnsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: returns.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
returnsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: returns.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
returnsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: returns.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

returns.form = returnsForm

const pos = {
    terminal: Object.assign(terminal, terminal),
    store: Object.assign(store, store),
    search: Object.assign(search, search),
    searchCustomers: Object.assign(searchCustomers, searchCustomers),
    quickCustomer: Object.assign(quickCustomer, quickCustomer),
    find: Object.assign(find, find),
    print: Object.assign(print, print),
    return: Object.assign(returnMethod, returnMethod),
    history: Object.assign(history, history),
    show: Object.assign(show, show),
    payment: Object.assign(payment, payment),
    destroy: Object.assign(destroy, destroy),
    returns: Object.assign(returns, returns),
}

export default pos