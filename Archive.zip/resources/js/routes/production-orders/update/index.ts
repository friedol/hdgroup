import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ProductionOrderController::view
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
export const view = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: view.url(args, options),
    method: 'put',
})

view.definition = {
    methods: ["put"],
    url: '/production-orders/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::view
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
view.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return view.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::view
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
view.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: view.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::view
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
const viewForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: view.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::view
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
viewForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: view.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

view.form = viewForm

const update = {
    view: Object.assign(view, view),
}

export default update