import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CartController::product
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
export const product = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product.url(options),
    method: 'get',
})

product.definition = {
    methods: ["get","head"],
    url: '/product/all',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::product
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
product.url = (options?: RouteQueryOptions) => {
    return product.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::product
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
product.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::product
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
product.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: product.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::product
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
const productForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::product
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
productForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::product
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
productForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

product.form = productForm

const visit = {
    product: Object.assign(product, product),
}

export default visit