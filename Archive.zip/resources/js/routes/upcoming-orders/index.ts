import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\UpcomingOrderController::index
* @see app/Http/Controllers/UpcomingOrderController.php:25
* @route '/upcoming-orders'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/upcoming-orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UpcomingOrderController::index
* @see app/Http/Controllers/UpcomingOrderController.php:25
* @route '/upcoming-orders'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingOrderController::index
* @see app/Http/Controllers/UpcomingOrderController.php:25
* @route '/upcoming-orders'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::index
* @see app/Http/Controllers/UpcomingOrderController.php:25
* @route '/upcoming-orders'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::index
* @see app/Http/Controllers/UpcomingOrderController.php:25
* @route '/upcoming-orders'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::index
* @see app/Http/Controllers/UpcomingOrderController.php:25
* @route '/upcoming-orders'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::index
* @see app/Http/Controllers/UpcomingOrderController.php:25
* @route '/upcoming-orders'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\UpcomingOrderController::create
* @see app/Http/Controllers/UpcomingOrderController.php:38
* @route '/upcoming-orders/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/upcoming-orders/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UpcomingOrderController::create
* @see app/Http/Controllers/UpcomingOrderController.php:38
* @route '/upcoming-orders/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingOrderController::create
* @see app/Http/Controllers/UpcomingOrderController.php:38
* @route '/upcoming-orders/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::create
* @see app/Http/Controllers/UpcomingOrderController.php:38
* @route '/upcoming-orders/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::create
* @see app/Http/Controllers/UpcomingOrderController.php:38
* @route '/upcoming-orders/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::create
* @see app/Http/Controllers/UpcomingOrderController.php:38
* @route '/upcoming-orders/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::create
* @see app/Http/Controllers/UpcomingOrderController.php:38
* @route '/upcoming-orders/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\UpcomingOrderController::store
* @see app/Http/Controllers/UpcomingOrderController.php:47
* @route '/upcoming-orders'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/upcoming-orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UpcomingOrderController::store
* @see app/Http/Controllers/UpcomingOrderController.php:47
* @route '/upcoming-orders'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingOrderController::store
* @see app/Http/Controllers/UpcomingOrderController.php:47
* @route '/upcoming-orders'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::store
* @see app/Http/Controllers/UpcomingOrderController.php:47
* @route '/upcoming-orders'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::store
* @see app/Http/Controllers/UpcomingOrderController.php:47
* @route '/upcoming-orders'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\UpcomingOrderController::show
* @see app/Http/Controllers/UpcomingOrderController.php:210
* @route '/upcoming-orders/{upcoming_order}'
*/
export const show = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/upcoming-orders/{upcoming_order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UpcomingOrderController::show
* @see app/Http/Controllers/UpcomingOrderController.php:210
* @route '/upcoming-orders/{upcoming_order}'
*/
show.url = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { upcoming_order: args }
    }

    if (Array.isArray(args)) {
        args = {
            upcoming_order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        upcoming_order: args.upcoming_order,
    }

    return show.definition.url
            .replace('{upcoming_order}', parsedArgs.upcoming_order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingOrderController::show
* @see app/Http/Controllers/UpcomingOrderController.php:210
* @route '/upcoming-orders/{upcoming_order}'
*/
show.get = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::show
* @see app/Http/Controllers/UpcomingOrderController.php:210
* @route '/upcoming-orders/{upcoming_order}'
*/
show.head = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::show
* @see app/Http/Controllers/UpcomingOrderController.php:210
* @route '/upcoming-orders/{upcoming_order}'
*/
const showForm = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::show
* @see app/Http/Controllers/UpcomingOrderController.php:210
* @route '/upcoming-orders/{upcoming_order}'
*/
showForm.get = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::show
* @see app/Http/Controllers/UpcomingOrderController.php:210
* @route '/upcoming-orders/{upcoming_order}'
*/
showForm.head = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\UpcomingOrderController::edit
* @see app/Http/Controllers/UpcomingOrderController.php:221
* @route '/upcoming-orders/{upcoming_order}/edit'
*/
export const edit = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/upcoming-orders/{upcoming_order}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UpcomingOrderController::edit
* @see app/Http/Controllers/UpcomingOrderController.php:221
* @route '/upcoming-orders/{upcoming_order}/edit'
*/
edit.url = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { upcoming_order: args }
    }

    if (Array.isArray(args)) {
        args = {
            upcoming_order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        upcoming_order: args.upcoming_order,
    }

    return edit.definition.url
            .replace('{upcoming_order}', parsedArgs.upcoming_order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingOrderController::edit
* @see app/Http/Controllers/UpcomingOrderController.php:221
* @route '/upcoming-orders/{upcoming_order}/edit'
*/
edit.get = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::edit
* @see app/Http/Controllers/UpcomingOrderController.php:221
* @route '/upcoming-orders/{upcoming_order}/edit'
*/
edit.head = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::edit
* @see app/Http/Controllers/UpcomingOrderController.php:221
* @route '/upcoming-orders/{upcoming_order}/edit'
*/
const editForm = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::edit
* @see app/Http/Controllers/UpcomingOrderController.php:221
* @route '/upcoming-orders/{upcoming_order}/edit'
*/
editForm.get = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::edit
* @see app/Http/Controllers/UpcomingOrderController.php:221
* @route '/upcoming-orders/{upcoming_order}/edit'
*/
editForm.head = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\UpcomingOrderController::update
* @see app/Http/Controllers/UpcomingOrderController.php:229
* @route '/upcoming-orders/{upcoming_order}'
*/
export const update = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/upcoming-orders/{upcoming_order}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\UpcomingOrderController::update
* @see app/Http/Controllers/UpcomingOrderController.php:229
* @route '/upcoming-orders/{upcoming_order}'
*/
update.url = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { upcoming_order: args }
    }

    if (Array.isArray(args)) {
        args = {
            upcoming_order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        upcoming_order: args.upcoming_order,
    }

    return update.definition.url
            .replace('{upcoming_order}', parsedArgs.upcoming_order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingOrderController::update
* @see app/Http/Controllers/UpcomingOrderController.php:229
* @route '/upcoming-orders/{upcoming_order}'
*/
update.put = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::update
* @see app/Http/Controllers/UpcomingOrderController.php:229
* @route '/upcoming-orders/{upcoming_order}'
*/
update.patch = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::update
* @see app/Http/Controllers/UpcomingOrderController.php:229
* @route '/upcoming-orders/{upcoming_order}'
*/
const updateForm = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::update
* @see app/Http/Controllers/UpcomingOrderController.php:229
* @route '/upcoming-orders/{upcoming_order}'
*/
updateForm.put = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::update
* @see app/Http/Controllers/UpcomingOrderController.php:229
* @route '/upcoming-orders/{upcoming_order}'
*/
updateForm.patch = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\UpcomingOrderController::destroy
* @see app/Http/Controllers/UpcomingOrderController.php:247
* @route '/upcoming-orders/{upcoming_order}'
*/
export const destroy = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/upcoming-orders/{upcoming_order}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\UpcomingOrderController::destroy
* @see app/Http/Controllers/UpcomingOrderController.php:247
* @route '/upcoming-orders/{upcoming_order}'
*/
destroy.url = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { upcoming_order: args }
    }

    if (Array.isArray(args)) {
        args = {
            upcoming_order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        upcoming_order: args.upcoming_order,
    }

    return destroy.definition.url
            .replace('{upcoming_order}', parsedArgs.upcoming_order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingOrderController::destroy
* @see app/Http/Controllers/UpcomingOrderController.php:247
* @route '/upcoming-orders/{upcoming_order}'
*/
destroy.delete = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::destroy
* @see app/Http/Controllers/UpcomingOrderController.php:247
* @route '/upcoming-orders/{upcoming_order}'
*/
const destroyForm = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::destroy
* @see app/Http/Controllers/UpcomingOrderController.php:247
* @route '/upcoming-orders/{upcoming_order}'
*/
destroyForm.delete = (args: { upcoming_order: string | number } | [upcoming_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const upcomingOrders = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default upcomingOrders