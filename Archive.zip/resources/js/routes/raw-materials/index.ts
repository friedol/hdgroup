import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/raw-materials',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/raw-materials/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:130
* @route '/raw-materials'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/raw-materials',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:130
* @route '/raw-materials'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:130
* @route '/raw-materials'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:130
* @route '/raw-materials'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:130
* @route '/raw-materials'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/raw-materials/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
export const edit = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/raw-materials/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
edit.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return edit.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
edit.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
edit.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
const editForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
editForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
editForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:366
* @route '/raw-materials/{id}'
*/
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/raw-materials/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:366
* @route '/raw-materials/{id}'
*/
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:366
* @route '/raw-materials/{id}'
*/
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:366
* @route '/raw-materials/{id}'
*/
const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:366
* @route '/raw-materials/{id}'
*/
updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:489
* @route '/raw-materials/{id}'
*/
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/raw-materials/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:489
* @route '/raw-materials/{id}'
*/
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:489
* @route '/raw-materials/{id}'
*/
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:489
* @route '/raw-materials/{id}'
*/
const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:489
* @route '/raw-materials/{id}'
*/
destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\BomController::adjustStock
* @see app/Http/Controllers/BomController.php:501
* @route '/raw-materials/{id}/adjust'
*/
export const adjustStock = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStock.url(args, options),
    method: 'post',
})

adjustStock.definition = {
    methods: ["post"],
    url: '/raw-materials/{id}/adjust',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BomController::adjustStock
* @see app/Http/Controllers/BomController.php:501
* @route '/raw-materials/{id}/adjust'
*/
adjustStock.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return adjustStock.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::adjustStock
* @see app/Http/Controllers/BomController.php:501
* @route '/raw-materials/{id}/adjust'
*/
adjustStock.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStock.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::adjustStock
* @see app/Http/Controllers/BomController.php:501
* @route '/raw-materials/{id}/adjust'
*/
const adjustStockForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: adjustStock.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::adjustStock
* @see app/Http/Controllers/BomController.php:501
* @route '/raw-materials/{id}/adjust'
*/
adjustStockForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: adjustStock.url(args, options),
    method: 'post',
})

adjustStock.form = adjustStockForm

/**
* @see \App\Http\Controllers\BomController::json
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
export const json = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: json.url(args, options),
    method: 'get',
})

json.definition = {
    methods: ["get","head"],
    url: '/raw-materials/{id}/json',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::json
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
json.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return json.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::json
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
json.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: json.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::json
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
json.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: json.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::json
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
const jsonForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: json.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::json
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
jsonForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: json.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::json
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
jsonForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: json.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

json.form = jsonForm

const rawMaterials = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
    adjustStock: Object.assign(adjustStock, adjustStock),
    json: Object.assign(json, json),
}

export default rawMaterials