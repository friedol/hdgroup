import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::filter
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
export const filter = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filter.url(options),
    method: 'get',
})

filter.definition = {
    methods: ["get","head"],
    url: '/report_inventory/Filter',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::filter
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
filter.url = (options?: RouteQueryOptions) => {
    return filter.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::filter
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
filter.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filter.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::filter
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
filter.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: filter.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::filter
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
const filterForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::filter
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
filterForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::filter
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
filterForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

filter.form = filterForm

const inventory = {
    filter: Object.assign(filter, filter),
}

export default inventory