import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::single_product
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
export const single_product = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: single_product.url(args, options),
    method: 'get',
})

single_product.definition = {
    methods: ["get","head"],
    url: '/report_sales/single_product/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::single_product
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
single_product.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return single_product.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::single_product
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
single_product.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: single_product.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::single_product
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
single_product.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: single_product.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::single_product
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
const single_productForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: single_product.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::single_product
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
single_productForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: single_product.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::single_product
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
single_productForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: single_product.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

single_product.form = single_productForm

const sales = {
    single_product: Object.assign(single_product, single_product),
}

export default sales