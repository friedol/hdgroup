import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import inventoryEd84cf from './inventory'
import profit8e64f4 from './profit'
import salesF8b092 from './sales'
import product_movement861259 from './product_movement'
/**
* @see \App\Http\Controllers\ReportController::inventory
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
export const inventory = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: inventory.url(options),
    method: 'get',
})

inventory.definition = {
    methods: ["get","head"],
    url: '/report_inventory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::inventory
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
inventory.url = (options?: RouteQueryOptions) => {
    return inventory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::inventory
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
inventory.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: inventory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::inventory
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
inventory.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: inventory.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::inventory
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
const inventoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: inventory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::inventory
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
inventoryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: inventory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::inventory
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
inventoryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: inventory.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

inventory.form = inventoryForm

/**
* @see \App\Http\Controllers\ReportController::profit
* @see app/Http/Controllers/ReportController.php:135
* @route '/report_profit'
*/
export const profit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profit.url(options),
    method: 'get',
})

profit.definition = {
    methods: ["get","head"],
    url: '/report_profit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::profit
* @see app/Http/Controllers/ReportController.php:135
* @route '/report_profit'
*/
profit.url = (options?: RouteQueryOptions) => {
    return profit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::profit
* @see app/Http/Controllers/ReportController.php:135
* @route '/report_profit'
*/
profit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::profit
* @see app/Http/Controllers/ReportController.php:135
* @route '/report_profit'
*/
profit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profit.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::profit
* @see app/Http/Controllers/ReportController.php:135
* @route '/report_profit'
*/
const profitForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::profit
* @see app/Http/Controllers/ReportController.php:135
* @route '/report_profit'
*/
profitForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::profit
* @see app/Http/Controllers/ReportController.php:135
* @route '/report_profit'
*/
profitForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profit.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

profit.form = profitForm

/**
* @see \App\Http\Controllers\ReportController::loans
* @see app/Http/Controllers/ReportController.php:402
* @route '/report_loan'
*/
export const loans = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loans.url(options),
    method: 'get',
})

loans.definition = {
    methods: ["get","head"],
    url: '/report_loan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::loans
* @see app/Http/Controllers/ReportController.php:402
* @route '/report_loan'
*/
loans.url = (options?: RouteQueryOptions) => {
    return loans.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::loans
* @see app/Http/Controllers/ReportController.php:402
* @route '/report_loan'
*/
loans.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loans.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::loans
* @see app/Http/Controllers/ReportController.php:402
* @route '/report_loan'
*/
loans.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: loans.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::loans
* @see app/Http/Controllers/ReportController.php:402
* @route '/report_loan'
*/
const loansForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loans.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::loans
* @see app/Http/Controllers/ReportController.php:402
* @route '/report_loan'
*/
loansForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loans.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::loans
* @see app/Http/Controllers/ReportController.php:402
* @route '/report_loan'
*/
loansForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loans.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

loans.form = loansForm

/**
* @see \App\Http\Controllers\ReportController::sales
* @see app/Http/Controllers/ReportController.php:421
* @route '/report_sales'
*/
export const sales = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sales.url(options),
    method: 'get',
})

sales.definition = {
    methods: ["get","head"],
    url: '/report_sales',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::sales
* @see app/Http/Controllers/ReportController.php:421
* @route '/report_sales'
*/
sales.url = (options?: RouteQueryOptions) => {
    return sales.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::sales
* @see app/Http/Controllers/ReportController.php:421
* @route '/report_sales'
*/
sales.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sales.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::sales
* @see app/Http/Controllers/ReportController.php:421
* @route '/report_sales'
*/
sales.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sales.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::sales
* @see app/Http/Controllers/ReportController.php:421
* @route '/report_sales'
*/
const salesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sales.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::sales
* @see app/Http/Controllers/ReportController.php:421
* @route '/report_sales'
*/
salesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sales.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::sales
* @see app/Http/Controllers/ReportController.php:421
* @route '/report_sales'
*/
salesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sales.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

sales.form = salesForm

/**
* @see \App\Http\Controllers\ReportController::expenses
* @see app/Http/Controllers/ReportController.php:738
* @route '/report_expenses'
*/
export const expenses = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expenses.url(options),
    method: 'get',
})

expenses.definition = {
    methods: ["get","head"],
    url: '/report_expenses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::expenses
* @see app/Http/Controllers/ReportController.php:738
* @route '/report_expenses'
*/
expenses.url = (options?: RouteQueryOptions) => {
    return expenses.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::expenses
* @see app/Http/Controllers/ReportController.php:738
* @route '/report_expenses'
*/
expenses.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expenses.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::expenses
* @see app/Http/Controllers/ReportController.php:738
* @route '/report_expenses'
*/
expenses.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: expenses.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::expenses
* @see app/Http/Controllers/ReportController.php:738
* @route '/report_expenses'
*/
const expensesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: expenses.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::expenses
* @see app/Http/Controllers/ReportController.php:738
* @route '/report_expenses'
*/
expensesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: expenses.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::expenses
* @see app/Http/Controllers/ReportController.php:738
* @route '/report_expenses'
*/
expensesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: expenses.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

expenses.form = expensesForm

/**
* @see \App\Http\Controllers\ReportController::general
* @see app/Http/Controllers/ReportController.php:793
* @route '/report_general'
*/
export const general = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: general.url(options),
    method: 'get',
})

general.definition = {
    methods: ["get","head"],
    url: '/report_general',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::general
* @see app/Http/Controllers/ReportController.php:793
* @route '/report_general'
*/
general.url = (options?: RouteQueryOptions) => {
    return general.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::general
* @see app/Http/Controllers/ReportController.php:793
* @route '/report_general'
*/
general.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: general.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::general
* @see app/Http/Controllers/ReportController.php:793
* @route '/report_general'
*/
general.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: general.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::general
* @see app/Http/Controllers/ReportController.php:793
* @route '/report_general'
*/
const generalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: general.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::general
* @see app/Http/Controllers/ReportController.php:793
* @route '/report_general'
*/
generalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: general.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::general
* @see app/Http/Controllers/ReportController.php:793
* @route '/report_general'
*/
generalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: general.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

general.form = generalForm

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:909
* @route '/balance_sheet'
*/
export const balance_sheet = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balance_sheet.url(options),
    method: 'get',
})

balance_sheet.definition = {
    methods: ["get","head"],
    url: '/balance_sheet',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:909
* @route '/balance_sheet'
*/
balance_sheet.url = (options?: RouteQueryOptions) => {
    return balance_sheet.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:909
* @route '/balance_sheet'
*/
balance_sheet.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balance_sheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:909
* @route '/balance_sheet'
*/
balance_sheet.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: balance_sheet.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:909
* @route '/balance_sheet'
*/
const balance_sheetForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balance_sheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:909
* @route '/balance_sheet'
*/
balance_sheetForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balance_sheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:909
* @route '/balance_sheet'
*/
balance_sheetForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balance_sheet.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

balance_sheet.form = balance_sheetForm

/**
* @see \App\Http\Controllers\ReportController::product_movement
* @see app/Http/Controllers/ReportController.php:954
* @route '/report_product_movement'
*/
export const product_movement = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product_movement.url(options),
    method: 'get',
})

product_movement.definition = {
    methods: ["get","head"],
    url: '/report_product_movement',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::product_movement
* @see app/Http/Controllers/ReportController.php:954
* @route '/report_product_movement'
*/
product_movement.url = (options?: RouteQueryOptions) => {
    return product_movement.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::product_movement
* @see app/Http/Controllers/ReportController.php:954
* @route '/report_product_movement'
*/
product_movement.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product_movement.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::product_movement
* @see app/Http/Controllers/ReportController.php:954
* @route '/report_product_movement'
*/
product_movement.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: product_movement.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::product_movement
* @see app/Http/Controllers/ReportController.php:954
* @route '/report_product_movement'
*/
const product_movementForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product_movement.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::product_movement
* @see app/Http/Controllers/ReportController.php:954
* @route '/report_product_movement'
*/
product_movementForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product_movement.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::product_movement
* @see app/Http/Controllers/ReportController.php:954
* @route '/report_product_movement'
*/
product_movementForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product_movement.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

product_movement.form = product_movementForm

const report = {
    inventory: Object.assign(inventory, inventoryEd84cf),
    profit: Object.assign(profit, profit8e64f4),
    loans: Object.assign(loans, loans),
    sales: Object.assign(sales, salesF8b092),
    expenses: Object.assign(expenses, expenses),
    general: Object.assign(general, general),
    balance_sheet: Object.assign(balance_sheet, balance_sheet),
    product_movement: Object.assign(product_movement, product_movement861259),
}

export default report