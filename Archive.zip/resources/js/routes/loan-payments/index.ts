import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PaymentController::index
* @see app/Http/Controllers/PaymentController.php:18
* @route '/loan-payments'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/loan-payments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::index
* @see app/Http/Controllers/PaymentController.php:18
* @route '/loan-payments'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::index
* @see app/Http/Controllers/PaymentController.php:18
* @route '/loan-payments'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::index
* @see app/Http/Controllers/PaymentController.php:18
* @route '/loan-payments'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PaymentController::index
* @see app/Http/Controllers/PaymentController.php:18
* @route '/loan-payments'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::index
* @see app/Http/Controllers/PaymentController.php:18
* @route '/loan-payments'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::index
* @see app/Http/Controllers/PaymentController.php:18
* @route '/loan-payments'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\PaymentController::store
* @see app/Http/Controllers/PaymentController.php:44
* @route '/loan-payments'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/loan-payments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PaymentController::store
* @see app/Http/Controllers/PaymentController.php:44
* @route '/loan-payments'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::store
* @see app/Http/Controllers/PaymentController.php:44
* @route '/loan-payments'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentController::store
* @see app/Http/Controllers/PaymentController.php:44
* @route '/loan-payments'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentController::store
* @see app/Http/Controllers/PaymentController.php:44
* @route '/loan-payments'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\PaymentController::show
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
export const show = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/loan-payments/{loan_payment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::show
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
show.url = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan_payment: args }
    }

    if (Array.isArray(args)) {
        args = {
            loan_payment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        loan_payment: args.loan_payment,
    }

    return show.definition.url
            .replace('{loan_payment}', parsedArgs.loan_payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::show
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
show.get = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::show
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
show.head = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PaymentController::show
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
const showForm = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::show
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
showForm.get = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::show
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
showForm.head = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\PaymentController::edit
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}/edit'
*/
export const edit = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/loan-payments/{loan_payment}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::edit
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}/edit'
*/
edit.url = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan_payment: args }
    }

    if (Array.isArray(args)) {
        args = {
            loan_payment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        loan_payment: args.loan_payment,
    }

    return edit.definition.url
            .replace('{loan_payment}', parsedArgs.loan_payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::edit
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}/edit'
*/
edit.get = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::edit
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}/edit'
*/
edit.head = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PaymentController::edit
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}/edit'
*/
const editForm = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::edit
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}/edit'
*/
editForm.get = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::edit
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}/edit'
*/
editForm.head = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\PaymentController::update
* @see app/Http/Controllers/PaymentController.php:150
* @route '/loan-payments/{loan_payment}'
*/
export const update = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/loan-payments/{loan_payment}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\PaymentController::update
* @see app/Http/Controllers/PaymentController.php:150
* @route '/loan-payments/{loan_payment}'
*/
update.url = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan_payment: args }
    }

    if (Array.isArray(args)) {
        args = {
            loan_payment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        loan_payment: args.loan_payment,
    }

    return update.definition.url
            .replace('{loan_payment}', parsedArgs.loan_payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::update
* @see app/Http/Controllers/PaymentController.php:150
* @route '/loan-payments/{loan_payment}'
*/
update.put = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\PaymentController::update
* @see app/Http/Controllers/PaymentController.php:150
* @route '/loan-payments/{loan_payment}'
*/
update.patch = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\PaymentController::update
* @see app/Http/Controllers/PaymentController.php:150
* @route '/loan-payments/{loan_payment}'
*/
const updateForm = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentController::update
* @see app/Http/Controllers/PaymentController.php:150
* @route '/loan-payments/{loan_payment}'
*/
updateForm.put = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentController::update
* @see app/Http/Controllers/PaymentController.php:150
* @route '/loan-payments/{loan_payment}'
*/
updateForm.patch = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\PaymentController::destroy
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
export const destroy = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/loan-payments/{loan_payment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PaymentController::destroy
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
destroy.url = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan_payment: args }
    }

    if (Array.isArray(args)) {
        args = {
            loan_payment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        loan_payment: args.loan_payment,
    }

    return destroy.definition.url
            .replace('{loan_payment}', parsedArgs.loan_payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::destroy
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
destroy.delete = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\PaymentController::destroy
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
const destroyForm = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentController::destroy
* @see app/Http/Controllers/PaymentController.php:0
* @route '/loan-payments/{loan_payment}'
*/
destroyForm.delete = (args: { loan_payment: string | number } | [loan_payment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const loanPayments = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default loanPayments