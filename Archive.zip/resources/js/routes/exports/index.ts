import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/exported-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
export const check = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: check.url(args, options),
    method: 'get',
})

check.definition = {
    methods: ["get","head"],
    url: '/exports/check/{unique_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
check.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return check.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
check.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: check.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
check.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: check.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
const checkForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: check.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
checkForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: check.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
checkForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: check.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

check.form = checkForm

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
export const reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

reports.definition = {
    methods: ["get","head"],
    url: '/exports_reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
reports.url = (options?: RouteQueryOptions) => {
    return reports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reports.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
const reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

reports.form = reportsForm

const exports = {
    index: Object.assign(index, index),
    check: Object.assign(check, check),
    reports: Object.assign(reports, reports),
}

export default exports