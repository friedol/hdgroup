import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CartController::confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
export const confirmation = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirmation.url(args, options),
    method: 'get',
})

confirmation.definition = {
    methods: ["get","head"],
    url: '/order/confirmation/{unique_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
confirmation.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return confirmation.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
confirmation.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirmation.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
confirmation.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: confirmation.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
const confirmationForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirmation.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
confirmationForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirmation.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
confirmationForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirmation.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

confirmation.form = confirmationForm

/**
* @see \App\Http\Controllers\CartController::track
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
export const track = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track.url(args, options),
    method: 'get',
})

track.definition = {
    methods: ["get","head"],
    url: '/order/track/{unique_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::track
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
track.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return track.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::track
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
track.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::track
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
track.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: track.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::track
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
const trackForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::track
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
trackForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::track
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
trackForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

track.form = trackForm

const order = {
    confirmation: Object.assign(confirmation, confirmation),
    track: Object.assign(track, track),
}

export default order