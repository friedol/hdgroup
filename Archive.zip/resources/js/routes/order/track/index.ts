import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CartController::lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
export const lookup = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: lookup.url(options),
    method: 'get',
})

lookup.definition = {
    methods: ["get","head"],
    url: '/order/track',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
lookup.url = (options?: RouteQueryOptions) => {
    return lookup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
lookup.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: lookup.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
lookup.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: lookup.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
const lookupForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: lookup.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
lookupForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: lookup.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
lookupForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: lookup.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

lookup.form = lookupForm

/**
* @see \App\Http\Controllers\CartController::submit
* @see app/Http/Controllers/CartController.php:424
* @route '/order/track'
*/
export const submit = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/order/track',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::submit
* @see app/Http/Controllers/CartController.php:424
* @route '/order/track'
*/
submit.url = (options?: RouteQueryOptions) => {
    return submit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::submit
* @see app/Http/Controllers/CartController.php:424
* @route '/order/track'
*/
submit.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::submit
* @see app/Http/Controllers/CartController.php:424
* @route '/order/track'
*/
const submitForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::submit
* @see app/Http/Controllers/CartController.php:424
* @route '/order/track'
*/
submitForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(options),
    method: 'post',
})

submit.form = submitForm
