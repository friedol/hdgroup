import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\SystemSettingController::index
* @see app/Http/Controllers/SystemSettingController.php:15
* @route '/settings'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SystemSettingController::index
* @see app/Http/Controllers/SystemSettingController.php:15
* @route '/settings'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SystemSettingController::index
* @see app/Http/Controllers/SystemSettingController.php:15
* @route '/settings'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SystemSettingController::index
* @see app/Http/Controllers/SystemSettingController.php:15
* @route '/settings'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SystemSettingController::index
* @see app/Http/Controllers/SystemSettingController.php:15
* @route '/settings'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SystemSettingController::index
* @see app/Http/Controllers/SystemSettingController.php:15
* @route '/settings'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SystemSettingController::index
* @see app/Http/Controllers/SystemSettingController.php:15
* @route '/settings'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\SystemSettingController::update
* @see app/Http/Controllers/SystemSettingController.php:57
* @route '/settings/update'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/settings/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SystemSettingController::update
* @see app/Http/Controllers/SystemSettingController.php:57
* @route '/settings/update'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SystemSettingController::update
* @see app/Http/Controllers/SystemSettingController.php:57
* @route '/settings/update'
*/
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SystemSettingController::update
* @see app/Http/Controllers/SystemSettingController.php:57
* @route '/settings/update'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SystemSettingController::update
* @see app/Http/Controllers/SystemSettingController.php:57
* @route '/settings/update'
*/
updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(options),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\SystemSettingController::testEmail
* @see app/Http/Controllers/SystemSettingController.php:129
* @route '/settings/test-email'
*/
export const testEmail = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testEmail.url(options),
    method: 'post',
})

testEmail.definition = {
    methods: ["post"],
    url: '/settings/test-email',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SystemSettingController::testEmail
* @see app/Http/Controllers/SystemSettingController.php:129
* @route '/settings/test-email'
*/
testEmail.url = (options?: RouteQueryOptions) => {
    return testEmail.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SystemSettingController::testEmail
* @see app/Http/Controllers/SystemSettingController.php:129
* @route '/settings/test-email'
*/
testEmail.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testEmail.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SystemSettingController::testEmail
* @see app/Http/Controllers/SystemSettingController.php:129
* @route '/settings/test-email'
*/
const testEmailForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: testEmail.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SystemSettingController::testEmail
* @see app/Http/Controllers/SystemSettingController.php:129
* @route '/settings/test-email'
*/
testEmailForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: testEmail.url(options),
    method: 'post',
})

testEmail.form = testEmailForm

/**
* @see \App\Http\Controllers\SystemSettingController::toggleOnlineShop
* @see app/Http/Controllers/SystemSettingController.php:155
* @route '/settings/toggle-online-shop'
*/
export const toggleOnlineShop = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleOnlineShop.url(options),
    method: 'post',
})

toggleOnlineShop.definition = {
    methods: ["post"],
    url: '/settings/toggle-online-shop',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SystemSettingController::toggleOnlineShop
* @see app/Http/Controllers/SystemSettingController.php:155
* @route '/settings/toggle-online-shop'
*/
toggleOnlineShop.url = (options?: RouteQueryOptions) => {
    return toggleOnlineShop.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SystemSettingController::toggleOnlineShop
* @see app/Http/Controllers/SystemSettingController.php:155
* @route '/settings/toggle-online-shop'
*/
toggleOnlineShop.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleOnlineShop.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SystemSettingController::toggleOnlineShop
* @see app/Http/Controllers/SystemSettingController.php:155
* @route '/settings/toggle-online-shop'
*/
const toggleOnlineShopForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleOnlineShop.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SystemSettingController::toggleOnlineShop
* @see app/Http/Controllers/SystemSettingController.php:155
* @route '/settings/toggle-online-shop'
*/
toggleOnlineShopForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleOnlineShop.url(options),
    method: 'post',
})

toggleOnlineShop.form = toggleOnlineShopForm

const settings = {
    index: Object.assign(index, index),
    update: Object.assign(update, update),
    testEmail: Object.assign(testEmail, testEmail),
    toggleOnlineShop: Object.assign(toggleOnlineShop, toggleOnlineShop),
}

export default settings