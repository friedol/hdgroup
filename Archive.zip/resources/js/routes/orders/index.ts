import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import create from './create'
import online2d5f56 from './online'
/**
* @see \App\Http\Controllers\CartController::history
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
export const history = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/order/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::history
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
history.url = (options?: RouteQueryOptions) => {
    return history.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::history
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
history.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::history
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
history.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::history
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
const historyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::history
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
historyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::history
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
historyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

history.form = historyForm

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\CustomerOrderController::store
* @see app/Http/Controllers/CustomerOrderController.php:677
* @route '/orders'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::store
* @see app/Http/Controllers/CustomerOrderController.php:677
* @route '/orders'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::store
* @see app/Http/Controllers/CustomerOrderController.php:677
* @route '/orders'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::store
* @see app/Http/Controllers/CustomerOrderController.php:677
* @route '/orders'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::store
* @see app/Http/Controllers/CustomerOrderController.php:677
* @route '/orders'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
export const show = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/orders/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
show.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return show.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
show.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
show.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
const showForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
showForm.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
showForm.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
export const edit = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/orders/{order}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
edit.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return edit.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
edit.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
edit.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
const editForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
editForm.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
editForm.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
export const update = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/orders/{order}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
update.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return update.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
update.put = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
update.patch = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
const updateForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
updateForm.put = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
updateForm.patch = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1399
* @route '/orders/{order}'
*/
export const destroy = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/orders/{order}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1399
* @route '/orders/{order}'
*/
destroy.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return destroy.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1399
* @route '/orders/{order}'
*/
destroy.delete = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1399
* @route '/orders/{order}'
*/
const destroyForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1399
* @route '/orders/{order}'
*/
destroyForm.delete = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\CustomerOrderController::all
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
export const all = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all.url(options),
    method: 'get',
})

all.definition = {
    methods: ["get","head"],
    url: '/general-orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::all
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
all.url = (options?: RouteQueryOptions) => {
    return all.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::all
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
all.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::all
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
all.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: all.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::all
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
const allForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: all.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::all
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
allForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: all.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::all
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
allForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: all.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

all.form = allForm

/**
* @see \App\Http\Controllers\CustomerOrderController::online
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
export const online = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: online.url(options),
    method: 'get',
})

online.definition = {
    methods: ["get","head"],
    url: '/online-orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::online
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
online.url = (options?: RouteQueryOptions) => {
    return online.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::online
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
online.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: online.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::online
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
online.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: online.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::online
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
const onlineForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: online.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::online
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
onlineForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: online.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::online
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
onlineForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: online.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

online.form = onlineForm

const orders = {
    history: Object.assign(history, history),
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
    all: Object.assign(all, all),
    online: Object.assign(online, online2d5f56),
}

export default orders