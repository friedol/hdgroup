import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
export const show = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/online-orders/{unique_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
show.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return show.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
show.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
show.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
const showForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
showForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
showForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1645
* @route '/online-orders/{unique_id}'
*/
export const destroy = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/online-orders/{unique_id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1645
* @route '/online-orders/{unique_id}'
*/
destroy.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return destroy.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1645
* @route '/online-orders/{unique_id}'
*/
destroy.delete = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1645
* @route '/online-orders/{unique_id}'
*/
const destroyForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1645
* @route '/online-orders/{unique_id}'
*/
destroyForm.delete = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\CustomerOrderController::approve
* @see app/Http/Controllers/CustomerOrderController.php:1491
* @route '/online-orders/{unique_id}/approve'
*/
export const approve = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/online-orders/{unique_id}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::approve
* @see app/Http/Controllers/CustomerOrderController.php:1491
* @route '/online-orders/{unique_id}/approve'
*/
approve.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return approve.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::approve
* @see app/Http/Controllers/CustomerOrderController.php:1491
* @route '/online-orders/{unique_id}/approve'
*/
approve.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::approve
* @see app/Http/Controllers/CustomerOrderController.php:1491
* @route '/online-orders/{unique_id}/approve'
*/
const approveForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::approve
* @see app/Http/Controllers/CustomerOrderController.php:1491
* @route '/online-orders/{unique_id}/approve'
*/
approveForm.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

approve.form = approveForm

/**
* @see \App\Http\Controllers\CustomerOrderController::reject
* @see app/Http/Controllers/CustomerOrderController.php:1584
* @route '/online-orders/{unique_id}/reject'
*/
export const reject = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/online-orders/{unique_id}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::reject
* @see app/Http/Controllers/CustomerOrderController.php:1584
* @route '/online-orders/{unique_id}/reject'
*/
reject.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return reject.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::reject
* @see app/Http/Controllers/CustomerOrderController.php:1584
* @route '/online-orders/{unique_id}/reject'
*/
reject.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::reject
* @see app/Http/Controllers/CustomerOrderController.php:1584
* @route '/online-orders/{unique_id}/reject'
*/
const rejectForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::reject
* @see app/Http/Controllers/CustomerOrderController.php:1584
* @route '/online-orders/{unique_id}/reject'
*/
rejectForm.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, options),
    method: 'post',
})

reject.form = rejectForm

/**
* @see \App\Http\Controllers\CustomerOrderController::pay
* @see app/Http/Controllers/CustomerOrderController.php:1319
* @route '/online-orders/{unique_id}/pay'
*/
export const pay = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

pay.definition = {
    methods: ["post"],
    url: '/online-orders/{unique_id}/pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::pay
* @see app/Http/Controllers/CustomerOrderController.php:1319
* @route '/online-orders/{unique_id}/pay'
*/
pay.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return pay.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::pay
* @see app/Http/Controllers/CustomerOrderController.php:1319
* @route '/online-orders/{unique_id}/pay'
*/
pay.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::pay
* @see app/Http/Controllers/CustomerOrderController.php:1319
* @route '/online-orders/{unique_id}/pay'
*/
const payForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pay.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::pay
* @see app/Http/Controllers/CustomerOrderController.php:1319
* @route '/online-orders/{unique_id}/pay'
*/
payForm.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pay.url(args, options),
    method: 'post',
})

pay.form = payForm

/**
* @see \App\Http\Controllers\CustomerOrderController::deliveryStatus
* @see app/Http/Controllers/CustomerOrderController.php:1615
* @route '/online-orders/{unique_id}/delivery-status'
*/
export const deliveryStatus = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deliveryStatus.url(args, options),
    method: 'post',
})

deliveryStatus.definition = {
    methods: ["post"],
    url: '/online-orders/{unique_id}/delivery-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::deliveryStatus
* @see app/Http/Controllers/CustomerOrderController.php:1615
* @route '/online-orders/{unique_id}/delivery-status'
*/
deliveryStatus.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return deliveryStatus.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::deliveryStatus
* @see app/Http/Controllers/CustomerOrderController.php:1615
* @route '/online-orders/{unique_id}/delivery-status'
*/
deliveryStatus.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deliveryStatus.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::deliveryStatus
* @see app/Http/Controllers/CustomerOrderController.php:1615
* @route '/online-orders/{unique_id}/delivery-status'
*/
const deliveryStatusForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deliveryStatus.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::deliveryStatus
* @see app/Http/Controllers/CustomerOrderController.php:1615
* @route '/online-orders/{unique_id}/delivery-status'
*/
deliveryStatusForm.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deliveryStatus.url(args, options),
    method: 'post',
})

deliveryStatus.form = deliveryStatusForm

const online = {
    show: Object.assign(show, show),
    destroy: Object.assign(destroy, destroy),
    approve: Object.assign(approve, approve),
    reject: Object.assign(reject, reject),
    pay: Object.assign(pay, pay),
    deliveryStatus: Object.assign(deliveryStatus, deliveryStatus),
}

export default online