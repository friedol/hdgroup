import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
export const crud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: crud.url(args, options),
    method: 'get',
})

crud.definition = {
    methods: ["get","head"],
    url: '/orders-crud/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
crud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return crud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
crud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: crud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
crud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: crud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
const crudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: crud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
crudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: crud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
crudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: crud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

crud.form = crudForm
