import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:1278
* @route '/orders-crud'
*/
export const crud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

crud.definition = {
    methods: ["post"],
    url: '/orders-crud',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:1278
* @route '/orders-crud'
*/
crud.url = (options?: RouteQueryOptions) => {
    return crud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:1278
* @route '/orders-crud'
*/
crud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:1278
* @route '/orders-crud'
*/
const crudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::crud
* @see app/Http/Controllers/CustomerOrderController.php:1278
* @route '/orders-crud'
*/
crudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

crud.form = crudForm
