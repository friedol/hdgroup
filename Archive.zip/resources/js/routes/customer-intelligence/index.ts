import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/customer-intelligence',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

const customerIntelligence = {
    dashboard: Object.assign(dashboard, dashboard),
}

export default customerIntelligence