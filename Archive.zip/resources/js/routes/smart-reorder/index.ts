import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:15
* @route '/smart-reorder'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/smart-reorder',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:15
* @route '/smart-reorder'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:15
* @route '/smart-reorder'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:15
* @route '/smart-reorder'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:15
* @route '/smart-reorder'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:15
* @route '/smart-reorder'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:15
* @route '/smart-reorder'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

const smartReorder = {
    dashboard: Object.assign(dashboard, dashboard),
}

export default smartReorder