import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\UserController::crud
* @see app/Http/Controllers/UserController.php:45
* @route '/users-crud'
*/
export const crud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

crud.definition = {
    methods: ["post"],
    url: '/users-crud',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserController::crud
* @see app/Http/Controllers/UserController.php:45
* @route '/users-crud'
*/
crud.url = (options?: RouteQueryOptions) => {
    return crud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::crud
* @see app/Http/Controllers/UserController.php:45
* @route '/users-crud'
*/
crud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::crud
* @see app/Http/Controllers/UserController.php:45
* @route '/users-crud'
*/
const crudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::crud
* @see app/Http/Controllers/UserController.php:45
* @route '/users-crud'
*/
crudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

crud.form = crudForm
