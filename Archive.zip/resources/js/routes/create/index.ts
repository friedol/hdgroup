import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ProfileController::account
* @see app/Http/Controllers/ProfileController.php:27
* @route '/create-account'
*/
export const account = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: account.url(options),
    method: 'post',
})

account.definition = {
    methods: ["post"],
    url: '/create-account',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProfileController::account
* @see app/Http/Controllers/ProfileController.php:27
* @route '/create-account'
*/
account.url = (options?: RouteQueryOptions) => {
    return account.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::account
* @see app/Http/Controllers/ProfileController.php:27
* @route '/create-account'
*/
account.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: account.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::account
* @see app/Http/Controllers/ProfileController.php:27
* @route '/create-account'
*/
const accountForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: account.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::account
* @see app/Http/Controllers/ProfileController.php:27
* @route '/create-account'
*/
accountForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: account.url(options),
    method: 'post',
})

account.form = accountForm

const create = {
    account: Object.assign(account, account),
}

export default create