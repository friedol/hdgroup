import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ContainerController::crud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud'
*/
export const crud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

crud.definition = {
    methods: ["post"],
    url: '/containers-crud',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ContainerController::crud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud'
*/
crud.url = (options?: RouteQueryOptions) => {
    return crud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::crud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud'
*/
crud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContainerController::crud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud'
*/
const crudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContainerController::crud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud'
*/
crudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

crud.form = crudForm
