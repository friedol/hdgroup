import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\HomeController::submit
* @see app/Http/Controllers/HomeController.php:105
* @route '/contact/message'
*/
export const submit = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/contact/message',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HomeController::submit
* @see app/Http/Controllers/HomeController.php:105
* @route '/contact/message'
*/
submit.url = (options?: RouteQueryOptions) => {
    return submit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::submit
* @see app/Http/Controllers/HomeController.php:105
* @route '/contact/message'
*/
submit.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HomeController::submit
* @see app/Http/Controllers/HomeController.php:105
* @route '/contact/message'
*/
const submitForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HomeController::submit
* @see app/Http/Controllers/HomeController.php:105
* @route '/contact/message'
*/
submitForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(options),
    method: 'post',
})

submit.form = submitForm

const contact = {
    submit: Object.assign(submit, submit),
}

export default contact