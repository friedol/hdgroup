import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CustomerOrderController::status
* @see app/Http/Controllers/CustomerOrderController.php:541
* @route '/cart-toggle-status'
*/
export const status = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: status.url(options),
    method: 'post',
})

status.definition = {
    methods: ["post"],
    url: '/cart-toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::status
* @see app/Http/Controllers/CustomerOrderController.php:541
* @route '/cart-toggle-status'
*/
status.url = (options?: RouteQueryOptions) => {
    return status.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::status
* @see app/Http/Controllers/CustomerOrderController.php:541
* @route '/cart-toggle-status'
*/
status.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: status.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::status
* @see app/Http/Controllers/CustomerOrderController.php:541
* @route '/cart-toggle-status'
*/
const statusForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: status.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::status
* @see app/Http/Controllers/CustomerOrderController.php:541
* @route '/cart-toggle-status'
*/
statusForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: status.url(options),
    method: 'post',
})

status.form = statusForm

const cartToggle = {
    status: Object.assign(status, status),
}

export default cartToggle