import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud'
*/
export const crud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

crud.definition = {
    methods: ["post"],
    url: '/boms-crud',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud'
*/
crud.url = (options?: RouteQueryOptions) => {
    return crud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud'
*/
crud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud'
*/
const crudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud'
*/
crudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

crud.form = crudForm
