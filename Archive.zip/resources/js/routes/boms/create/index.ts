import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
export const crud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: crud.url(options),
    method: 'get',
})

crud.definition = {
    methods: ["get","head"],
    url: '/boms-crud/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
crud.url = (options?: RouteQueryOptions) => {
    return crud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
crud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: crud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
crud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: crud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
const crudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: crud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
crudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: crud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::crud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
crudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: crud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

crud.form = crudForm
