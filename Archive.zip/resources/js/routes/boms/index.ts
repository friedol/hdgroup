import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/boms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/boms/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:602
* @route '/boms'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/boms',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:602
* @route '/boms'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:602
* @route '/boms'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:602
* @route '/boms'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:602
* @route '/boms'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
export const show = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/boms/{bom}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
show.url = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bom: args }
    }

    if (Array.isArray(args)) {
        args = {
            bom: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        bom: args.bom,
    }

    return show.definition.url
            .replace('{bom}', parsedArgs.bom.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
show.get = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
show.head = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
const showForm = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
showForm.get = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
showForm.head = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
export const edit = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/boms/{bom}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
edit.url = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bom: args }
    }

    if (Array.isArray(args)) {
        args = {
            bom: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        bom: args.bom,
    }

    return edit.definition.url
            .replace('{bom}', parsedArgs.bom.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
edit.get = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
edit.head = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
const editForm = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
editForm.get = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
editForm.head = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
export const update = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/boms/{bom}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
update.url = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bom: args }
    }

    if (Array.isArray(args)) {
        args = {
            bom: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        bom: args.bom,
    }

    return update.definition.url
            .replace('{bom}', parsedArgs.bom.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
update.put = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
update.patch = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
const updateForm = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
updateForm.put = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
updateForm.patch = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:810
* @route '/boms/{bom}'
*/
export const destroy = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/boms/{bom}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:810
* @route '/boms/{bom}'
*/
destroy.url = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bom: args }
    }

    if (Array.isArray(args)) {
        args = {
            bom: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        bom: args.bom,
    }

    return destroy.definition.url
            .replace('{bom}', parsedArgs.bom.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:810
* @route '/boms/{bom}'
*/
destroy.delete = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:810
* @route '/boms/{bom}'
*/
const destroyForm = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:810
* @route '/boms/{bom}'
*/
destroyForm.delete = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\BomController::calculateCost
* @see app/Http/Controllers/BomController.php:836
* @route '/boms/calculate-cost'
*/
export const calculateCost = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: calculateCost.url(options),
    method: 'post',
})

calculateCost.definition = {
    methods: ["post"],
    url: '/boms/calculate-cost',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BomController::calculateCost
* @see app/Http/Controllers/BomController.php:836
* @route '/boms/calculate-cost'
*/
calculateCost.url = (options?: RouteQueryOptions) => {
    return calculateCost.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::calculateCost
* @see app/Http/Controllers/BomController.php:836
* @route '/boms/calculate-cost'
*/
calculateCost.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: calculateCost.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::calculateCost
* @see app/Http/Controllers/BomController.php:836
* @route '/boms/calculate-cost'
*/
const calculateCostForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: calculateCost.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::calculateCost
* @see app/Http/Controllers/BomController.php:836
* @route '/boms/calculate-cost'
*/
calculateCostForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: calculateCost.url(options),
    method: 'post',
})

calculateCost.form = calculateCostForm

/**
* @see \App\Http\Controllers\BomController::activate
* @see app/Http/Controllers/BomController.php:775
* @route '/boms/{id}/activate'
*/
export const activate = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: activate.url(args, options),
    method: 'put',
})

activate.definition = {
    methods: ["put"],
    url: '/boms/{id}/activate',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\BomController::activate
* @see app/Http/Controllers/BomController.php:775
* @route '/boms/{id}/activate'
*/
activate.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return activate.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::activate
* @see app/Http/Controllers/BomController.php:775
* @route '/boms/{id}/activate'
*/
activate.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: activate.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\BomController::activate
* @see app/Http/Controllers/BomController.php:775
* @route '/boms/{id}/activate'
*/
const activateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: activate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::activate
* @see app/Http/Controllers/BomController.php:775
* @route '/boms/{id}/activate'
*/
activateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: activate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

activate.form = activateForm

/**
* @see \App\Http\Controllers\BomController::deactivate
* @see app/Http/Controllers/BomController.php:800
* @route '/boms/{id}/deactivate'
*/
export const deactivate = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: deactivate.url(args, options),
    method: 'put',
})

deactivate.definition = {
    methods: ["put"],
    url: '/boms/{id}/deactivate',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\BomController::deactivate
* @see app/Http/Controllers/BomController.php:800
* @route '/boms/{id}/deactivate'
*/
deactivate.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return deactivate.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::deactivate
* @see app/Http/Controllers/BomController.php:800
* @route '/boms/{id}/deactivate'
*/
deactivate.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: deactivate.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\BomController::deactivate
* @see app/Http/Controllers/BomController.php:800
* @route '/boms/{id}/deactivate'
*/
const deactivateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deactivate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::deactivate
* @see app/Http/Controllers/BomController.php:800
* @route '/boms/{id}/deactivate'
*/
deactivateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deactivate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

deactivate.form = deactivateForm

const boms = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
    calculateCost: Object.assign(calculateCost, calculateCost),
    activate: Object.assign(activate, activate),
    deactivate: Object.assign(deactivate, deactivate),
}

export default boms