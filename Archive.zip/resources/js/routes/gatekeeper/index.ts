import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:19
* @route '/gatekeeper'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/gatekeeper',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:19
* @route '/gatekeeper'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:19
* @route '/gatekeeper'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:19
* @route '/gatekeeper'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:19
* @route '/gatekeeper'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:19
* @route '/gatekeeper'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:19
* @route '/gatekeeper'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:45
* @route '/gatekeeper/record-in'
*/
export const recordInForm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recordInForm.url(options),
    method: 'get',
})

recordInForm.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/record-in',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:45
* @route '/gatekeeper/record-in'
*/
recordInForm.url = (options?: RouteQueryOptions) => {
    return recordInForm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:45
* @route '/gatekeeper/record-in'
*/
recordInForm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recordInForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:45
* @route '/gatekeeper/record-in'
*/
recordInForm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: recordInForm.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:45
* @route '/gatekeeper/record-in'
*/
const recordInFormForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordInForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:45
* @route '/gatekeeper/record-in'
*/
recordInFormForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordInForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:45
* @route '/gatekeeper/record-in'
*/
recordInFormForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordInForm.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

recordInForm.form = recordInFormForm

/**
* @see \App\Http\Controllers\GatekeeperController::recordIn
* @see app/Http/Controllers/GatekeeperController.php:61
* @route '/gatekeeper/record-in'
*/
export const recordIn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recordIn.url(options),
    method: 'post',
})

recordIn.definition = {
    methods: ["post"],
    url: '/gatekeeper/record-in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GatekeeperController::recordIn
* @see app/Http/Controllers/GatekeeperController.php:61
* @route '/gatekeeper/record-in'
*/
recordIn.url = (options?: RouteQueryOptions) => {
    return recordIn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::recordIn
* @see app/Http/Controllers/GatekeeperController.php:61
* @route '/gatekeeper/record-in'
*/
recordIn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recordIn.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordIn
* @see app/Http/Controllers/GatekeeperController.php:61
* @route '/gatekeeper/record-in'
*/
const recordInForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: recordIn.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordIn
* @see app/Http/Controllers/GatekeeperController.php:61
* @route '/gatekeeper/record-in'
*/
recordInForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: recordIn.url(options),
    method: 'post',
})

recordIn.form = recordInForm

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:104
* @route '/gatekeeper/record-out'
*/
export const recordOutForm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recordOutForm.url(options),
    method: 'get',
})

recordOutForm.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/record-out',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:104
* @route '/gatekeeper/record-out'
*/
recordOutForm.url = (options?: RouteQueryOptions) => {
    return recordOutForm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:104
* @route '/gatekeeper/record-out'
*/
recordOutForm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recordOutForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:104
* @route '/gatekeeper/record-out'
*/
recordOutForm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: recordOutForm.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:104
* @route '/gatekeeper/record-out'
*/
const recordOutFormForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordOutForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:104
* @route '/gatekeeper/record-out'
*/
recordOutFormForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordOutForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:104
* @route '/gatekeeper/record-out'
*/
recordOutFormForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordOutForm.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

recordOutForm.form = recordOutFormForm

/**
* @see \App\Http\Controllers\GatekeeperController::recordOut
* @see app/Http/Controllers/GatekeeperController.php:120
* @route '/gatekeeper/record-out'
*/
export const recordOut = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recordOut.url(options),
    method: 'post',
})

recordOut.definition = {
    methods: ["post"],
    url: '/gatekeeper/record-out',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GatekeeperController::recordOut
* @see app/Http/Controllers/GatekeeperController.php:120
* @route '/gatekeeper/record-out'
*/
recordOut.url = (options?: RouteQueryOptions) => {
    return recordOut.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::recordOut
* @see app/Http/Controllers/GatekeeperController.php:120
* @route '/gatekeeper/record-out'
*/
recordOut.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recordOut.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordOut
* @see app/Http/Controllers/GatekeeperController.php:120
* @route '/gatekeeper/record-out'
*/
const recordOutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: recordOut.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordOut
* @see app/Http/Controllers/GatekeeperController.php:120
* @route '/gatekeeper/record-out'
*/
recordOutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: recordOut.url(options),
    method: 'post',
})

recordOut.form = recordOutForm

/**
* @see \App\Http\Controllers\GatekeeperController::print
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/print'
*/
export const print = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::print
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/print'
*/
print.url = (options?: RouteQueryOptions) => {
    return print.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::print
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/print'
*/
print.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::print
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/print'
*/
print.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::print
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/print'
*/
const printForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::print
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/print'
*/
printForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::print
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/print'
*/
printForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

print.form = printForm

/**
* @see \App\Http\Controllers\GatekeeperController::exportPdf
* @see app/Http/Controllers/GatekeeperController.php:173
* @route '/gatekeeper/export/pdf'
*/
export const exportPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPdf.url(options),
    method: 'get',
})

exportPdf.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/export/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::exportPdf
* @see app/Http/Controllers/GatekeeperController.php:173
* @route '/gatekeeper/export/pdf'
*/
exportPdf.url = (options?: RouteQueryOptions) => {
    return exportPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::exportPdf
* @see app/Http/Controllers/GatekeeperController.php:173
* @route '/gatekeeper/export/pdf'
*/
exportPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::exportPdf
* @see app/Http/Controllers/GatekeeperController.php:173
* @route '/gatekeeper/export/pdf'
*/
exportPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportPdf.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::exportPdf
* @see app/Http/Controllers/GatekeeperController.php:173
* @route '/gatekeeper/export/pdf'
*/
const exportPdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::exportPdf
* @see app/Http/Controllers/GatekeeperController.php:173
* @route '/gatekeeper/export/pdf'
*/
exportPdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::exportPdf
* @see app/Http/Controllers/GatekeeperController.php:173
* @route '/gatekeeper/export/pdf'
*/
exportPdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportPdf.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

exportPdf.form = exportPdfForm

/**
* @see \App\Http\Controllers\GatekeeperController::stats
* @see app/Http/Controllers/GatekeeperController.php:271
* @route '/gatekeeper/stats'
*/
export const stats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})

stats.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::stats
* @see app/Http/Controllers/GatekeeperController.php:271
* @route '/gatekeeper/stats'
*/
stats.url = (options?: RouteQueryOptions) => {
    return stats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::stats
* @see app/Http/Controllers/GatekeeperController.php:271
* @route '/gatekeeper/stats'
*/
stats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::stats
* @see app/Http/Controllers/GatekeeperController.php:271
* @route '/gatekeeper/stats'
*/
stats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stats.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::stats
* @see app/Http/Controllers/GatekeeperController.php:271
* @route '/gatekeeper/stats'
*/
const statsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: stats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::stats
* @see app/Http/Controllers/GatekeeperController.php:271
* @route '/gatekeeper/stats'
*/
statsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: stats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::stats
* @see app/Http/Controllers/GatekeeperController.php:271
* @route '/gatekeeper/stats'
*/
statsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: stats.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

stats.form = statsForm

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:163
* @route '/gatekeeper/{gatekeeperLog}'
*/
export const show = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/{gatekeeperLog}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:163
* @route '/gatekeeper/{gatekeeperLog}'
*/
show.url = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gatekeeperLog: args }
    }

    if (Array.isArray(args)) {
        args = {
            gatekeeperLog: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        gatekeeperLog: args.gatekeeperLog,
    }

    return show.definition.url
            .replace('{gatekeeperLog}', parsedArgs.gatekeeperLog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:163
* @route '/gatekeeper/{gatekeeperLog}'
*/
show.get = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:163
* @route '/gatekeeper/{gatekeeperLog}'
*/
show.head = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:163
* @route '/gatekeeper/{gatekeeperLog}'
*/
const showForm = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:163
* @route '/gatekeeper/{gatekeeperLog}'
*/
showForm.get = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:163
* @route '/gatekeeper/{gatekeeperLog}'
*/
showForm.head = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:221
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
export const edit = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/{gatekeeperLog}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:221
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
edit.url = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gatekeeperLog: args }
    }

    if (Array.isArray(args)) {
        args = {
            gatekeeperLog: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        gatekeeperLog: args.gatekeeperLog,
    }

    return edit.definition.url
            .replace('{gatekeeperLog}', parsedArgs.gatekeeperLog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:221
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
edit.get = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:221
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
edit.head = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:221
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
const editForm = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:221
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
editForm.get = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:221
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
editForm.head = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\GatekeeperController::update
* @see app/Http/Controllers/GatekeeperController.php:231
* @route '/gatekeeper/{gatekeeperLog}'
*/
export const update = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/gatekeeper/{gatekeeperLog}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\GatekeeperController::update
* @see app/Http/Controllers/GatekeeperController.php:231
* @route '/gatekeeper/{gatekeeperLog}'
*/
update.url = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gatekeeperLog: args }
    }

    if (Array.isArray(args)) {
        args = {
            gatekeeperLog: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        gatekeeperLog: args.gatekeeperLog,
    }

    return update.definition.url
            .replace('{gatekeeperLog}', parsedArgs.gatekeeperLog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::update
* @see app/Http/Controllers/GatekeeperController.php:231
* @route '/gatekeeper/{gatekeeperLog}'
*/
update.put = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\GatekeeperController::update
* @see app/Http/Controllers/GatekeeperController.php:231
* @route '/gatekeeper/{gatekeeperLog}'
*/
const updateForm = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::update
* @see app/Http/Controllers/GatekeeperController.php:231
* @route '/gatekeeper/{gatekeeperLog}'
*/
updateForm.put = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\GatekeeperController::destroy
* @see app/Http/Controllers/GatekeeperController.php:247
* @route '/gatekeeper/{gatekeeperLog}'
*/
export const destroy = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/gatekeeper/{gatekeeperLog}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\GatekeeperController::destroy
* @see app/Http/Controllers/GatekeeperController.php:247
* @route '/gatekeeper/{gatekeeperLog}'
*/
destroy.url = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gatekeeperLog: args }
    }

    if (Array.isArray(args)) {
        args = {
            gatekeeperLog: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        gatekeeperLog: args.gatekeeperLog,
    }

    return destroy.definition.url
            .replace('{gatekeeperLog}', parsedArgs.gatekeeperLog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::destroy
* @see app/Http/Controllers/GatekeeperController.php:247
* @route '/gatekeeper/{gatekeeperLog}'
*/
destroy.delete = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\GatekeeperController::destroy
* @see app/Http/Controllers/GatekeeperController.php:247
* @route '/gatekeeper/{gatekeeperLog}'
*/
const destroyForm = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::destroy
* @see app/Http/Controllers/GatekeeperController.php:247
* @route '/gatekeeper/{gatekeeperLog}'
*/
destroyForm.delete = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const gatekeeper = {
    index: Object.assign(index, index),
    recordInForm: Object.assign(recordInForm, recordInForm),
    recordIn: Object.assign(recordIn, recordIn),
    recordOutForm: Object.assign(recordOutForm, recordOutForm),
    recordOut: Object.assign(recordOut, recordOut),
    print: Object.assign(print, print),
    exportPdf: Object.assign(exportPdf, exportPdf),
    stats: Object.assign(stats, stats),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default gatekeeper