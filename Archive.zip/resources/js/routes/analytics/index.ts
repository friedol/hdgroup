import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/analytics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

const analytics = {
    dashboard: Object.assign(dashboard, dashboard),
}

export default analytics