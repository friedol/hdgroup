import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PromoCodeController::index
* @see app/Http/Controllers/PromoCodeController.php:13
* @route '/promo-codes'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/promo-codes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PromoCodeController::index
* @see app/Http/Controllers/PromoCodeController.php:13
* @route '/promo-codes'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromoCodeController::index
* @see app/Http/Controllers/PromoCodeController.php:13
* @route '/promo-codes'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PromoCodeController::index
* @see app/Http/Controllers/PromoCodeController.php:13
* @route '/promo-codes'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PromoCodeController::index
* @see app/Http/Controllers/PromoCodeController.php:13
* @route '/promo-codes'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PromoCodeController::index
* @see app/Http/Controllers/PromoCodeController.php:13
* @route '/promo-codes'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PromoCodeController::index
* @see app/Http/Controllers/PromoCodeController.php:13
* @route '/promo-codes'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\PromoCodeController::store
* @see app/Http/Controllers/PromoCodeController.php:22
* @route '/promo-codes'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/promo-codes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PromoCodeController::store
* @see app/Http/Controllers/PromoCodeController.php:22
* @route '/promo-codes'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromoCodeController::store
* @see app/Http/Controllers/PromoCodeController.php:22
* @route '/promo-codes'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PromoCodeController::store
* @see app/Http/Controllers/PromoCodeController.php:22
* @route '/promo-codes'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PromoCodeController::store
* @see app/Http/Controllers/PromoCodeController.php:22
* @route '/promo-codes'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\PromoCodeController::update
* @see app/Http/Controllers/PromoCodeController.php:53
* @route '/promo-codes/{promoCode}'
*/
export const update = (args: { promoCode: number | { id: number } } | [promoCode: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/promo-codes/{promoCode}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PromoCodeController::update
* @see app/Http/Controllers/PromoCodeController.php:53
* @route '/promo-codes/{promoCode}'
*/
update.url = (args: { promoCode: number | { id: number } } | [promoCode: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { promoCode: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { promoCode: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            promoCode: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        promoCode: typeof args.promoCode === 'object'
        ? args.promoCode.id
        : args.promoCode,
    }

    return update.definition.url
            .replace('{promoCode}', parsedArgs.promoCode.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromoCodeController::update
* @see app/Http/Controllers/PromoCodeController.php:53
* @route '/promo-codes/{promoCode}'
*/
update.put = (args: { promoCode: number | { id: number } } | [promoCode: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\PromoCodeController::update
* @see app/Http/Controllers/PromoCodeController.php:53
* @route '/promo-codes/{promoCode}'
*/
const updateForm = (args: { promoCode: number | { id: number } } | [promoCode: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PromoCodeController::update
* @see app/Http/Controllers/PromoCodeController.php:53
* @route '/promo-codes/{promoCode}'
*/
updateForm.put = (args: { promoCode: number | { id: number } } | [promoCode: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\PromoCodeController::destroy
* @see app/Http/Controllers/PromoCodeController.php:74
* @route '/promo-codes/{promoCode}'
*/
export const destroy = (args: { promoCode: number | { id: number } } | [promoCode: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/promo-codes/{promoCode}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PromoCodeController::destroy
* @see app/Http/Controllers/PromoCodeController.php:74
* @route '/promo-codes/{promoCode}'
*/
destroy.url = (args: { promoCode: number | { id: number } } | [promoCode: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { promoCode: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { promoCode: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            promoCode: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        promoCode: typeof args.promoCode === 'object'
        ? args.promoCode.id
        : args.promoCode,
    }

    return destroy.definition.url
            .replace('{promoCode}', parsedArgs.promoCode.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromoCodeController::destroy
* @see app/Http/Controllers/PromoCodeController.php:74
* @route '/promo-codes/{promoCode}'
*/
destroy.delete = (args: { promoCode: number | { id: number } } | [promoCode: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\PromoCodeController::destroy
* @see app/Http/Controllers/PromoCodeController.php:74
* @route '/promo-codes/{promoCode}'
*/
const destroyForm = (args: { promoCode: number | { id: number } } | [promoCode: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PromoCodeController::destroy
* @see app/Http/Controllers/PromoCodeController.php:74
* @route '/promo-codes/{promoCode}'
*/
destroyForm.delete = (args: { promoCode: number | { id: number } } | [promoCode: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const promoCodes = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default promoCodes