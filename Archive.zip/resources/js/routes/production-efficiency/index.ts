import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/production-efficiency',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

const productionEfficiency = {
    dashboard: Object.assign(dashboard, dashboard),
}

export default productionEfficiency