import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\UpcomingOrderController::upcomingOrders
* @see app/Http/Controllers/UpcomingOrderController.php:71
* @route '/upcoming-orders/publish/{product_id}'
*/
export const upcomingOrders = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: upcomingOrders.url(args, options),
    method: 'put',
})

upcomingOrders.definition = {
    methods: ["put"],
    url: '/upcoming-orders/publish/{product_id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UpcomingOrderController::upcomingOrders
* @see app/Http/Controllers/UpcomingOrderController.php:71
* @route '/upcoming-orders/publish/{product_id}'
*/
upcomingOrders.url = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            product_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product_id: args.product_id,
    }

    return upcomingOrders.definition.url
            .replace('{product_id}', parsedArgs.product_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingOrderController::upcomingOrders
* @see app/Http/Controllers/UpcomingOrderController.php:71
* @route '/upcoming-orders/publish/{product_id}'
*/
upcomingOrders.put = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: upcomingOrders.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::upcomingOrders
* @see app/Http/Controllers/UpcomingOrderController.php:71
* @route '/upcoming-orders/publish/{product_id}'
*/
const upcomingOrdersForm = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: upcomingOrders.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingOrderController::upcomingOrders
* @see app/Http/Controllers/UpcomingOrderController.php:71
* @route '/upcoming-orders/publish/{product_id}'
*/
upcomingOrdersForm.put = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: upcomingOrders.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

upcomingOrders.form = upcomingOrdersForm

/**
* @see \App\Http\Controllers\UpcomingProductController::upcomingProducts
* @see app/Http/Controllers/UpcomingProductController.php:273
* @route '/upcoming-products/publish/{product_id}'
*/
export const upcomingProducts = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: upcomingProducts.url(args, options),
    method: 'put',
})

upcomingProducts.definition = {
    methods: ["put"],
    url: '/upcoming-products/publish/{product_id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UpcomingProductController::upcomingProducts
* @see app/Http/Controllers/UpcomingProductController.php:273
* @route '/upcoming-products/publish/{product_id}'
*/
upcomingProducts.url = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            product_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product_id: args.product_id,
    }

    return upcomingProducts.definition.url
            .replace('{product_id}', parsedArgs.product_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingProductController::upcomingProducts
* @see app/Http/Controllers/UpcomingProductController.php:273
* @route '/upcoming-products/publish/{product_id}'
*/
upcomingProducts.put = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: upcomingProducts.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::upcomingProducts
* @see app/Http/Controllers/UpcomingProductController.php:273
* @route '/upcoming-products/publish/{product_id}'
*/
const upcomingProductsForm = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: upcomingProducts.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::upcomingProducts
* @see app/Http/Controllers/UpcomingProductController.php:273
* @route '/upcoming-products/publish/{product_id}'
*/
upcomingProductsForm.put = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: upcomingProducts.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

upcomingProducts.form = upcomingProductsForm

const publish = {
    upcomingOrders: Object.assign(upcomingOrders, upcomingOrders),
    upcomingProducts: Object.assign(upcomingProducts, upcomingProducts),
}

export default publish