import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../wayfinder'
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: login.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
loginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: login.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
loginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: login.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

login.form = loginForm

/**
* @see \App\Http\Controllers\PageController::logout
* @see app/Http/Controllers/PageController.php:993
* @route '/logout'
*/
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PageController::logout
* @see app/Http/Controllers/PageController.php:993
* @route '/logout'
*/
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::logout
* @see app/Http/Controllers/PageController.php:993
* @route '/logout'
*/
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PageController::logout
* @see app/Http/Controllers/PageController.php:993
* @route '/logout'
*/
const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PageController::logout
* @see app/Http/Controllers/PageController.php:993
* @route '/logout'
*/
logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logout.url(options),
    method: 'post',
})

logout.form = logoutForm

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
export const register = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

register.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
register.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
register.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: register.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
registerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
registerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

register.form = registerForm

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

home.form = homeForm

/**
* @see \App\Http\Controllers\HomeController::selectedCategory
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
export const selectedCategory = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: selectedCategory.url(args, options),
    method: 'get',
})

selectedCategory.definition = {
    methods: ["get","head"],
    url: '/category/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::selectedCategory
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
selectedCategory.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return selectedCategory.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::selectedCategory
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
selectedCategory.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: selectedCategory.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::selectedCategory
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
selectedCategory.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: selectedCategory.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::selectedCategory
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
const selectedCategoryForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: selectedCategory.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::selectedCategory
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
selectedCategoryForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: selectedCategory.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::selectedCategory
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
selectedCategoryForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: selectedCategory.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

selectedCategory.form = selectedCategoryForm

/**
* @see \App\Http\Controllers\HomeController::saveFeedback
* @see app/Http/Controllers/HomeController.php:94
* @route '/help/desk/save'
*/
export const saveFeedback = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveFeedback.url(options),
    method: 'post',
})

saveFeedback.definition = {
    methods: ["post"],
    url: '/help/desk/save',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HomeController::saveFeedback
* @see app/Http/Controllers/HomeController.php:94
* @route '/help/desk/save'
*/
saveFeedback.url = (options?: RouteQueryOptions) => {
    return saveFeedback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::saveFeedback
* @see app/Http/Controllers/HomeController.php:94
* @route '/help/desk/save'
*/
saveFeedback.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveFeedback.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HomeController::saveFeedback
* @see app/Http/Controllers/HomeController.php:94
* @route '/help/desk/save'
*/
const saveFeedbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: saveFeedback.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HomeController::saveFeedback
* @see app/Http/Controllers/HomeController.php:94
* @route '/help/desk/save'
*/
saveFeedbackForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: saveFeedback.url(options),
    method: 'post',
})

saveFeedback.form = saveFeedbackForm

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
export const about = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})

about.definition = {
    methods: ["get","head"],
    url: '/about',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
about.url = (options?: RouteQueryOptions) => {
    return about.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
about.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
about.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: about.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
const aboutForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: about.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
aboutForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: about.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
aboutForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: about.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

about.form = aboutForm

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
export const profile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

profile.definition = {
    methods: ["get","head"],
    url: '/profile/show',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
profile.url = (options?: RouteQueryOptions) => {
    return profile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
profile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
profile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profile.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
const profileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
profileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
profileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

profile.form = profileForm

/**
* @see \App\Http\Controllers\CartController::shop
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
export const shop = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: shop.url(options),
    method: 'get',
})

shop.definition = {
    methods: ["get","head"],
    url: '/shop',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::shop
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
shop.url = (options?: RouteQueryOptions) => {
    return shop.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::shop
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
shop.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: shop.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::shop
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
shop.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: shop.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::shop
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
const shopForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: shop.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::shop
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
shopForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: shop.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::shop
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
shopForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: shop.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

shop.form = shopForm

/**
* @see \App\Http\Controllers\CartController::cart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
export const cart = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cart.url(options),
    method: 'get',
})

cart.definition = {
    methods: ["get","head"],
    url: '/cart',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::cart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
cart.url = (options?: RouteQueryOptions) => {
    return cart.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::cart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
cart.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cart.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::cart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
cart.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cart.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::cart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
const cartForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cart.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::cart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
cartForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cart.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::cart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
cartForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cart.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

cart.form = cartForm

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
export const contact = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})

contact.definition = {
    methods: ["get","head"],
    url: '/contact',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
contact.url = (options?: RouteQueryOptions) => {
    return contact.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
contact.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
contact.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contact.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
const contactForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: contact.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
contactForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: contact.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
contactForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: contact.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

contact.form = contactForm

/**
* @see \App\Http\Controllers\CartController::orderProduct
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
export const orderProduct = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orderProduct.url(args, options),
    method: 'get',
})

orderProduct.definition = {
    methods: ["get","head"],
    url: '/order-product/{product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::orderProduct
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
orderProduct.url = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: args.product,
    }

    return orderProduct.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::orderProduct
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
orderProduct.get = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orderProduct.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::orderProduct
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
orderProduct.head = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orderProduct.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::orderProduct
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
const orderProductForm = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orderProduct.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::orderProduct
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
orderProductForm.get = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orderProduct.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::orderProduct
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
orderProductForm.head = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orderProduct.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

orderProduct.form = orderProductForm

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
export const order_recommended_edit = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_recommended_edit.url(args, options),
    method: 'get',
})

order_recommended_edit.definition = {
    methods: ["get","head"],
    url: '/order_recommended/{unique_id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
order_recommended_edit.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return order_recommended_edit.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
order_recommended_edit.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_recommended_edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
order_recommended_edit.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: order_recommended_edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
const order_recommended_editForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
order_recommended_editForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
order_recommended_editForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

order_recommended_edit.form = order_recommended_editForm

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
export const order_recommended_show = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_recommended_show.url(args, options),
    method: 'get',
})

order_recommended_show.definition = {
    methods: ["get","head"],
    url: '/order_recommended/{unique_id}/show',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
order_recommended_show.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return order_recommended_show.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
order_recommended_show.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_recommended_show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
order_recommended_show.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: order_recommended_show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
const order_recommended_showForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
order_recommended_showForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
order_recommended_showForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

order_recommended_show.form = order_recommended_showForm

/**
* @see \App\Http\Controllers\PageController::order_recommended_update
* @see app/Http/Controllers/PageController.php:595
* @route '/order_recommended/{unique_id}/update'
*/
export const order_recommended_update = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: order_recommended_update.url(args, options),
    method: 'put',
})

order_recommended_update.definition = {
    methods: ["put"],
    url: '/order_recommended/{unique_id}/update',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PageController::order_recommended_update
* @see app/Http/Controllers/PageController.php:595
* @route '/order_recommended/{unique_id}/update'
*/
order_recommended_update.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return order_recommended_update.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::order_recommended_update
* @see app/Http/Controllers/PageController.php:595
* @route '/order_recommended/{unique_id}/update'
*/
order_recommended_update.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: order_recommended_update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_update
* @see app/Http/Controllers/PageController.php:595
* @route '/order_recommended/{unique_id}/update'
*/
const order_recommended_updateForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: order_recommended_update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_update
* @see app/Http/Controllers/PageController.php:595
* @route '/order_recommended/{unique_id}/update'
*/
order_recommended_updateForm.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: order_recommended_update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

order_recommended_update.form = order_recommended_updateForm

/**
* @see \App\Http\Controllers\ExportController::exports_add_more
* @see app/Http/Controllers/ExportController.php:320
* @route '/exports_add_more'
*/
export const exports_add_more = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exports_add_more.url(options),
    method: 'post',
})

exports_add_more.definition = {
    methods: ["post"],
    url: '/exports_add_more',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ExportController::exports_add_more
* @see app/Http/Controllers/ExportController.php:320
* @route '/exports_add_more'
*/
exports_add_more.url = (options?: RouteQueryOptions) => {
    return exports_add_more.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::exports_add_more
* @see app/Http/Controllers/ExportController.php:320
* @route '/exports_add_more'
*/
exports_add_more.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exports_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExportController::exports_add_more
* @see app/Http/Controllers/ExportController.php:320
* @route '/exports_add_more'
*/
const exports_add_moreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exports_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExportController::exports_add_more
* @see app/Http/Controllers/ExportController.php:320
* @route '/exports_add_more'
*/
exports_add_moreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exports_add_more.url(options),
    method: 'post',
})

exports_add_more.form = exports_add_moreForm

/**
* @see \App\Http\Controllers\ExportController::exportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
export const exportStatistics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportStatistics.url(options),
    method: 'get',
})

exportStatistics.definition = {
    methods: ["get","head"],
    url: '/export-statistics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExportController::exportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
exportStatistics.url = (options?: RouteQueryOptions) => {
    return exportStatistics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::exportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
exportStatistics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportStatistics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::exportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
exportStatistics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportStatistics.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExportController::exportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
const exportStatisticsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportStatistics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::exportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
exportStatisticsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportStatistics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::exportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
exportStatisticsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportStatistics.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

exportStatistics.form = exportStatisticsForm

/**
* @see \App\Http\Controllers\ExportController::exports_edit_exports_status
* @see app/Http/Controllers/ExportController.php:112
* @route '/exported-products/editstatus/{unique_id}'
*/
export const exports_edit_exports_status = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: exports_edit_exports_status.url(args, options),
    method: 'put',
})

exports_edit_exports_status.definition = {
    methods: ["put"],
    url: '/exported-products/editstatus/{unique_id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ExportController::exports_edit_exports_status
* @see app/Http/Controllers/ExportController.php:112
* @route '/exported-products/editstatus/{unique_id}'
*/
exports_edit_exports_status.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return exports_edit_exports_status.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::exports_edit_exports_status
* @see app/Http/Controllers/ExportController.php:112
* @route '/exported-products/editstatus/{unique_id}'
*/
exports_edit_exports_status.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: exports_edit_exports_status.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ExportController::exports_edit_exports_status
* @see app/Http/Controllers/ExportController.php:112
* @route '/exported-products/editstatus/{unique_id}'
*/
const exports_edit_exports_statusForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exports_edit_exports_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExportController::exports_edit_exports_status
* @see app/Http/Controllers/ExportController.php:112
* @route '/exported-products/editstatus/{unique_id}'
*/
exports_edit_exports_statusForm.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exports_edit_exports_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

exports_edit_exports_status.form = exports_edit_exports_statusForm

/**
* @see \App\Http\Controllers\ExportController::exports_change_to_loan
* @see app/Http/Controllers/ExportController.php:71
* @route '/exported-products/change_to_loan/{unique_id}'
*/
export const exports_change_to_loan = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: exports_change_to_loan.url(args, options),
    method: 'put',
})

exports_change_to_loan.definition = {
    methods: ["put"],
    url: '/exported-products/change_to_loan/{unique_id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ExportController::exports_change_to_loan
* @see app/Http/Controllers/ExportController.php:71
* @route '/exported-products/change_to_loan/{unique_id}'
*/
exports_change_to_loan.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return exports_change_to_loan.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::exports_change_to_loan
* @see app/Http/Controllers/ExportController.php:71
* @route '/exported-products/change_to_loan/{unique_id}'
*/
exports_change_to_loan.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: exports_change_to_loan.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ExportController::exports_change_to_loan
* @see app/Http/Controllers/ExportController.php:71
* @route '/exported-products/change_to_loan/{unique_id}'
*/
const exports_change_to_loanForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exports_change_to_loan.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExportController::exports_change_to_loan
* @see app/Http/Controllers/ExportController.php:71
* @route '/exported-products/change_to_loan/{unique_id}'
*/
exports_change_to_loanForm.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exports_change_to_loan.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

exports_change_to_loan.form = exports_change_to_loanForm

/**
* @see \App\Http\Controllers\LoanController::loans_add_more
* @see app/Http/Controllers/LoanController.php:336
* @route '/loans_add_more'
*/
export const loans_add_more = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loans_add_more.url(options),
    method: 'post',
})

loans_add_more.definition = {
    methods: ["post"],
    url: '/loans_add_more',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LoanController::loans_add_more
* @see app/Http/Controllers/LoanController.php:336
* @route '/loans_add_more'
*/
loans_add_more.url = (options?: RouteQueryOptions) => {
    return loans_add_more.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::loans_add_more
* @see app/Http/Controllers/LoanController.php:336
* @route '/loans_add_more'
*/
loans_add_more.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loans_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::loans_add_more
* @see app/Http/Controllers/LoanController.php:336
* @route '/loans_add_more'
*/
const loans_add_moreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loans_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::loans_add_more
* @see app/Http/Controllers/LoanController.php:336
* @route '/loans_add_more'
*/
loans_add_moreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loans_add_more.url(options),
    method: 'post',
})

loans_add_more.form = loans_add_moreForm

/**
* @see \App\Http\Controllers\LoanController::loans_edit_status
* @see app/Http/Controllers/LoanController.php:465
* @route '/loans/editstatus/{unique_id}'
*/
export const loans_edit_status = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: loans_edit_status.url(args, options),
    method: 'put',
})

loans_edit_status.definition = {
    methods: ["put"],
    url: '/loans/editstatus/{unique_id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LoanController::loans_edit_status
* @see app/Http/Controllers/LoanController.php:465
* @route '/loans/editstatus/{unique_id}'
*/
loans_edit_status.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return loans_edit_status.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::loans_edit_status
* @see app/Http/Controllers/LoanController.php:465
* @route '/loans/editstatus/{unique_id}'
*/
loans_edit_status.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: loans_edit_status.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\LoanController::loans_edit_status
* @see app/Http/Controllers/LoanController.php:465
* @route '/loans/editstatus/{unique_id}'
*/
const loans_edit_statusForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loans_edit_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::loans_edit_status
* @see app/Http/Controllers/LoanController.php:465
* @route '/loans/editstatus/{unique_id}'
*/
loans_edit_statusForm.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loans_edit_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

loans_edit_status.form = loans_edit_statusForm

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_add_more
* @see app/Http/Controllers/CustomerOrderController.php:852
* @route '/orders_add_more'
*/
export const orders_add_more = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: orders_add_more.url(options),
    method: 'post',
})

orders_add_more.definition = {
    methods: ["post"],
    url: '/orders_add_more',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_add_more
* @see app/Http/Controllers/CustomerOrderController.php:852
* @route '/orders_add_more'
*/
orders_add_more.url = (options?: RouteQueryOptions) => {
    return orders_add_more.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_add_more
* @see app/Http/Controllers/CustomerOrderController.php:852
* @route '/orders_add_more'
*/
orders_add_more.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: orders_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_add_more
* @see app/Http/Controllers/CustomerOrderController.php:852
* @route '/orders_add_more'
*/
const orders_add_moreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: orders_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_add_more
* @see app/Http/Controllers/CustomerOrderController.php:852
* @route '/orders_add_more'
*/
orders_add_moreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: orders_add_more.url(options),
    method: 'post',
})

orders_add_more.form = orders_add_moreForm

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_edit_orders_status
* @see app/Http/Controllers/CustomerOrderController.php:685
* @route '/orders/editstatus/{unique_id}'
*/
export const orders_edit_orders_status = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: orders_edit_orders_status.url(args, options),
    method: 'put',
})

orders_edit_orders_status.definition = {
    methods: ["put"],
    url: '/orders/editstatus/{unique_id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_edit_orders_status
* @see app/Http/Controllers/CustomerOrderController.php:685
* @route '/orders/editstatus/{unique_id}'
*/
orders_edit_orders_status.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return orders_edit_orders_status.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_edit_orders_status
* @see app/Http/Controllers/CustomerOrderController.php:685
* @route '/orders/editstatus/{unique_id}'
*/
orders_edit_orders_status.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: orders_edit_orders_status.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_edit_orders_status
* @see app/Http/Controllers/CustomerOrderController.php:685
* @route '/orders/editstatus/{unique_id}'
*/
const orders_edit_orders_statusForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: orders_edit_orders_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_edit_orders_status
* @see app/Http/Controllers/CustomerOrderController.php:685
* @route '/orders/editstatus/{unique_id}'
*/
orders_edit_orders_statusForm.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: orders_edit_orders_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

orders_edit_orders_status.form = orders_edit_orders_statusForm

/**
* @see \App\Http\Controllers\ExpensesController::expenses_reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
export const expenses_reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expenses_reports.url(options),
    method: 'get',
})

expenses_reports.definition = {
    methods: ["get","head"],
    url: '/expenses_reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpensesController::expenses_reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
expenses_reports.url = (options?: RouteQueryOptions) => {
    return expenses_reports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::expenses_reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
expenses_reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expenses_reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::expenses_reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
expenses_reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: expenses_reports.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExpensesController::expenses_reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
const expenses_reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: expenses_reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::expenses_reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
expenses_reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: expenses_reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::expenses_reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
expenses_reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: expenses_reports.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

expenses_reports.form = expenses_reportsForm

/**
* @see \App\Http\Controllers\LoanController::loans_reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
export const loans_reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loans_reports.url(options),
    method: 'get',
})

loans_reports.definition = {
    methods: ["get","head"],
    url: '/loans_reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::loans_reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
loans_reports.url = (options?: RouteQueryOptions) => {
    return loans_reports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::loans_reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
loans_reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loans_reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::loans_reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
loans_reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: loans_reports.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LoanController::loans_reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
const loans_reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loans_reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::loans_reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
loans_reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loans_reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::loans_reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
loans_reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loans_reports.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

loans_reports.form = loans_reportsForm
