import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:17
* @route '/staff-performance'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/staff-performance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:17
* @route '/staff-performance'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:17
* @route '/staff-performance'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:17
* @route '/staff-performance'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:17
* @route '/staff-performance'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:17
* @route '/staff-performance'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:17
* @route '/staff-performance'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

const staffPerformance = {
    dashboard: Object.assign(dashboard, dashboard),
}

export default staffPerformance