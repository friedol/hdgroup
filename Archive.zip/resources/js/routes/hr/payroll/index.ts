import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\HumanResourceController::process
* @see app/Http/Controllers/HumanResourceController.php:100
* @route '/hr/payroll/process'
*/
export const process = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: process.url(options),
    method: 'post',
})

process.definition = {
    methods: ["post"],
    url: '/hr/payroll/process',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HumanResourceController::process
* @see app/Http/Controllers/HumanResourceController.php:100
* @route '/hr/payroll/process'
*/
process.url = (options?: RouteQueryOptions) => {
    return process.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HumanResourceController::process
* @see app/Http/Controllers/HumanResourceController.php:100
* @route '/hr/payroll/process'
*/
process.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: process.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HumanResourceController::process
* @see app/Http/Controllers/HumanResourceController.php:100
* @route '/hr/payroll/process'
*/
const processForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: process.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HumanResourceController::process
* @see app/Http/Controllers/HumanResourceController.php:100
* @route '/hr/payroll/process'
*/
processForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: process.url(options),
    method: 'post',
})

process.form = processForm

const payroll = {
    process: Object.assign(process, process),
}

export default payroll