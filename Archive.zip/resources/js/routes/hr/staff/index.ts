import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\HumanResourceController::updateSalary
* @see app/Http/Controllers/HumanResourceController.php:158
* @route '/hr/staff/{id}/update-salary'
*/
export const updateSalary = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSalary.url(args, options),
    method: 'post',
})

updateSalary.definition = {
    methods: ["post"],
    url: '/hr/staff/{id}/update-salary',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HumanResourceController::updateSalary
* @see app/Http/Controllers/HumanResourceController.php:158
* @route '/hr/staff/{id}/update-salary'
*/
updateSalary.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateSalary.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HumanResourceController::updateSalary
* @see app/Http/Controllers/HumanResourceController.php:158
* @route '/hr/staff/{id}/update-salary'
*/
updateSalary.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSalary.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HumanResourceController::updateSalary
* @see app/Http/Controllers/HumanResourceController.php:158
* @route '/hr/staff/{id}/update-salary'
*/
const updateSalaryForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateSalary.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HumanResourceController::updateSalary
* @see app/Http/Controllers/HumanResourceController.php:158
* @route '/hr/staff/{id}/update-salary'
*/
updateSalaryForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateSalary.url(args, options),
    method: 'post',
})

updateSalary.form = updateSalaryForm

const staff = {
    updateSalary: Object.assign(updateSalary, updateSalary),
}

export default staff