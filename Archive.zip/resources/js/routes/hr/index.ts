import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import payrollCe309f from './payroll'
import staff from './staff'
import departments from './departments'
/**
* @see \App\Http\Controllers\HumanResourceController::payroll
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
export const payroll = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payroll.url(options),
    method: 'get',
})

payroll.definition = {
    methods: ["get","head"],
    url: '/hr/payroll',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HumanResourceController::payroll
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
payroll.url = (options?: RouteQueryOptions) => {
    return payroll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HumanResourceController::payroll
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
payroll.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payroll.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::payroll
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
payroll.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: payroll.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HumanResourceController::payroll
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
const payrollForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payroll.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::payroll
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
payrollForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payroll.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::payroll
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
payrollForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payroll.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

payroll.form = payrollForm

const hr = {
    payroll: Object.assign(payroll, payrollCe309f),
    staff: Object.assign(staff, staff),
    departments: Object.assign(departments, departments),
}

export default hr