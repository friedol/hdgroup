import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
export const track = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track.url(args, options),
    method: 'get',
})

track.definition = {
    methods: ["get","head"],
    url: '/track/{deliveryNumber}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
track.url = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deliveryNumber: args }
    }

    if (Array.isArray(args)) {
        args = {
            deliveryNumber: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        deliveryNumber: args.deliveryNumber,
    }

    return track.definition.url
            .replace('{deliveryNumber}', parsedArgs.deliveryNumber.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
track.get = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
track.head = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: track.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
const trackForm = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
trackForm.get = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
trackForm.head = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

track.form = trackForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::accept
* @see app/Http/Controllers/DeliveryTrackingController.php:82
* @route '/deliveries/{delivery}/accept'
*/
export const accept = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: accept.url(args, options),
    method: 'put',
})

accept.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/accept',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::accept
* @see app/Http/Controllers/DeliveryTrackingController.php:82
* @route '/deliveries/{delivery}/accept'
*/
accept.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return accept.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::accept
* @see app/Http/Controllers/DeliveryTrackingController.php:82
* @route '/deliveries/{delivery}/accept'
*/
accept.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: accept.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::accept
* @see app/Http/Controllers/DeliveryTrackingController.php:82
* @route '/deliveries/{delivery}/accept'
*/
const acceptForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: accept.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::accept
* @see app/Http/Controllers/DeliveryTrackingController.php:82
* @route '/deliveries/{delivery}/accept'
*/
acceptForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: accept.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

accept.form = acceptForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::pickup
* @see app/Http/Controllers/DeliveryTrackingController.php:98
* @route '/deliveries/{delivery}/pickup'
*/
export const pickup = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: pickup.url(args, options),
    method: 'put',
})

pickup.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/pickup',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::pickup
* @see app/Http/Controllers/DeliveryTrackingController.php:98
* @route '/deliveries/{delivery}/pickup'
*/
pickup.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return pickup.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::pickup
* @see app/Http/Controllers/DeliveryTrackingController.php:98
* @route '/deliveries/{delivery}/pickup'
*/
pickup.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: pickup.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::pickup
* @see app/Http/Controllers/DeliveryTrackingController.php:98
* @route '/deliveries/{delivery}/pickup'
*/
const pickupForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pickup.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::pickup
* @see app/Http/Controllers/DeliveryTrackingController.php:98
* @route '/deliveries/{delivery}/pickup'
*/
pickupForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pickup.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

pickup.form = pickupForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::inTransit
* @see app/Http/Controllers/DeliveryTrackingController.php:132
* @route '/deliveries/{delivery}/in-transit'
*/
export const inTransit = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: inTransit.url(args, options),
    method: 'put',
})

inTransit.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/in-transit',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::inTransit
* @see app/Http/Controllers/DeliveryTrackingController.php:132
* @route '/deliveries/{delivery}/in-transit'
*/
inTransit.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return inTransit.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::inTransit
* @see app/Http/Controllers/DeliveryTrackingController.php:132
* @route '/deliveries/{delivery}/in-transit'
*/
inTransit.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: inTransit.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::inTransit
* @see app/Http/Controllers/DeliveryTrackingController.php:132
* @route '/deliveries/{delivery}/in-transit'
*/
const inTransitForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: inTransit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::inTransit
* @see app/Http/Controllers/DeliveryTrackingController.php:132
* @route '/deliveries/{delivery}/in-transit'
*/
inTransitForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: inTransit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

inTransit.form = inTransitForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::complete
* @see app/Http/Controllers/DeliveryTrackingController.php:164
* @route '/deliveries/{delivery}/complete'
*/
export const complete = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: complete.url(args, options),
    method: 'put',
})

complete.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/complete',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::complete
* @see app/Http/Controllers/DeliveryTrackingController.php:164
* @route '/deliveries/{delivery}/complete'
*/
complete.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return complete.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::complete
* @see app/Http/Controllers/DeliveryTrackingController.php:164
* @route '/deliveries/{delivery}/complete'
*/
complete.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: complete.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::complete
* @see app/Http/Controllers/DeliveryTrackingController.php:164
* @route '/deliveries/{delivery}/complete'
*/
const completeForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: complete.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::complete
* @see app/Http/Controllers/DeliveryTrackingController.php:164
* @route '/deliveries/{delivery}/complete'
*/
completeForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: complete.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

complete.form = completeForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::fail
* @see app/Http/Controllers/DeliveryTrackingController.php:224
* @route '/deliveries/{delivery}/fail'
*/
export const fail = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: fail.url(args, options),
    method: 'put',
})

fail.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/fail',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::fail
* @see app/Http/Controllers/DeliveryTrackingController.php:224
* @route '/deliveries/{delivery}/fail'
*/
fail.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return fail.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::fail
* @see app/Http/Controllers/DeliveryTrackingController.php:224
* @route '/deliveries/{delivery}/fail'
*/
fail.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: fail.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::fail
* @see app/Http/Controllers/DeliveryTrackingController.php:224
* @route '/deliveries/{delivery}/fail'
*/
const failForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: fail.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::fail
* @see app/Http/Controllers/DeliveryTrackingController.php:224
* @route '/deliveries/{delivery}/fail'
*/
failForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: fail.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

fail.form = failForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::rate
* @see app/Http/Controllers/DeliveryTrackingController.php:246
* @route '/deliveries/{delivery}/rate'
*/
export const rate = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: rate.url(args, options),
    method: 'put',
})

rate.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/rate',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::rate
* @see app/Http/Controllers/DeliveryTrackingController.php:246
* @route '/deliveries/{delivery}/rate'
*/
rate.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return rate.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::rate
* @see app/Http/Controllers/DeliveryTrackingController.php:246
* @route '/deliveries/{delivery}/rate'
*/
rate.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: rate.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::rate
* @see app/Http/Controllers/DeliveryTrackingController.php:246
* @route '/deliveries/{delivery}/rate'
*/
const rateForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::rate
* @see app/Http/Controllers/DeliveryTrackingController.php:246
* @route '/deliveries/{delivery}/rate'
*/
rateForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

rate.form = rateForm

const delivery = {
    track: Object.assign(track, track),
    accept: Object.assign(accept, accept),
    pickup: Object.assign(pickup, pickup),
    inTransit: Object.assign(inTransit, inTransit),
    complete: Object.assign(complete, complete),
    fail: Object.assign(fail, fail),
    rate: Object.assign(rate, rate),
}

export default delivery