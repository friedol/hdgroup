import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\DeliveryTrackingController::data
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
export const data = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(args, options),
    method: 'get',
})

data.definition = {
    methods: ["get","head"],
    url: '/api/delivery/{deliveryNumber}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::data
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
data.url = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deliveryNumber: args }
    }

    if (Array.isArray(args)) {
        args = {
            deliveryNumber: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        deliveryNumber: args.deliveryNumber,
    }

    return data.definition.url
            .replace('{deliveryNumber}', parsedArgs.deliveryNumber.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::data
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
data.get = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::data
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
data.head = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: data.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::data
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
const dataForm = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: data.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::data
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
dataForm.get = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: data.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::data
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
dataForm.head = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: data.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

data.form = dataForm

const delivery = {
    data: Object.assign(data, data),
}

export default delivery