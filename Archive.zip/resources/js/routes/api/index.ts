import delivery from './delivery'

const api = {
    delivery: Object.assign(delivery, delivery),
}

export default api