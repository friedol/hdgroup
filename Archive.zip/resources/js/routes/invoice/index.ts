import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PosController::share
* @see app/Http/Controllers/PosController.php:819
* @route '/invoice/receipt/{invoice}'
*/
export const share = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: share.url(args, options),
    method: 'get',
})

share.definition = {
    methods: ["get","head"],
    url: '/invoice/receipt/{invoice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::share
* @see app/Http/Controllers/PosController.php:819
* @route '/invoice/receipt/{invoice}'
*/
share.url = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

    if (Array.isArray(args)) {
        args = {
            invoice: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        invoice: args.invoice,
    }

    return share.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::share
* @see app/Http/Controllers/PosController.php:819
* @route '/invoice/receipt/{invoice}'
*/
share.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: share.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::share
* @see app/Http/Controllers/PosController.php:819
* @route '/invoice/receipt/{invoice}'
*/
share.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: share.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::share
* @see app/Http/Controllers/PosController.php:819
* @route '/invoice/receipt/{invoice}'
*/
const shareForm = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: share.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::share
* @see app/Http/Controllers/PosController.php:819
* @route '/invoice/receipt/{invoice}'
*/
shareForm.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: share.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::share
* @see app/Http/Controllers/PosController.php:819
* @route '/invoice/receipt/{invoice}'
*/
shareForm.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: share.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

share.form = shareForm

const invoice = {
    share: Object.assign(share, share),
}

export default invoice