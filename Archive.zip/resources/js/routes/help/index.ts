import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\HomeController::desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
export const desk = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: desk.url(options),
    method: 'get',
})

desk.definition = {
    methods: ["get","head"],
    url: '/help/desk',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
desk.url = (options?: RouteQueryOptions) => {
    return desk.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
desk.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: desk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
desk.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: desk.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
const deskForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: desk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
deskForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: desk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
deskForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: desk.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

desk.form = deskForm

const help = {
    desk: Object.assign(desk, desk),
}

export default help