import finance from './finance'
import customerDataCenter from './customer-data-center'
import heroSlides from './hero-slides'
import popupAds from './popup-ads'

const admin = {
    finance: Object.assign(finance, finance),
    customerDataCenter: Object.assign(customerDataCenter, customerDataCenter),
    heroSlides: Object.assign(heroSlides, heroSlides),
    popupAds: Object.assign(popupAds, popupAds),
}

export default admin