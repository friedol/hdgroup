import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
export const voucher = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: voucher.url(args, options),
    method: 'get',
})

voucher.definition = {
    methods: ["get","head"],
    url: '/finance/expenses/{expense}/voucher',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
voucher.url = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expense: args }
    }

    if (Array.isArray(args)) {
        args = {
            expense: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        expense: args.expense,
    }

    return voucher.definition.url
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
voucher.get = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: voucher.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
voucher.head = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: voucher.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
const voucherForm = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
voucherForm.get = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
voucherForm.head = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

voucher.form = voucherForm

const expenses = {
    voucher: Object.assign(voucher, voucher),
}

export default expenses