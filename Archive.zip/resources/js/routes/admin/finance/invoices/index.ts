import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PosController::receipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
export const receipt = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipt.url(args, options),
    method: 'get',
})

receipt.definition = {
    methods: ["get","head"],
    url: '/finance/invoices/{invoice}/receipt',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::receipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
receipt.url = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

    if (Array.isArray(args)) {
        args = {
            invoice: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        invoice: args.invoice,
    }

    return receipt.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::receipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
receipt.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipt.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::receipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
receipt.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: receipt.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::receipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
const receiptForm = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipt.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::receipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
receiptForm.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipt.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::receipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
receiptForm.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipt.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

receipt.form = receiptForm

const invoices = {
    receipt: Object.assign(receipt, receipt),
}

export default invoices