import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FinancialAnalyticsController::print
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
export const print = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/finance/cash-flow/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::print
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
print.url = (options?: RouteQueryOptions) => {
    return print.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::print
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
print.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::print
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
print.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::print
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
const printForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::print
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
printForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::print
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
printForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

print.form = printForm

const cashFlow = {
    print: Object.assign(print, print),
}

export default cashFlow