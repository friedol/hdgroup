import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import cashFlow008db6 from './cash-flow'
import dailyReport69f7b5 from './daily-report'
import balanceSheetBd94f5 from './balance-sheet'
import invoices from './invoices'
import expenses from './expenses'
/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/finance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlow
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
export const cashFlow = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cashFlow.url(options),
    method: 'get',
})

cashFlow.definition = {
    methods: ["get","head"],
    url: '/finance/cash-flow',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlow
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
cashFlow.url = (options?: RouteQueryOptions) => {
    return cashFlow.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlow
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
cashFlow.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cashFlow.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlow
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
cashFlow.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cashFlow.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlow
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
const cashFlowForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashFlow.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlow
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
cashFlowForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashFlow.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlow
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
cashFlowForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashFlow.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

cashFlow.form = cashFlowForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
export const dailyReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyReport.url(options),
    method: 'get',
})

dailyReport.definition = {
    methods: ["get","head"],
    url: '/finance/daily-report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
dailyReport.url = (options?: RouteQueryOptions) => {
    return dailyReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
dailyReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyReport.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
dailyReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dailyReport.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
const dailyReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReport.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
dailyReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReport.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
dailyReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReport.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dailyReport.form = dailyReportForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
export const balanceSheet = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balanceSheet.url(options),
    method: 'get',
})

balanceSheet.definition = {
    methods: ["get","head"],
    url: '/finance/balance-sheet',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
balanceSheet.url = (options?: RouteQueryOptions) => {
    return balanceSheet.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
balanceSheet.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balanceSheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
balanceSheet.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: balanceSheet.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
const balanceSheetForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balanceSheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
balanceSheetForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balanceSheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
balanceSheetForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balanceSheet.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

balanceSheet.form = balanceSheetForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
export const reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

reports.definition = {
    methods: ["get","head"],
    url: '/finance/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
reports.url = (options?: RouteQueryOptions) => {
    return reports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reports.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
const reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

reports.form = reportsForm

const finance = {
    dashboard: Object.assign(dashboard, dashboard),
    cashFlow: Object.assign(cashFlow, cashFlow008db6),
    dailyReport: Object.assign(dailyReport, dailyReport69f7b5),
    balanceSheet: Object.assign(balanceSheet, balanceSheetBd94f5),
    reports: Object.assign(reports, reports),
    invoices: Object.assign(invoices, invoices),
    expenses: Object.assign(expenses, expenses),
}

export default finance