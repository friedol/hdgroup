import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FinancialAnalyticsController::pdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
export const pdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/finance/daily-report/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::pdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
pdf.url = (options?: RouteQueryOptions) => {
    return pdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::pdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
pdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::pdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
pdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::pdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
const pdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::pdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
pdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::pdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
pdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

pdf.form = pdfForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::download
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
export const download = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/finance/daily-report/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::download
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
download.url = (options?: RouteQueryOptions) => {
    return download.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::download
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
download.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::download
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
download.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::download
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
const downloadForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::download
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
downloadForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::download
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
downloadForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

download.form = downloadForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::printPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
export const printPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printPdf.url(options),
    method: 'get',
})

printPdf.definition = {
    methods: ["get","head"],
    url: '/finance/daily-report/print-pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::printPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
printPdf.url = (options?: RouteQueryOptions) => {
    return printPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::printPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
printPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::printPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
printPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printPdf.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::printPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
const printPdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::printPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
printPdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::printPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
printPdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printPdf.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

printPdf.form = printPdfForm

const dailyReport = {
    pdf: Object.assign(pdf, pdf),
    download: Object.assign(download, download),
    printPdf: Object.assign(printPdf, printPdf),
}

export default dailyReport