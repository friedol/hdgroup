import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import followUp from './follow-up'
import followUpDate from './follow-up-date'
/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::index
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:27
* @route '/customer-data-center'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/customer-data-center',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::index
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:27
* @route '/customer-data-center'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::index
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:27
* @route '/customer-data-center'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::index
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:27
* @route '/customer-data-center'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::index
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:27
* @route '/customer-data-center'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::index
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:27
* @route '/customer-data-center'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::index
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:27
* @route '/customer-data-center'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::syncAll
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:150
* @route '/customer-data-center/refresh-all'
*/
export const syncAll = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: syncAll.url(options),
    method: 'post',
})

syncAll.definition = {
    methods: ["post"],
    url: '/customer-data-center/refresh-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::syncAll
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:150
* @route '/customer-data-center/refresh-all'
*/
syncAll.url = (options?: RouteQueryOptions) => {
    return syncAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::syncAll
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:150
* @route '/customer-data-center/refresh-all'
*/
syncAll.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: syncAll.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::syncAll
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:150
* @route '/customer-data-center/refresh-all'
*/
const syncAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: syncAll.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::syncAll
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:150
* @route '/customer-data-center/refresh-all'
*/
syncAllForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: syncAll.url(options),
    method: 'post',
})

syncAll.form = syncAllForm

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::show
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:69
* @route '/customer-data-center/{customer}'
*/
export const show = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/customer-data-center/{customer}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::show
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:69
* @route '/customer-data-center/{customer}'
*/
show.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return show.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::show
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:69
* @route '/customer-data-center/{customer}'
*/
show.get = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::show
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:69
* @route '/customer-data-center/{customer}'
*/
show.head = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::show
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:69
* @route '/customer-data-center/{customer}'
*/
const showForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::show
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:69
* @route '/customer-data-center/{customer}'
*/
showForm.get = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::show
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:69
* @route '/customer-data-center/{customer}'
*/
showForm.head = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::refresh
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:141
* @route '/customer-data-center/{customer}/refresh'
*/
export const refresh = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refresh.url(args, options),
    method: 'post',
})

refresh.definition = {
    methods: ["post"],
    url: '/customer-data-center/{customer}/refresh',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::refresh
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:141
* @route '/customer-data-center/{customer}/refresh'
*/
refresh.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return refresh.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::refresh
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:141
* @route '/customer-data-center/{customer}/refresh'
*/
refresh.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refresh.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::refresh
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:141
* @route '/customer-data-center/{customer}/refresh'
*/
const refreshForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: refresh.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CustomerDataCenterController::refresh
* @see app/Http/Controllers/Admin/CustomerDataCenterController.php:141
* @route '/customer-data-center/{customer}/refresh'
*/
refreshForm.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: refresh.url(args, options),
    method: 'post',
})

refresh.form = refreshForm

const customerDataCenter = {
    index: Object.assign(index, index),
    syncAll: Object.assign(syncAll, syncAll),
    show: Object.assign(show, show),
    refresh: Object.assign(refresh, refresh),
    followUp: Object.assign(followUp, followUp),
    followUpDate: Object.assign(followUpDate, followUpDate),
}

export default customerDataCenter