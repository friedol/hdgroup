import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see routes/other.php:30
* @route '/email/verification-notification'
*/
export const customer = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: customer.url(options),
    method: 'post',
})

customer.definition = {
    methods: ["post"],
    url: '/email/verification-notification',
} satisfies RouteDefinition<["post"]>

/**
* @see routes/other.php:30
* @route '/email/verification-notification'
*/
customer.url = (options?: RouteQueryOptions) => {
    return customer.definition.url + queryParams(options)
}

/**
* @see routes/other.php:30
* @route '/email/verification-notification'
*/
customer.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: customer.url(options),
    method: 'post',
})

/**
* @see routes/other.php:30
* @route '/email/verification-notification'
*/
const customerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: customer.url(options),
    method: 'post',
})

/**
* @see routes/other.php:30
* @route '/email/verification-notification'
*/
customerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: customer.url(options),
    method: 'post',
})

customer.form = customerForm

const send = {
    customer: Object.assign(customer, customer),
}

export default send