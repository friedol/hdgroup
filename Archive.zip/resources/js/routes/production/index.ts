import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import rollBasedAaac41 from './roll-based'
import benchmarks from './benchmarks'
import ordersB47e5f from './orders'
/**
* @see \App\Http\Controllers\RollProductionController::rollBased
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
export const rollBased = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rollBased.url(options),
    method: 'get',
})

rollBased.definition = {
    methods: ["get","head"],
    url: '/production/roll-based',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RollProductionController::rollBased
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
rollBased.url = (options?: RouteQueryOptions) => {
    return rollBased.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RollProductionController::rollBased
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
rollBased.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rollBased.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RollProductionController::rollBased
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
rollBased.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: rollBased.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RollProductionController::rollBased
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
const rollBasedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rollBased.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RollProductionController::rollBased
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
rollBasedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rollBased.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RollProductionController::rollBased
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
rollBasedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rollBased.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

rollBased.form = rollBasedForm

/**
* @see routes/web.php:280
* @route '/production-orders'
*/
export const orders = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orders.url(options),
    method: 'get',
})

orders.definition = {
    methods: ["get","head"],
    url: '/production-orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:280
* @route '/production-orders'
*/
orders.url = (options?: RouteQueryOptions) => {
    return orders.definition.url + queryParams(options)
}

/**
* @see routes/web.php:280
* @route '/production-orders'
*/
orders.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orders.url(options),
    method: 'get',
})

/**
* @see routes/web.php:280
* @route '/production-orders'
*/
orders.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orders.url(options),
    method: 'head',
})

/**
* @see routes/web.php:280
* @route '/production-orders'
*/
const ordersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orders.url(options),
    method: 'get',
})

/**
* @see routes/web.php:280
* @route '/production-orders'
*/
ordersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orders.url(options),
    method: 'get',
})

/**
* @see routes/web.php:280
* @route '/production-orders'
*/
ordersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orders.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

orders.form = ordersForm

const production = {
    rollBased: Object.assign(rollBased, rollBasedAaac41),
    benchmarks: Object.assign(benchmarks, benchmarks),
    orders: Object.assign(orders, ordersB47e5f),
}

export default production