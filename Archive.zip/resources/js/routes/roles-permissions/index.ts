import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import role from './role'
import permission from './permission'
/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/roles-permissions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const rolesPermissions = {
    index: Object.assign(index, index),
    role: Object.assign(role, role),
    permission: Object.assign(permission, permission),
}

export default rolesPermissions