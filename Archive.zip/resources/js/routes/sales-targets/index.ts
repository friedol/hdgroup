import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\SalesTargetController::index
* @see app/Http/Controllers/SalesTargetController.php:16
* @route '/sales-targets'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/sales-targets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesTargetController::index
* @see app/Http/Controllers/SalesTargetController.php:16
* @route '/sales-targets'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesTargetController::index
* @see app/Http/Controllers/SalesTargetController.php:16
* @route '/sales-targets'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SalesTargetController::index
* @see app/Http/Controllers/SalesTargetController.php:16
* @route '/sales-targets'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SalesTargetController::index
* @see app/Http/Controllers/SalesTargetController.php:16
* @route '/sales-targets'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SalesTargetController::index
* @see app/Http/Controllers/SalesTargetController.php:16
* @route '/sales-targets'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SalesTargetController::index
* @see app/Http/Controllers/SalesTargetController.php:16
* @route '/sales-targets'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\SalesTargetController::store
* @see app/Http/Controllers/SalesTargetController.php:104
* @route '/sales-targets'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/sales-targets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesTargetController::store
* @see app/Http/Controllers/SalesTargetController.php:104
* @route '/sales-targets'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesTargetController::store
* @see app/Http/Controllers/SalesTargetController.php:104
* @route '/sales-targets'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SalesTargetController::store
* @see app/Http/Controllers/SalesTargetController.php:104
* @route '/sales-targets'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SalesTargetController::store
* @see app/Http/Controllers/SalesTargetController.php:104
* @route '/sales-targets'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\SalesTargetController::destroy
* @see app/Http/Controllers/SalesTargetController.php:129
* @route '/sales-targets/{salesTarget}'
*/
export const destroy = (args: { salesTarget: number | { id: number } } | [salesTarget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/sales-targets/{salesTarget}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SalesTargetController::destroy
* @see app/Http/Controllers/SalesTargetController.php:129
* @route '/sales-targets/{salesTarget}'
*/
destroy.url = (args: { salesTarget: number | { id: number } } | [salesTarget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesTarget: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { salesTarget: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            salesTarget: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        salesTarget: typeof args.salesTarget === 'object'
        ? args.salesTarget.id
        : args.salesTarget,
    }

    return destroy.definition.url
            .replace('{salesTarget}', parsedArgs.salesTarget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesTargetController::destroy
* @see app/Http/Controllers/SalesTargetController.php:129
* @route '/sales-targets/{salesTarget}'
*/
destroy.delete = (args: { salesTarget: number | { id: number } } | [salesTarget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\SalesTargetController::destroy
* @see app/Http/Controllers/SalesTargetController.php:129
* @route '/sales-targets/{salesTarget}'
*/
const destroyForm = (args: { salesTarget: number | { id: number } } | [salesTarget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SalesTargetController::destroy
* @see app/Http/Controllers/SalesTargetController.php:129
* @route '/sales-targets/{salesTarget}'
*/
destroyForm.delete = (args: { salesTarget: number | { id: number } } | [salesTarget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const salesTargets = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    destroy: Object.assign(destroy, destroy),
}

export default salesTargets