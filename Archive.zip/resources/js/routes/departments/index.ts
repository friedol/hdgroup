import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\HR\DepartmentController::create
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/hr/departments/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HR\DepartmentController::create
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HR\DepartmentController::create
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::create
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::create
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::create
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::create
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\HR\DepartmentController::show
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}'
*/
export const show = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/hr/departments/{department}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HR\DepartmentController::show
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}'
*/
show.url = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

    if (Array.isArray(args)) {
        args = {
            department: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        department: args.department,
    }

    return show.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HR\DepartmentController::show
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}'
*/
show.get = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::show
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}'
*/
show.head = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::show
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}'
*/
const showForm = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::show
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}'
*/
showForm.get = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::show
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}'
*/
showForm.head = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\HR\DepartmentController::edit
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}/edit'
*/
export const edit = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/hr/departments/{department}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HR\DepartmentController::edit
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}/edit'
*/
edit.url = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

    if (Array.isArray(args)) {
        args = {
            department: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        department: args.department,
    }

    return edit.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HR\DepartmentController::edit
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}/edit'
*/
edit.get = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::edit
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}/edit'
*/
edit.head = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::edit
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}/edit'
*/
const editForm = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::edit
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}/edit'
*/
editForm.get = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HR\DepartmentController::edit
* @see app/Http/Controllers/HR/DepartmentController.php:0
* @route '/hr/departments/{department}/edit'
*/
editForm.head = (args: { department: string | number } | [department: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

const departments = {
    create: Object.assign(create, create),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
}

export default departments