import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ProductController::status
* @see app/Http/Controllers/ProductController.php:759
* @route '/product-toggle-status'
*/
export const status = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: status.url(options),
    method: 'post',
})

status.definition = {
    methods: ["post"],
    url: '/product-toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductController::status
* @see app/Http/Controllers/ProductController.php:759
* @route '/product-toggle-status'
*/
status.url = (options?: RouteQueryOptions) => {
    return status.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::status
* @see app/Http/Controllers/ProductController.php:759
* @route '/product-toggle-status'
*/
status.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: status.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::status
* @see app/Http/Controllers/ProductController.php:759
* @route '/product-toggle-status'
*/
const statusForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: status.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::status
* @see app/Http/Controllers/ProductController.php:759
* @route '/product-toggle-status'
*/
statusForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: status.url(options),
    method: 'post',
})

status.form = statusForm

/**
* @see \App\Http\Controllers\ProductController::visibility
* @see app/Http/Controllers/ProductController.php:773
* @route '/product-toggle-visibility'
*/
export const visibility = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: visibility.url(options),
    method: 'post',
})

visibility.definition = {
    methods: ["post"],
    url: '/product-toggle-visibility',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductController::visibility
* @see app/Http/Controllers/ProductController.php:773
* @route '/product-toggle-visibility'
*/
visibility.url = (options?: RouteQueryOptions) => {
    return visibility.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::visibility
* @see app/Http/Controllers/ProductController.php:773
* @route '/product-toggle-visibility'
*/
visibility.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: visibility.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::visibility
* @see app/Http/Controllers/ProductController.php:773
* @route '/product-toggle-visibility'
*/
const visibilityForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: visibility.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::visibility
* @see app/Http/Controllers/ProductController.php:773
* @route '/product-toggle-visibility'
*/
visibilityForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: visibility.url(options),
    method: 'post',
})

visibility.form = visibilityForm

const productToggle = {
    status: Object.assign(status, status),
    visibility: Object.assign(visibility, visibility),
}

export default productToggle