import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/store/checkout'
*/
export const checkout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

checkout.definition = {
    methods: ["post"],
    url: '/store/checkout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/store/checkout'
*/
checkout.url = (options?: RouteQueryOptions) => {
    return checkout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/store/checkout'
*/
checkout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/store/checkout'
*/
const checkoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: checkout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/store/checkout'
*/
checkoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: checkout.url(options),
    method: 'post',
})

checkout.form = checkoutForm

const store = {
    checkout: Object.assign(checkout, checkout),
}

export default store