import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\RegisterProductController::index
* @see app/Http/Controllers/RegisterProductController.php:14
* @route '/register-products'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/register-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RegisterProductController::index
* @see app/Http/Controllers/RegisterProductController.php:14
* @route '/register-products'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RegisterProductController::index
* @see app/Http/Controllers/RegisterProductController.php:14
* @route '/register-products'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::index
* @see app/Http/Controllers/RegisterProductController.php:14
* @route '/register-products'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RegisterProductController::index
* @see app/Http/Controllers/RegisterProductController.php:14
* @route '/register-products'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::index
* @see app/Http/Controllers/RegisterProductController.php:14
* @route '/register-products'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::index
* @see app/Http/Controllers/RegisterProductController.php:14
* @route '/register-products'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\RegisterProductController::create
* @see app/Http/Controllers/RegisterProductController.php:31
* @route '/register-products/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/register-products/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RegisterProductController::create
* @see app/Http/Controllers/RegisterProductController.php:31
* @route '/register-products/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RegisterProductController::create
* @see app/Http/Controllers/RegisterProductController.php:31
* @route '/register-products/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::create
* @see app/Http/Controllers/RegisterProductController.php:31
* @route '/register-products/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RegisterProductController::create
* @see app/Http/Controllers/RegisterProductController.php:31
* @route '/register-products/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::create
* @see app/Http/Controllers/RegisterProductController.php:31
* @route '/register-products/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::create
* @see app/Http/Controllers/RegisterProductController.php:31
* @route '/register-products/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\RegisterProductController::store
* @see app/Http/Controllers/RegisterProductController.php:39
* @route '/register-products'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/register-products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RegisterProductController::store
* @see app/Http/Controllers/RegisterProductController.php:39
* @route '/register-products'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RegisterProductController::store
* @see app/Http/Controllers/RegisterProductController.php:39
* @route '/register-products'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RegisterProductController::store
* @see app/Http/Controllers/RegisterProductController.php:39
* @route '/register-products'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RegisterProductController::store
* @see app/Http/Controllers/RegisterProductController.php:39
* @route '/register-products'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\RegisterProductController::show
* @see app/Http/Controllers/RegisterProductController.php:76
* @route '/register-products/{register_product}'
*/
export const show = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/register-products/{register_product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RegisterProductController::show
* @see app/Http/Controllers/RegisterProductController.php:76
* @route '/register-products/{register_product}'
*/
show.url = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { register_product: args }
    }

    if (Array.isArray(args)) {
        args = {
            register_product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        register_product: args.register_product,
    }

    return show.definition.url
            .replace('{register_product}', parsedArgs.register_product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RegisterProductController::show
* @see app/Http/Controllers/RegisterProductController.php:76
* @route '/register-products/{register_product}'
*/
show.get = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::show
* @see app/Http/Controllers/RegisterProductController.php:76
* @route '/register-products/{register_product}'
*/
show.head = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RegisterProductController::show
* @see app/Http/Controllers/RegisterProductController.php:76
* @route '/register-products/{register_product}'
*/
const showForm = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::show
* @see app/Http/Controllers/RegisterProductController.php:76
* @route '/register-products/{register_product}'
*/
showForm.get = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::show
* @see app/Http/Controllers/RegisterProductController.php:76
* @route '/register-products/{register_product}'
*/
showForm.head = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\RegisterProductController::edit
* @see app/Http/Controllers/RegisterProductController.php:85
* @route '/register-products/{register_product}/edit'
*/
export const edit = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/register-products/{register_product}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RegisterProductController::edit
* @see app/Http/Controllers/RegisterProductController.php:85
* @route '/register-products/{register_product}/edit'
*/
edit.url = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { register_product: args }
    }

    if (Array.isArray(args)) {
        args = {
            register_product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        register_product: args.register_product,
    }

    return edit.definition.url
            .replace('{register_product}', parsedArgs.register_product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RegisterProductController::edit
* @see app/Http/Controllers/RegisterProductController.php:85
* @route '/register-products/{register_product}/edit'
*/
edit.get = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::edit
* @see app/Http/Controllers/RegisterProductController.php:85
* @route '/register-products/{register_product}/edit'
*/
edit.head = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RegisterProductController::edit
* @see app/Http/Controllers/RegisterProductController.php:85
* @route '/register-products/{register_product}/edit'
*/
const editForm = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::edit
* @see app/Http/Controllers/RegisterProductController.php:85
* @route '/register-products/{register_product}/edit'
*/
editForm.get = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RegisterProductController::edit
* @see app/Http/Controllers/RegisterProductController.php:85
* @route '/register-products/{register_product}/edit'
*/
editForm.head = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\RegisterProductController::update
* @see app/Http/Controllers/RegisterProductController.php:96
* @route '/register-products/{register_product}'
*/
export const update = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/register-products/{register_product}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\RegisterProductController::update
* @see app/Http/Controllers/RegisterProductController.php:96
* @route '/register-products/{register_product}'
*/
update.url = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { register_product: args }
    }

    if (Array.isArray(args)) {
        args = {
            register_product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        register_product: args.register_product,
    }

    return update.definition.url
            .replace('{register_product}', parsedArgs.register_product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RegisterProductController::update
* @see app/Http/Controllers/RegisterProductController.php:96
* @route '/register-products/{register_product}'
*/
update.put = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\RegisterProductController::update
* @see app/Http/Controllers/RegisterProductController.php:96
* @route '/register-products/{register_product}'
*/
update.patch = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\RegisterProductController::update
* @see app/Http/Controllers/RegisterProductController.php:96
* @route '/register-products/{register_product}'
*/
const updateForm = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RegisterProductController::update
* @see app/Http/Controllers/RegisterProductController.php:96
* @route '/register-products/{register_product}'
*/
updateForm.put = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RegisterProductController::update
* @see app/Http/Controllers/RegisterProductController.php:96
* @route '/register-products/{register_product}'
*/
updateForm.patch = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\RegisterProductController::destroy
* @see app/Http/Controllers/RegisterProductController.php:119
* @route '/register-products/{register_product}'
*/
export const destroy = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/register-products/{register_product}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\RegisterProductController::destroy
* @see app/Http/Controllers/RegisterProductController.php:119
* @route '/register-products/{register_product}'
*/
destroy.url = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { register_product: args }
    }

    if (Array.isArray(args)) {
        args = {
            register_product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        register_product: args.register_product,
    }

    return destroy.definition.url
            .replace('{register_product}', parsedArgs.register_product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RegisterProductController::destroy
* @see app/Http/Controllers/RegisterProductController.php:119
* @route '/register-products/{register_product}'
*/
destroy.delete = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\RegisterProductController::destroy
* @see app/Http/Controllers/RegisterProductController.php:119
* @route '/register-products/{register_product}'
*/
const destroyForm = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RegisterProductController::destroy
* @see app/Http/Controllers/RegisterProductController.php:119
* @route '/register-products/{register_product}'
*/
destroyForm.delete = (args: { register_product: string | number } | [register_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const registerProducts = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default registerProducts