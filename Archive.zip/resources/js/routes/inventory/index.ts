import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\InventoryController::view
* @see app/Http/Controllers/InventoryController.php:13
* @route '/inventory-report'
*/
export const view = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view.url(options),
    method: 'get',
})

view.definition = {
    methods: ["get","head"],
    url: '/inventory-report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InventoryController::view
* @see app/Http/Controllers/InventoryController.php:13
* @route '/inventory-report'
*/
view.url = (options?: RouteQueryOptions) => {
    return view.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryController::view
* @see app/Http/Controllers/InventoryController.php:13
* @route '/inventory-report'
*/
view.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\InventoryController::view
* @see app/Http/Controllers/InventoryController.php:13
* @route '/inventory-report'
*/
view.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: view.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\InventoryController::view
* @see app/Http/Controllers/InventoryController.php:13
* @route '/inventory-report'
*/
const viewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: view.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\InventoryController::view
* @see app/Http/Controllers/InventoryController.php:13
* @route '/inventory-report'
*/
viewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: view.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\InventoryController::view
* @see app/Http/Controllers/InventoryController.php:13
* @route '/inventory-report'
*/
viewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: view.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

view.form = viewForm

const inventory = {
    view: Object.assign(view, view),
}

export default inventory