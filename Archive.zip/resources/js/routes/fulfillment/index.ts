import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import item from './item'
import bulk from './bulk'
/**
* @see \App\Http\Controllers\FulfillmentController::index
* @see app/Http/Controllers/FulfillmentController.php:17
* @route '/fulfillment'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/fulfillment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FulfillmentController::index
* @see app/Http/Controllers/FulfillmentController.php:17
* @route '/fulfillment'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FulfillmentController::index
* @see app/Http/Controllers/FulfillmentController.php:17
* @route '/fulfillment'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FulfillmentController::index
* @see app/Http/Controllers/FulfillmentController.php:17
* @route '/fulfillment'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FulfillmentController::index
* @see app/Http/Controllers/FulfillmentController.php:17
* @route '/fulfillment'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FulfillmentController::index
* @see app/Http/Controllers/FulfillmentController.php:17
* @route '/fulfillment'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FulfillmentController::index
* @see app/Http/Controllers/FulfillmentController.php:17
* @route '/fulfillment'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\FulfillmentController::show
* @see app/Http/Controllers/FulfillmentController.php:92
* @route '/fulfillment/{invoice}'
*/
export const show = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/fulfillment/{invoice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FulfillmentController::show
* @see app/Http/Controllers/FulfillmentController.php:92
* @route '/fulfillment/{invoice}'
*/
show.url = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

    if (Array.isArray(args)) {
        args = {
            invoice: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        invoice: args.invoice,
    }

    return show.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FulfillmentController::show
* @see app/Http/Controllers/FulfillmentController.php:92
* @route '/fulfillment/{invoice}'
*/
show.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FulfillmentController::show
* @see app/Http/Controllers/FulfillmentController.php:92
* @route '/fulfillment/{invoice}'
*/
show.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FulfillmentController::show
* @see app/Http/Controllers/FulfillmentController.php:92
* @route '/fulfillment/{invoice}'
*/
const showForm = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FulfillmentController::show
* @see app/Http/Controllers/FulfillmentController.php:92
* @route '/fulfillment/{invoice}'
*/
showForm.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FulfillmentController::show
* @see app/Http/Controllers/FulfillmentController.php:92
* @route '/fulfillment/{invoice}'
*/
showForm.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const fulfillment = {
    index: Object.assign(index, index),
    show: Object.assign(show, show),
    item: Object.assign(item, item),
    bulk: Object.assign(bulk, bulk),
}

export default fulfillment