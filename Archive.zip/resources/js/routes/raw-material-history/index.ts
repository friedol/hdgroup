import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ProductionOrderController::index
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/raw-material-history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::index
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::index
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::index
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::index
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::index
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::index
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const rawMaterialHistory = {
    index: Object.assign(index, index),
}

export default rawMaterialHistory