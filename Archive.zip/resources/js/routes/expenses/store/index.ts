import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ExpensesController::crud
* @see app/Http/Controllers/ExpensesController.php:90
* @route '/expenses-crud'
*/
export const crud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

crud.definition = {
    methods: ["post"],
    url: '/expenses-crud',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ExpensesController::crud
* @see app/Http/Controllers/ExpensesController.php:90
* @route '/expenses-crud'
*/
crud.url = (options?: RouteQueryOptions) => {
    return crud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::crud
* @see app/Http/Controllers/ExpensesController.php:90
* @route '/expenses-crud'
*/
crud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::crud
* @see app/Http/Controllers/ExpensesController.php:90
* @route '/expenses-crud'
*/
const crudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::crud
* @see app/Http/Controllers/ExpensesController.php:90
* @route '/expenses-crud'
*/
crudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

crud.form = crudForm
