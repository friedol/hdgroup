import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ExpensesController::crud
* @see app/Http/Controllers/ExpensesController.php:114
* @route '/expenses-crud/{id}'
*/
export const crud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: crud.url(args, options),
    method: 'put',
})

crud.definition = {
    methods: ["put"],
    url: '/expenses-crud/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ExpensesController::crud
* @see app/Http/Controllers/ExpensesController.php:114
* @route '/expenses-crud/{id}'
*/
crud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return crud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::crud
* @see app/Http/Controllers/ExpensesController.php:114
* @route '/expenses-crud/{id}'
*/
crud.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: crud.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ExpensesController::crud
* @see app/Http/Controllers/ExpensesController.php:114
* @route '/expenses-crud/{id}'
*/
const crudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::crud
* @see app/Http/Controllers/ExpensesController.php:114
* @route '/expenses-crud/{id}'
*/
crudForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

crud.form = crudForm
