import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DeliveryPersonController::index
* @see app/Http/Controllers/DeliveryPersonController.php:14
* @route '/delivery-personnel'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/delivery-personnel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeliveryPersonController::index
* @see app/Http/Controllers/DeliveryPersonController.php:14
* @route '/delivery-personnel'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryPersonController::index
* @see app/Http/Controllers/DeliveryPersonController.php:14
* @route '/delivery-personnel'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::index
* @see app/Http/Controllers/DeliveryPersonController.php:14
* @route '/delivery-personnel'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::index
* @see app/Http/Controllers/DeliveryPersonController.php:14
* @route '/delivery-personnel'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::index
* @see app/Http/Controllers/DeliveryPersonController.php:14
* @route '/delivery-personnel'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::index
* @see app/Http/Controllers/DeliveryPersonController.php:14
* @route '/delivery-personnel'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\DeliveryPersonController::create
* @see app/Http/Controllers/DeliveryPersonController.php:58
* @route '/delivery-personnel/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/delivery-personnel/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeliveryPersonController::create
* @see app/Http/Controllers/DeliveryPersonController.php:58
* @route '/delivery-personnel/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryPersonController::create
* @see app/Http/Controllers/DeliveryPersonController.php:58
* @route '/delivery-personnel/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::create
* @see app/Http/Controllers/DeliveryPersonController.php:58
* @route '/delivery-personnel/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::create
* @see app/Http/Controllers/DeliveryPersonController.php:58
* @route '/delivery-personnel/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::create
* @see app/Http/Controllers/DeliveryPersonController.php:58
* @route '/delivery-personnel/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::create
* @see app/Http/Controllers/DeliveryPersonController.php:58
* @route '/delivery-personnel/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\DeliveryPersonController::store
* @see app/Http/Controllers/DeliveryPersonController.php:84
* @route '/delivery-personnel'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/delivery-personnel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeliveryPersonController::store
* @see app/Http/Controllers/DeliveryPersonController.php:84
* @route '/delivery-personnel'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryPersonController::store
* @see app/Http/Controllers/DeliveryPersonController.php:84
* @route '/delivery-personnel'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::store
* @see app/Http/Controllers/DeliveryPersonController.php:84
* @route '/delivery-personnel'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::store
* @see app/Http/Controllers/DeliveryPersonController.php:84
* @route '/delivery-personnel'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\DeliveryPersonController::show
* @see app/Http/Controllers/DeliveryPersonController.php:112
* @route '/delivery-personnel/{delivery_personnel}'
*/
export const show = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/delivery-personnel/{delivery_personnel}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeliveryPersonController::show
* @see app/Http/Controllers/DeliveryPersonController.php:112
* @route '/delivery-personnel/{delivery_personnel}'
*/
show.url = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery_personnel: args }
    }

    if (Array.isArray(args)) {
        args = {
            delivery_personnel: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery_personnel: args.delivery_personnel,
    }

    return show.definition.url
            .replace('{delivery_personnel}', parsedArgs.delivery_personnel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryPersonController::show
* @see app/Http/Controllers/DeliveryPersonController.php:112
* @route '/delivery-personnel/{delivery_personnel}'
*/
show.get = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::show
* @see app/Http/Controllers/DeliveryPersonController.php:112
* @route '/delivery-personnel/{delivery_personnel}'
*/
show.head = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::show
* @see app/Http/Controllers/DeliveryPersonController.php:112
* @route '/delivery-personnel/{delivery_personnel}'
*/
const showForm = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::show
* @see app/Http/Controllers/DeliveryPersonController.php:112
* @route '/delivery-personnel/{delivery_personnel}'
*/
showForm.get = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::show
* @see app/Http/Controllers/DeliveryPersonController.php:112
* @route '/delivery-personnel/{delivery_personnel}'
*/
showForm.head = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\DeliveryPersonController::edit
* @see app/Http/Controllers/DeliveryPersonController.php:151
* @route '/delivery-personnel/{delivery_personnel}/edit'
*/
export const edit = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/delivery-personnel/{delivery_personnel}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeliveryPersonController::edit
* @see app/Http/Controllers/DeliveryPersonController.php:151
* @route '/delivery-personnel/{delivery_personnel}/edit'
*/
edit.url = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery_personnel: args }
    }

    if (Array.isArray(args)) {
        args = {
            delivery_personnel: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery_personnel: args.delivery_personnel,
    }

    return edit.definition.url
            .replace('{delivery_personnel}', parsedArgs.delivery_personnel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryPersonController::edit
* @see app/Http/Controllers/DeliveryPersonController.php:151
* @route '/delivery-personnel/{delivery_personnel}/edit'
*/
edit.get = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::edit
* @see app/Http/Controllers/DeliveryPersonController.php:151
* @route '/delivery-personnel/{delivery_personnel}/edit'
*/
edit.head = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::edit
* @see app/Http/Controllers/DeliveryPersonController.php:151
* @route '/delivery-personnel/{delivery_personnel}/edit'
*/
const editForm = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::edit
* @see app/Http/Controllers/DeliveryPersonController.php:151
* @route '/delivery-personnel/{delivery_personnel}/edit'
*/
editForm.get = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::edit
* @see app/Http/Controllers/DeliveryPersonController.php:151
* @route '/delivery-personnel/{delivery_personnel}/edit'
*/
editForm.head = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\DeliveryPersonController::update
* @see app/Http/Controllers/DeliveryPersonController.php:178
* @route '/delivery-personnel/{delivery_personnel}'
*/
export const update = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/delivery-personnel/{delivery_personnel}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\DeliveryPersonController::update
* @see app/Http/Controllers/DeliveryPersonController.php:178
* @route '/delivery-personnel/{delivery_personnel}'
*/
update.url = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery_personnel: args }
    }

    if (Array.isArray(args)) {
        args = {
            delivery_personnel: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery_personnel: args.delivery_personnel,
    }

    return update.definition.url
            .replace('{delivery_personnel}', parsedArgs.delivery_personnel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryPersonController::update
* @see app/Http/Controllers/DeliveryPersonController.php:178
* @route '/delivery-personnel/{delivery_personnel}'
*/
update.put = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::update
* @see app/Http/Controllers/DeliveryPersonController.php:178
* @route '/delivery-personnel/{delivery_personnel}'
*/
update.patch = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::update
* @see app/Http/Controllers/DeliveryPersonController.php:178
* @route '/delivery-personnel/{delivery_personnel}'
*/
const updateForm = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::update
* @see app/Http/Controllers/DeliveryPersonController.php:178
* @route '/delivery-personnel/{delivery_personnel}'
*/
updateForm.put = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::update
* @see app/Http/Controllers/DeliveryPersonController.php:178
* @route '/delivery-personnel/{delivery_personnel}'
*/
updateForm.patch = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\DeliveryPersonController::destroy
* @see app/Http/Controllers/DeliveryPersonController.php:203
* @route '/delivery-personnel/{delivery_personnel}'
*/
export const destroy = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/delivery-personnel/{delivery_personnel}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DeliveryPersonController::destroy
* @see app/Http/Controllers/DeliveryPersonController.php:203
* @route '/delivery-personnel/{delivery_personnel}'
*/
destroy.url = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery_personnel: args }
    }

    if (Array.isArray(args)) {
        args = {
            delivery_personnel: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery_personnel: args.delivery_personnel,
    }

    return destroy.definition.url
            .replace('{delivery_personnel}', parsedArgs.delivery_personnel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryPersonController::destroy
* @see app/Http/Controllers/DeliveryPersonController.php:203
* @route '/delivery-personnel/{delivery_personnel}'
*/
destroy.delete = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::destroy
* @see app/Http/Controllers/DeliveryPersonController.php:203
* @route '/delivery-personnel/{delivery_personnel}'
*/
const destroyForm = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryPersonController::destroy
* @see app/Http/Controllers/DeliveryPersonController.php:203
* @route '/delivery-personnel/{delivery_personnel}'
*/
destroyForm.delete = (args: { delivery_personnel: string | number } | [delivery_personnel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const deliveryPersonnel = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default deliveryPersonnel