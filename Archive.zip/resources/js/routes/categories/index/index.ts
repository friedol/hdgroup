import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
export const crud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: crud.url(options),
    method: 'get',
})

crud.definition = {
    methods: ["get","head"],
    url: '/categories-crud',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
crud.url = (options?: RouteQueryOptions) => {
    return crud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
crud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: crud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
crud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: crud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
const crudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: crud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
crudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: crud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
crudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: crud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

crud.form = crudForm

const index = {
    crud: Object.assign(crud, crud),
}

export default index