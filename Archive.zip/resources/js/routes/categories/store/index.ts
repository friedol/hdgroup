import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:34
* @route '/categories-crud'
*/
export const crud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

crud.definition = {
    methods: ["post"],
    url: '/categories-crud',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:34
* @route '/categories-crud'
*/
crud.url = (options?: RouteQueryOptions) => {
    return crud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:34
* @route '/categories-crud'
*/
crud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:34
* @route '/categories-crud'
*/
const crudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\CategoryController::crud
* @see app/Http/Controllers/management/CategoryController.php:34
* @route '/categories-crud'
*/
crudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: crud.url(options),
    method: 'post',
})

crud.form = crudForm
