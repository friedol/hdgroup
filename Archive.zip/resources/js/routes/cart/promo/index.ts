import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CartController::apply
* @see app/Http/Controllers/CartController.php:472
* @route '/cart/promo/apply'
*/
export const apply = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: apply.url(options),
    method: 'post',
})

apply.definition = {
    methods: ["post"],
    url: '/cart/promo/apply',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::apply
* @see app/Http/Controllers/CartController.php:472
* @route '/cart/promo/apply'
*/
apply.url = (options?: RouteQueryOptions) => {
    return apply.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::apply
* @see app/Http/Controllers/CartController.php:472
* @route '/cart/promo/apply'
*/
apply.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: apply.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::apply
* @see app/Http/Controllers/CartController.php:472
* @route '/cart/promo/apply'
*/
const applyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: apply.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::apply
* @see app/Http/Controllers/CartController.php:472
* @route '/cart/promo/apply'
*/
applyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: apply.url(options),
    method: 'post',
})

apply.form = applyForm

/**
* @see \App\Http\Controllers\CartController::remove
* @see app/Http/Controllers/CartController.php:501
* @route '/cart/promo/remove'
*/
export const remove = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: remove.url(options),
    method: 'post',
})

remove.definition = {
    methods: ["post"],
    url: '/cart/promo/remove',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::remove
* @see app/Http/Controllers/CartController.php:501
* @route '/cart/promo/remove'
*/
remove.url = (options?: RouteQueryOptions) => {
    return remove.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::remove
* @see app/Http/Controllers/CartController.php:501
* @route '/cart/promo/remove'
*/
remove.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: remove.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::remove
* @see app/Http/Controllers/CartController.php:501
* @route '/cart/promo/remove'
*/
const removeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: remove.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::remove
* @see app/Http/Controllers/CartController.php:501
* @route '/cart/promo/remove'
*/
removeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: remove.url(options),
    method: 'post',
})

remove.form = removeForm

const promo = {
    apply: Object.assign(apply, apply),
    remove: Object.assign(remove, remove),
}

export default promo