import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Account\OrderTrackingController::orderTracking
* @see app/Http/Controllers/Account/OrderTrackingController.php:12
* @route '/account/order-tracking/{order_number}'
*/
export const orderTracking = (args: { order_number: string | number } | [order_number: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orderTracking.url(args, options),
    method: 'get',
})

orderTracking.definition = {
    methods: ["get","head"],
    url: '/account/order-tracking/{order_number}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Account\OrderTrackingController::orderTracking
* @see app/Http/Controllers/Account/OrderTrackingController.php:12
* @route '/account/order-tracking/{order_number}'
*/
orderTracking.url = (args: { order_number: string | number } | [order_number: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order_number: args }
    }

    if (Array.isArray(args)) {
        args = {
            order_number: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order_number: args.order_number,
    }

    return orderTracking.definition.url
            .replace('{order_number}', parsedArgs.order_number.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\OrderTrackingController::orderTracking
* @see app/Http/Controllers/Account/OrderTrackingController.php:12
* @route '/account/order-tracking/{order_number}'
*/
orderTracking.get = (args: { order_number: string | number } | [order_number: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orderTracking.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Account\OrderTrackingController::orderTracking
* @see app/Http/Controllers/Account/OrderTrackingController.php:12
* @route '/account/order-tracking/{order_number}'
*/
orderTracking.head = (args: { order_number: string | number } | [order_number: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orderTracking.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Account\OrderTrackingController::orderTracking
* @see app/Http/Controllers/Account/OrderTrackingController.php:12
* @route '/account/order-tracking/{order_number}'
*/
const orderTrackingForm = (args: { order_number: string | number } | [order_number: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orderTracking.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Account\OrderTrackingController::orderTracking
* @see app/Http/Controllers/Account/OrderTrackingController.php:12
* @route '/account/order-tracking/{order_number}'
*/
orderTrackingForm.get = (args: { order_number: string | number } | [order_number: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orderTracking.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Account\OrderTrackingController::orderTracking
* @see app/Http/Controllers/Account/OrderTrackingController.php:12
* @route '/account/order-tracking/{order_number}'
*/
orderTrackingForm.head = (args: { order_number: string | number } | [order_number: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orderTracking.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

orderTracking.form = orderTrackingForm

const account = {
    orderTracking: Object.assign(orderTracking, orderTracking),
}

export default account