import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DamagedProductController::index
* @see app/Http/Controllers/DamagedProductController.php:32
* @route '/damaged-products'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/damaged-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DamagedProductController::index
* @see app/Http/Controllers/DamagedProductController.php:32
* @route '/damaged-products'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DamagedProductController::index
* @see app/Http/Controllers/DamagedProductController.php:32
* @route '/damaged-products'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DamagedProductController::index
* @see app/Http/Controllers/DamagedProductController.php:32
* @route '/damaged-products'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DamagedProductController::index
* @see app/Http/Controllers/DamagedProductController.php:32
* @route '/damaged-products'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DamagedProductController::index
* @see app/Http/Controllers/DamagedProductController.php:32
* @route '/damaged-products'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DamagedProductController::index
* @see app/Http/Controllers/DamagedProductController.php:32
* @route '/damaged-products'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\DamagedProductController::store
* @see app/Http/Controllers/DamagedProductController.php:112
* @route '/damaged-products'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/damaged-products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DamagedProductController::store
* @see app/Http/Controllers/DamagedProductController.php:112
* @route '/damaged-products'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DamagedProductController::store
* @see app/Http/Controllers/DamagedProductController.php:112
* @route '/damaged-products'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DamagedProductController::store
* @see app/Http/Controllers/DamagedProductController.php:112
* @route '/damaged-products'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DamagedProductController::store
* @see app/Http/Controllers/DamagedProductController.php:112
* @route '/damaged-products'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\DamagedProductController::destroy
* @see app/Http/Controllers/DamagedProductController.php:166
* @route '/damaged-products/{id}'
*/
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/damaged-products/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DamagedProductController::destroy
* @see app/Http/Controllers/DamagedProductController.php:166
* @route '/damaged-products/{id}'
*/
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DamagedProductController::destroy
* @see app/Http/Controllers/DamagedProductController.php:166
* @route '/damaged-products/{id}'
*/
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\DamagedProductController::destroy
* @see app/Http/Controllers/DamagedProductController.php:166
* @route '/damaged-products/{id}'
*/
const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DamagedProductController::destroy
* @see app/Http/Controllers/DamagedProductController.php:166
* @route '/damaged-products/{id}'
*/
destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const damagedProducts = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    destroy: Object.assign(destroy, destroy),
}

export default damagedProducts