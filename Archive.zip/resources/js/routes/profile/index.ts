import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ProfileController::changePassword
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
export const changePassword = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: changePassword.url(options),
    method: 'get',
})

changePassword.definition = {
    methods: ["get","head"],
    url: '/profile/change_password',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::changePassword
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
changePassword.url = (options?: RouteQueryOptions) => {
    return changePassword.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::changePassword
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
changePassword.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: changePassword.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::changePassword
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
changePassword.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: changePassword.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::changePassword
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
const changePasswordForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: changePassword.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::changePassword
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
changePasswordForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: changePassword.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::changePassword
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
changePasswordForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: changePassword.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

changePassword.form = changePasswordForm

/**
* @see \App\Http\Controllers\ProfileController::change
* @see app/Http/Controllers/ProfileController.php:54
* @route '/profile/update'
*/
export const change = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: change.url(options),
    method: 'post',
})

change.definition = {
    methods: ["post"],
    url: '/profile/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProfileController::change
* @see app/Http/Controllers/ProfileController.php:54
* @route '/profile/update'
*/
change.url = (options?: RouteQueryOptions) => {
    return change.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::change
* @see app/Http/Controllers/ProfileController.php:54
* @route '/profile/update'
*/
change.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: change.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::change
* @see app/Http/Controllers/ProfileController.php:54
* @route '/profile/update'
*/
const changeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: change.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::change
* @see app/Http/Controllers/ProfileController.php:54
* @route '/profile/update'
*/
changeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: change.url(options),
    method: 'post',
})

change.form = changeForm

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ProfileController::store
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/profile',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProfileController::store
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::store
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::store
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::store
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
export const show = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/profile/{profile}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
show.url = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { profile: args }
    }

    if (Array.isArray(args)) {
        args = {
            profile: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        profile: args.profile,
    }

    return show.definition.url
            .replace('{profile}', parsedArgs.profile.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
show.get = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
show.head = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
const showForm = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
showForm.get = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
showForm.head = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
export const edit = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/profile/{profile}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
edit.url = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { profile: args }
    }

    if (Array.isArray(args)) {
        args = {
            profile: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        profile: args.profile,
    }

    return edit.definition.url
            .replace('{profile}', parsedArgs.profile.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
edit.get = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
edit.head = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
const editForm = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
editForm.get = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
editForm.head = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
export const update = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/profile/{profile}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
update.url = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { profile: args }
    }

    if (Array.isArray(args)) {
        args = {
            profile: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        profile: args.profile,
    }

    return update.definition.url
            .replace('{profile}', parsedArgs.profile.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
update.put = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
update.patch = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
const updateForm = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
updateForm.put = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
updateForm.patch = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\ProfileController::destroy
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
export const destroy = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/profile/{profile}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProfileController::destroy
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
destroy.url = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { profile: args }
    }

    if (Array.isArray(args)) {
        args = {
            profile: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        profile: args.profile,
    }

    return destroy.definition.url
            .replace('{profile}', parsedArgs.profile.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::destroy
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
destroy.delete = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ProfileController::destroy
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
const destroyForm = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::destroy
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
destroyForm.delete = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const profile = {
    changePassword: Object.assign(changePassword, changePassword),
    change: Object.assign(change, change),
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default profile