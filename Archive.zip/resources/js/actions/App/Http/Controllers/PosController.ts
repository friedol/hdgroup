import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
export const terminal = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terminal.url(options),
    method: 'get',
})

terminal.definition = {
    methods: ["get","head"],
    url: '/pos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
terminal.url = (options?: RouteQueryOptions) => {
    return terminal.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
terminal.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terminal.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
terminal.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: terminal.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
const terminalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: terminal.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
terminalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: terminal.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::terminal
* @see app/Http/Controllers/PosController.php:38
* @route '/pos'
*/
terminalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: terminal.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

terminal.form = terminalForm

/**
* @see \App\Http\Controllers\PosController::store
* @see app/Http/Controllers/PosController.php:365
* @route '/pos/store'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pos/store',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PosController::store
* @see app/Http/Controllers/PosController.php:365
* @route '/pos/store'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::store
* @see app/Http/Controllers/PosController.php:365
* @route '/pos/store'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::store
* @see app/Http/Controllers/PosController.php:365
* @route '/pos/store'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::store
* @see app/Http/Controllers/PosController.php:365
* @route '/pos/store'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\PosController::searchProducts
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
export const searchProducts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchProducts.url(options),
    method: 'get',
})

searchProducts.definition = {
    methods: ["get","head"],
    url: '/pos/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::searchProducts
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
searchProducts.url = (options?: RouteQueryOptions) => {
    return searchProducts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::searchProducts
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
searchProducts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::searchProducts
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
searchProducts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: searchProducts.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::searchProducts
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
const searchProductsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::searchProducts
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
searchProductsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::searchProducts
* @see app/Http/Controllers/PosController.php:164
* @route '/pos/search'
*/
searchProductsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchProducts.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

searchProducts.form = searchProductsForm

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
export const searchCustomers = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchCustomers.url(options),
    method: 'get',
})

searchCustomers.definition = {
    methods: ["get","head"],
    url: '/pos/search-customers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
searchCustomers.url = (options?: RouteQueryOptions) => {
    return searchCustomers.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
searchCustomers.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchCustomers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
searchCustomers.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: searchCustomers.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
const searchCustomersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchCustomers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
searchCustomersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchCustomers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::searchCustomers
* @see app/Http/Controllers/PosController.php:275
* @route '/pos/search-customers'
*/
searchCustomersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchCustomers.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

searchCustomers.form = searchCustomersForm

/**
* @see \App\Http\Controllers\PosController::quickCustomerStore
* @see app/Http/Controllers/PosController.php:289
* @route '/pos/quick-customer'
*/
export const quickCustomerStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: quickCustomerStore.url(options),
    method: 'post',
})

quickCustomerStore.definition = {
    methods: ["post"],
    url: '/pos/quick-customer',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PosController::quickCustomerStore
* @see app/Http/Controllers/PosController.php:289
* @route '/pos/quick-customer'
*/
quickCustomerStore.url = (options?: RouteQueryOptions) => {
    return quickCustomerStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::quickCustomerStore
* @see app/Http/Controllers/PosController.php:289
* @route '/pos/quick-customer'
*/
quickCustomerStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: quickCustomerStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::quickCustomerStore
* @see app/Http/Controllers/PosController.php:289
* @route '/pos/quick-customer'
*/
const quickCustomerStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: quickCustomerStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::quickCustomerStore
* @see app/Http/Controllers/PosController.php:289
* @route '/pos/quick-customer'
*/
quickCustomerStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: quickCustomerStore.url(options),
    method: 'post',
})

quickCustomerStore.form = quickCustomerStoreForm

/**
* @see \App\Http\Controllers\PosController::findProduct
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
export const findProduct = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: findProduct.url(args, options),
    method: 'get',
})

findProduct.definition = {
    methods: ["get","head"],
    url: '/pos/find/{identifier}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::findProduct
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
findProduct.url = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { identifier: args }
    }

    if (Array.isArray(args)) {
        args = {
            identifier: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        identifier: args.identifier,
    }

    return findProduct.definition.url
            .replace('{identifier}', parsedArgs.identifier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::findProduct
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
findProduct.get = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: findProduct.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::findProduct
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
findProduct.head = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: findProduct.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::findProduct
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
const findProductForm = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: findProduct.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::findProduct
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
findProductForm.get = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: findProduct.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::findProduct
* @see app/Http/Controllers/PosController.php:0
* @route '/pos/find/{identifier}'
*/
findProductForm.head = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: findProduct.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

findProduct.form = findProductForm

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
const printReceipt995dfd8515f82635e91c6d482ff8e396 = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printReceipt995dfd8515f82635e91c6d482ff8e396.url(args, options),
    method: 'get',
})

printReceipt995dfd8515f82635e91c6d482ff8e396.definition = {
    methods: ["get","head"],
    url: '/pos/print/{invoice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
printReceipt995dfd8515f82635e91c6d482ff8e396.url = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

    if (Array.isArray(args)) {
        args = {
            invoice: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        invoice: args.invoice,
    }

    return printReceipt995dfd8515f82635e91c6d482ff8e396.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
printReceipt995dfd8515f82635e91c6d482ff8e396.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printReceipt995dfd8515f82635e91c6d482ff8e396.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
printReceipt995dfd8515f82635e91c6d482ff8e396.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printReceipt995dfd8515f82635e91c6d482ff8e396.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
const printReceipt995dfd8515f82635e91c6d482ff8e396Form = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printReceipt995dfd8515f82635e91c6d482ff8e396.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
printReceipt995dfd8515f82635e91c6d482ff8e396Form.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printReceipt995dfd8515f82635e91c6d482ff8e396.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/pos/print/{invoice}'
*/
printReceipt995dfd8515f82635e91c6d482ff8e396Form.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printReceipt995dfd8515f82635e91c6d482ff8e396.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

printReceipt995dfd8515f82635e91c6d482ff8e396.form = printReceipt995dfd8515f82635e91c6d482ff8e396Form
/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
const printReceipt2b475a6fe7deea13af5889d5637ea7b2 = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printReceipt2b475a6fe7deea13af5889d5637ea7b2.url(args, options),
    method: 'get',
})

printReceipt2b475a6fe7deea13af5889d5637ea7b2.definition = {
    methods: ["get","head"],
    url: '/finance/invoices/{invoice}/receipt',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
printReceipt2b475a6fe7deea13af5889d5637ea7b2.url = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

    if (Array.isArray(args)) {
        args = {
            invoice: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        invoice: args.invoice,
    }

    return printReceipt2b475a6fe7deea13af5889d5637ea7b2.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
printReceipt2b475a6fe7deea13af5889d5637ea7b2.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printReceipt2b475a6fe7deea13af5889d5637ea7b2.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
printReceipt2b475a6fe7deea13af5889d5637ea7b2.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printReceipt2b475a6fe7deea13af5889d5637ea7b2.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
const printReceipt2b475a6fe7deea13af5889d5637ea7b2Form = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printReceipt2b475a6fe7deea13af5889d5637ea7b2.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
printReceipt2b475a6fe7deea13af5889d5637ea7b2Form.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printReceipt2b475a6fe7deea13af5889d5637ea7b2.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::printReceipt
* @see app/Http/Controllers/PosController.php:627
* @route '/finance/invoices/{invoice}/receipt'
*/
printReceipt2b475a6fe7deea13af5889d5637ea7b2Form.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printReceipt2b475a6fe7deea13af5889d5637ea7b2.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

printReceipt2b475a6fe7deea13af5889d5637ea7b2.form = printReceipt2b475a6fe7deea13af5889d5637ea7b2Form

export const printReceipt = {
    '/pos/print/{invoice}': printReceipt995dfd8515f82635e91c6d482ff8e396,
    '/finance/invoices/{invoice}/receipt': printReceipt2b475a6fe7deea13af5889d5637ea7b2,
}

/**
* @see \App\Http\Controllers\PosController::processReturn
* @see app/Http/Controllers/PosController.php:694
* @route '/pos/return'
*/
export const processReturn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: processReturn.url(options),
    method: 'post',
})

processReturn.definition = {
    methods: ["post"],
    url: '/pos/return',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PosController::processReturn
* @see app/Http/Controllers/PosController.php:694
* @route '/pos/return'
*/
processReturn.url = (options?: RouteQueryOptions) => {
    return processReturn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::processReturn
* @see app/Http/Controllers/PosController.php:694
* @route '/pos/return'
*/
processReturn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: processReturn.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::processReturn
* @see app/Http/Controllers/PosController.php:694
* @route '/pos/return'
*/
const processReturnForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: processReturn.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::processReturn
* @see app/Http/Controllers/PosController.php:694
* @route '/pos/return'
*/
processReturnForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: processReturn.url(options),
    method: 'post',
})

processReturn.form = processReturnForm

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
export const history = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/sales-history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
history.url = (options?: RouteQueryOptions) => {
    return history.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
history.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
history.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
const historyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
historyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::history
* @see app/Http/Controllers/PosController.php:928
* @route '/sales-history'
*/
historyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

history.form = historyForm

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
export const show = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/pos/sale/{invoice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
show.url = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

    if (Array.isArray(args)) {
        args = {
            invoice: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        invoice: args.invoice,
    }

    return show.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
show.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
show.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
const showForm = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
showForm.get = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::show
* @see app/Http/Controllers/PosController.php:771
* @route '/pos/sale/{invoice}'
*/
showForm.head = (args: { invoice: string | number } | [invoice: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\PosController::storePayment
* @see app/Http/Controllers/PosController.php:841
* @route '/pos/sale/payment'
*/
export const storePayment = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePayment.url(options),
    method: 'post',
})

storePayment.definition = {
    methods: ["post"],
    url: '/pos/sale/payment',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PosController::storePayment
* @see app/Http/Controllers/PosController.php:841
* @route '/pos/sale/payment'
*/
storePayment.url = (options?: RouteQueryOptions) => {
    return storePayment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::storePayment
* @see app/Http/Controllers/PosController.php:841
* @route '/pos/sale/payment'
*/
storePayment.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePayment.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::storePayment
* @see app/Http/Controllers/PosController.php:841
* @route '/pos/sale/payment'
*/
const storePaymentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storePayment.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::storePayment
* @see app/Http/Controllers/PosController.php:841
* @route '/pos/sale/payment'
*/
storePaymentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storePayment.url(options),
    method: 'post',
})

storePayment.form = storePaymentForm

/**
* @see \App\Http\Controllers\PosController::destroy
* @see app/Http/Controllers/PosController.php:907
* @route '/pos/sale/{id}'
*/
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/pos/sale/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PosController::destroy
* @see app/Http/Controllers/PosController.php:907
* @route '/pos/sale/{id}'
*/
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::destroy
* @see app/Http/Controllers/PosController.php:907
* @route '/pos/sale/{id}'
*/
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\PosController::destroy
* @see app/Http/Controllers/PosController.php:907
* @route '/pos/sale/{id}'
*/
const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PosController::destroy
* @see app/Http/Controllers/PosController.php:907
* @route '/pos/sale/{id}'
*/
destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
export const returns = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: returns.url(options),
    method: 'get',
})

returns.definition = {
    methods: ["get","head"],
    url: '/returns',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
returns.url = (options?: RouteQueryOptions) => {
    return returns.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
returns.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: returns.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
returns.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: returns.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
const returnsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: returns.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
returnsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: returns.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PosController::returns
* @see app/Http/Controllers/PosController.php:992
* @route '/returns'
*/
returnsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: returns.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

returns.form = returnsForm

const PosController = { terminal, store, searchProducts, searchCustomers, quickCustomerStore, findProduct, printReceipt, processReturn, history, show, storePayment, destroy, returns }

export default PosController