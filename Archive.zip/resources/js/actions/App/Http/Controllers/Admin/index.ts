import CustomerDataCenterController from './CustomerDataCenterController'

const Admin = {
    CustomerDataCenterController: Object.assign(CustomerDataCenterController, CustomerDataCenterController),
}

export default Admin