import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ParkingOrderController::index
* @see app/Http/Controllers/ParkingOrderController.php:23
* @route '/parking_orders'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/parking_orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::index
* @see app/Http/Controllers/ParkingOrderController.php:23
* @route '/parking_orders'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::index
* @see app/Http/Controllers/ParkingOrderController.php:23
* @route '/parking_orders'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::index
* @see app/Http/Controllers/ParkingOrderController.php:23
* @route '/parking_orders'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::index
* @see app/Http/Controllers/ParkingOrderController.php:23
* @route '/parking_orders'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::index
* @see app/Http/Controllers/ParkingOrderController.php:23
* @route '/parking_orders'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::index
* @see app/Http/Controllers/ParkingOrderController.php:23
* @route '/parking_orders'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ParkingOrderController::create
* @see app/Http/Controllers/ParkingOrderController.php:129
* @route '/parking_orders/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/parking_orders/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::create
* @see app/Http/Controllers/ParkingOrderController.php:129
* @route '/parking_orders/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::create
* @see app/Http/Controllers/ParkingOrderController.php:129
* @route '/parking_orders/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::create
* @see app/Http/Controllers/ParkingOrderController.php:129
* @route '/parking_orders/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::create
* @see app/Http/Controllers/ParkingOrderController.php:129
* @route '/parking_orders/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::create
* @see app/Http/Controllers/ParkingOrderController.php:129
* @route '/parking_orders/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::create
* @see app/Http/Controllers/ParkingOrderController.php:129
* @route '/parking_orders/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\ParkingOrderController::store
* @see app/Http/Controllers/ParkingOrderController.php:141
* @route '/parking_orders'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/parking_orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::store
* @see app/Http/Controllers/ParkingOrderController.php:141
* @route '/parking_orders'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::store
* @see app/Http/Controllers/ParkingOrderController.php:141
* @route '/parking_orders'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::store
* @see app/Http/Controllers/ParkingOrderController.php:141
* @route '/parking_orders'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::store
* @see app/Http/Controllers/ParkingOrderController.php:141
* @route '/parking_orders'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\ParkingOrderController::show
* @see app/Http/Controllers/ParkingOrderController.php:233
* @route '/parking_orders/{parking_order}'
*/
export const show = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/parking_orders/{parking_order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::show
* @see app/Http/Controllers/ParkingOrderController.php:233
* @route '/parking_orders/{parking_order}'
*/
show.url = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { parking_order: args }
    }

    if (Array.isArray(args)) {
        args = {
            parking_order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        parking_order: args.parking_order,
    }

    return show.definition.url
            .replace('{parking_order}', parsedArgs.parking_order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::show
* @see app/Http/Controllers/ParkingOrderController.php:233
* @route '/parking_orders/{parking_order}'
*/
show.get = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::show
* @see app/Http/Controllers/ParkingOrderController.php:233
* @route '/parking_orders/{parking_order}'
*/
show.head = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::show
* @see app/Http/Controllers/ParkingOrderController.php:233
* @route '/parking_orders/{parking_order}'
*/
const showForm = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::show
* @see app/Http/Controllers/ParkingOrderController.php:233
* @route '/parking_orders/{parking_order}'
*/
showForm.get = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::show
* @see app/Http/Controllers/ParkingOrderController.php:233
* @route '/parking_orders/{parking_order}'
*/
showForm.head = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\ParkingOrderController::edit
* @see app/Http/Controllers/ParkingOrderController.php:247
* @route '/parking_orders/{parking_order}/edit'
*/
export const edit = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/parking_orders/{parking_order}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::edit
* @see app/Http/Controllers/ParkingOrderController.php:247
* @route '/parking_orders/{parking_order}/edit'
*/
edit.url = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { parking_order: args }
    }

    if (Array.isArray(args)) {
        args = {
            parking_order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        parking_order: args.parking_order,
    }

    return edit.definition.url
            .replace('{parking_order}', parsedArgs.parking_order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::edit
* @see app/Http/Controllers/ParkingOrderController.php:247
* @route '/parking_orders/{parking_order}/edit'
*/
edit.get = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::edit
* @see app/Http/Controllers/ParkingOrderController.php:247
* @route '/parking_orders/{parking_order}/edit'
*/
edit.head = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::edit
* @see app/Http/Controllers/ParkingOrderController.php:247
* @route '/parking_orders/{parking_order}/edit'
*/
const editForm = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::edit
* @see app/Http/Controllers/ParkingOrderController.php:247
* @route '/parking_orders/{parking_order}/edit'
*/
editForm.get = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::edit
* @see app/Http/Controllers/ParkingOrderController.php:247
* @route '/parking_orders/{parking_order}/edit'
*/
editForm.head = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\ParkingOrderController::update
* @see app/Http/Controllers/ParkingOrderController.php:258
* @route '/parking_orders/{parking_order}'
*/
export const update = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/parking_orders/{parking_order}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::update
* @see app/Http/Controllers/ParkingOrderController.php:258
* @route '/parking_orders/{parking_order}'
*/
update.url = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { parking_order: args }
    }

    if (Array.isArray(args)) {
        args = {
            parking_order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        parking_order: args.parking_order,
    }

    return update.definition.url
            .replace('{parking_order}', parsedArgs.parking_order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::update
* @see app/Http/Controllers/ParkingOrderController.php:258
* @route '/parking_orders/{parking_order}'
*/
update.put = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::update
* @see app/Http/Controllers/ParkingOrderController.php:258
* @route '/parking_orders/{parking_order}'
*/
update.patch = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::update
* @see app/Http/Controllers/ParkingOrderController.php:258
* @route '/parking_orders/{parking_order}'
*/
const updateForm = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::update
* @see app/Http/Controllers/ParkingOrderController.php:258
* @route '/parking_orders/{parking_order}'
*/
updateForm.put = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::update
* @see app/Http/Controllers/ParkingOrderController.php:258
* @route '/parking_orders/{parking_order}'
*/
updateForm.patch = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\ParkingOrderController::destroy
* @see app/Http/Controllers/ParkingOrderController.php:341
* @route '/parking_orders/{parking_order}'
*/
export const destroy = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/parking_orders/{parking_order}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::destroy
* @see app/Http/Controllers/ParkingOrderController.php:341
* @route '/parking_orders/{parking_order}'
*/
destroy.url = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { parking_order: args }
    }

    if (Array.isArray(args)) {
        args = {
            parking_order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        parking_order: args.parking_order,
    }

    return destroy.definition.url
            .replace('{parking_order}', parsedArgs.parking_order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::destroy
* @see app/Http/Controllers/ParkingOrderController.php:341
* @route '/parking_orders/{parking_order}'
*/
destroy.delete = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::destroy
* @see app/Http/Controllers/ParkingOrderController.php:341
* @route '/parking_orders/{parking_order}'
*/
const destroyForm = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::destroy
* @see app/Http/Controllers/ParkingOrderController.php:341
* @route '/parking_orders/{parking_order}'
*/
destroyForm.delete = (args: { parking_order: string | number } | [parking_order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\ParkingOrderController::addProducts
* @see app/Http/Controllers/ParkingOrderController.php:373
* @route '/parking_orders_more'
*/
export const addProducts = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addProducts.url(options),
    method: 'post',
})

addProducts.definition = {
    methods: ["post"],
    url: '/parking_orders_more',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::addProducts
* @see app/Http/Controllers/ParkingOrderController.php:373
* @route '/parking_orders_more'
*/
addProducts.url = (options?: RouteQueryOptions) => {
    return addProducts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::addProducts
* @see app/Http/Controllers/ParkingOrderController.php:373
* @route '/parking_orders_more'
*/
addProducts.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addProducts.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::addProducts
* @see app/Http/Controllers/ParkingOrderController.php:373
* @route '/parking_orders_more'
*/
const addProductsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: addProducts.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::addProducts
* @see app/Http/Controllers/ParkingOrderController.php:373
* @route '/parking_orders_more'
*/
addProductsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: addProducts.url(options),
    method: 'post',
})

addProducts.form = addProductsForm

/**
* @see \App\Http\Controllers\ParkingOrderController::editItem
* @see app/Http/Controllers/ParkingOrderController.php:434
* @route '/parking_orders/item/{id}/edit'
*/
export const editItem = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editItem.url(args, options),
    method: 'get',
})

editItem.definition = {
    methods: ["get","head"],
    url: '/parking_orders/item/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::editItem
* @see app/Http/Controllers/ParkingOrderController.php:434
* @route '/parking_orders/item/{id}/edit'
*/
editItem.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return editItem.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::editItem
* @see app/Http/Controllers/ParkingOrderController.php:434
* @route '/parking_orders/item/{id}/edit'
*/
editItem.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editItem.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::editItem
* @see app/Http/Controllers/ParkingOrderController.php:434
* @route '/parking_orders/item/{id}/edit'
*/
editItem.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editItem.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::editItem
* @see app/Http/Controllers/ParkingOrderController.php:434
* @route '/parking_orders/item/{id}/edit'
*/
const editItemForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editItem.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::editItem
* @see app/Http/Controllers/ParkingOrderController.php:434
* @route '/parking_orders/item/{id}/edit'
*/
editItemForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editItem.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::editItem
* @see app/Http/Controllers/ParkingOrderController.php:434
* @route '/parking_orders/item/{id}/edit'
*/
editItemForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editItem.form = editItemForm

/**
* @see \App\Http\Controllers\ParkingOrderController::updateItem
* @see app/Http/Controllers/ParkingOrderController.php:440
* @route '/parking_orders/item/{id}/update'
*/
export const updateItem = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItem.url(args, options),
    method: 'put',
})

updateItem.definition = {
    methods: ["put"],
    url: '/parking_orders/item/{id}/update',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::updateItem
* @see app/Http/Controllers/ParkingOrderController.php:440
* @route '/parking_orders/item/{id}/update'
*/
updateItem.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateItem.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::updateItem
* @see app/Http/Controllers/ParkingOrderController.php:440
* @route '/parking_orders/item/{id}/update'
*/
updateItem.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItem.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::updateItem
* @see app/Http/Controllers/ParkingOrderController.php:440
* @route '/parking_orders/item/{id}/update'
*/
const updateItemForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::updateItem
* @see app/Http/Controllers/ParkingOrderController.php:440
* @route '/parking_orders/item/{id}/update'
*/
updateItemForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateItem.form = updateItemForm

/**
* @see \App\Http\Controllers\ParkingOrderController::removeItem
* @see app/Http/Controllers/ParkingOrderController.php:482
* @route '/parking_orders/item/{id}/remove'
*/
export const removeItem = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeItem.url(args, options),
    method: 'delete',
})

removeItem.definition = {
    methods: ["delete"],
    url: '/parking_orders/item/{id}/remove',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::removeItem
* @see app/Http/Controllers/ParkingOrderController.php:482
* @route '/parking_orders/item/{id}/remove'
*/
removeItem.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return removeItem.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::removeItem
* @see app/Http/Controllers/ParkingOrderController.php:482
* @route '/parking_orders/item/{id}/remove'
*/
removeItem.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeItem.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::removeItem
* @see app/Http/Controllers/ParkingOrderController.php:482
* @route '/parking_orders/item/{id}/remove'
*/
const removeItemForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::removeItem
* @see app/Http/Controllers/ParkingOrderController.php:482
* @route '/parking_orders/item/{id}/remove'
*/
removeItemForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

removeItem.form = removeItemForm

/**
* @see \App\Http\Controllers\ParkingOrderController::pushUpcoming
* @see app/Http/Controllers/ParkingOrderController.php:512
* @route '/parking_orders/{unique_id}/push'
*/
export const pushUpcoming = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pushUpcoming.url(args, options),
    method: 'post',
})

pushUpcoming.definition = {
    methods: ["post"],
    url: '/parking_orders/{unique_id}/push',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ParkingOrderController::pushUpcoming
* @see app/Http/Controllers/ParkingOrderController.php:512
* @route '/parking_orders/{unique_id}/push'
*/
pushUpcoming.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return pushUpcoming.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ParkingOrderController::pushUpcoming
* @see app/Http/Controllers/ParkingOrderController.php:512
* @route '/parking_orders/{unique_id}/push'
*/
pushUpcoming.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pushUpcoming.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::pushUpcoming
* @see app/Http/Controllers/ParkingOrderController.php:512
* @route '/parking_orders/{unique_id}/push'
*/
const pushUpcomingForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pushUpcoming.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ParkingOrderController::pushUpcoming
* @see app/Http/Controllers/ParkingOrderController.php:512
* @route '/parking_orders/{unique_id}/push'
*/
pushUpcomingForm.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pushUpcoming.url(args, options),
    method: 'post',
})

pushUpcoming.form = pushUpcomingForm

const ParkingOrderController = { index, create, store, show, edit, update, destroy, addProducts, editItem, updateItem, removeItem, pushUpcoming }

export default ParkingOrderController