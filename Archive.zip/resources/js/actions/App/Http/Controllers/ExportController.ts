import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/exported-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::index
* @see app/Http/Controllers/ExportController.php:28
* @route '/exported-products'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ExportController::exports_add_more
* @see app/Http/Controllers/ExportController.php:320
* @route '/exports_add_more'
*/
export const exports_add_more = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exports_add_more.url(options),
    method: 'post',
})

exports_add_more.definition = {
    methods: ["post"],
    url: '/exports_add_more',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ExportController::exports_add_more
* @see app/Http/Controllers/ExportController.php:320
* @route '/exports_add_more'
*/
exports_add_more.url = (options?: RouteQueryOptions) => {
    return exports_add_more.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::exports_add_more
* @see app/Http/Controllers/ExportController.php:320
* @route '/exports_add_more'
*/
exports_add_more.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exports_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExportController::exports_add_more
* @see app/Http/Controllers/ExportController.php:320
* @route '/exports_add_more'
*/
const exports_add_moreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exports_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExportController::exports_add_more
* @see app/Http/Controllers/ExportController.php:320
* @route '/exports_add_more'
*/
exports_add_moreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exports_add_more.url(options),
    method: 'post',
})

exports_add_more.form = exports_add_moreForm

/**
* @see \App\Http\Controllers\ExportController::fetchExportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
export const fetchExportStatistics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fetchExportStatistics.url(options),
    method: 'get',
})

fetchExportStatistics.definition = {
    methods: ["get","head"],
    url: '/export-statistics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExportController::fetchExportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
fetchExportStatistics.url = (options?: RouteQueryOptions) => {
    return fetchExportStatistics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::fetchExportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
fetchExportStatistics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fetchExportStatistics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::fetchExportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
fetchExportStatistics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: fetchExportStatistics.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExportController::fetchExportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
const fetchExportStatisticsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: fetchExportStatistics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::fetchExportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
fetchExportStatisticsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: fetchExportStatistics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::fetchExportStatistics
* @see app/Http/Controllers/ExportController.php:150
* @route '/export-statistics'
*/
fetchExportStatisticsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: fetchExportStatistics.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

fetchExportStatistics.form = fetchExportStatisticsForm

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
export const check = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: check.url(args, options),
    method: 'get',
})

check.definition = {
    methods: ["get","head"],
    url: '/exports/check/{unique_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
check.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return check.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
check.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: check.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
check.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: check.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
const checkForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: check.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
checkForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: check.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::check
* @see app/Http/Controllers/ExportController.php:431
* @route '/exports/check/{unique_id}'
*/
checkForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: check.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

check.form = checkForm

/**
* @see \App\Http\Controllers\ExportController::edit_exports_status
* @see app/Http/Controllers/ExportController.php:112
* @route '/exported-products/editstatus/{unique_id}'
*/
export const edit_exports_status = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: edit_exports_status.url(args, options),
    method: 'put',
})

edit_exports_status.definition = {
    methods: ["put"],
    url: '/exported-products/editstatus/{unique_id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ExportController::edit_exports_status
* @see app/Http/Controllers/ExportController.php:112
* @route '/exported-products/editstatus/{unique_id}'
*/
edit_exports_status.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return edit_exports_status.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::edit_exports_status
* @see app/Http/Controllers/ExportController.php:112
* @route '/exported-products/editstatus/{unique_id}'
*/
edit_exports_status.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: edit_exports_status.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ExportController::edit_exports_status
* @see app/Http/Controllers/ExportController.php:112
* @route '/exported-products/editstatus/{unique_id}'
*/
const edit_exports_statusForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: edit_exports_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExportController::edit_exports_status
* @see app/Http/Controllers/ExportController.php:112
* @route '/exported-products/editstatus/{unique_id}'
*/
edit_exports_statusForm.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: edit_exports_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

edit_exports_status.form = edit_exports_statusForm

/**
* @see \App\Http\Controllers\ExportController::exports_change_to_loan
* @see app/Http/Controllers/ExportController.php:71
* @route '/exported-products/change_to_loan/{unique_id}'
*/
export const exports_change_to_loan = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: exports_change_to_loan.url(args, options),
    method: 'put',
})

exports_change_to_loan.definition = {
    methods: ["put"],
    url: '/exported-products/change_to_loan/{unique_id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ExportController::exports_change_to_loan
* @see app/Http/Controllers/ExportController.php:71
* @route '/exported-products/change_to_loan/{unique_id}'
*/
exports_change_to_loan.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return exports_change_to_loan.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::exports_change_to_loan
* @see app/Http/Controllers/ExportController.php:71
* @route '/exported-products/change_to_loan/{unique_id}'
*/
exports_change_to_loan.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: exports_change_to_loan.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ExportController::exports_change_to_loan
* @see app/Http/Controllers/ExportController.php:71
* @route '/exported-products/change_to_loan/{unique_id}'
*/
const exports_change_to_loanForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exports_change_to_loan.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExportController::exports_change_to_loan
* @see app/Http/Controllers/ExportController.php:71
* @route '/exported-products/change_to_loan/{unique_id}'
*/
exports_change_to_loanForm.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exports_change_to_loan.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

exports_change_to_loan.form = exports_change_to_loanForm

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
export const reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

reports.definition = {
    methods: ["get","head"],
    url: '/exports_reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
reports.url = (options?: RouteQueryOptions) => {
    return reports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reports.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
const reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExportController::reports
* @see app/Http/Controllers/ExportController.php:500
* @route '/exports_reports'
*/
reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

reports.form = reportsForm

const ExportController = { index, exports_add_more, fetchExportStatistics, check, edit_exports_status, exports_change_to_loan, reports }

export default ExportController