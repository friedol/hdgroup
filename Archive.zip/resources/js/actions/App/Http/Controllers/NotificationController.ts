import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\NotificationController::fetch
* @see app/Http/Controllers/NotificationController.php:15
* @route '/notifications/fetch'
*/
export const fetch = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fetch.url(options),
    method: 'get',
})

fetch.definition = {
    methods: ["get","head"],
    url: '/notifications/fetch',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NotificationController::fetch
* @see app/Http/Controllers/NotificationController.php:15
* @route '/notifications/fetch'
*/
fetch.url = (options?: RouteQueryOptions) => {
    return fetch.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::fetch
* @see app/Http/Controllers/NotificationController.php:15
* @route '/notifications/fetch'
*/
fetch.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fetch.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\NotificationController::fetch
* @see app/Http/Controllers/NotificationController.php:15
* @route '/notifications/fetch'
*/
fetch.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: fetch.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\NotificationController::fetch
* @see app/Http/Controllers/NotificationController.php:15
* @route '/notifications/fetch'
*/
const fetchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: fetch.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\NotificationController::fetch
* @see app/Http/Controllers/NotificationController.php:15
* @route '/notifications/fetch'
*/
fetchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: fetch.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\NotificationController::fetch
* @see app/Http/Controllers/NotificationController.php:15
* @route '/notifications/fetch'
*/
fetchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: fetch.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

fetch.form = fetchForm

const NotificationController = { fetch }

export default NotificationController