import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::dashboard
* @see app/Http/Controllers/DashboardController.php:20
* @route '/dashboard'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\DashboardController::manufacturingDashboard
* @see app/Http/Controllers/DashboardController.php:521
* @route '/manufacturing/dashboard'
*/
export const manufacturingDashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: manufacturingDashboard.url(options),
    method: 'get',
})

manufacturingDashboard.definition = {
    methods: ["get","head"],
    url: '/manufacturing/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::manufacturingDashboard
* @see app/Http/Controllers/DashboardController.php:521
* @route '/manufacturing/dashboard'
*/
manufacturingDashboard.url = (options?: RouteQueryOptions) => {
    return manufacturingDashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::manufacturingDashboard
* @see app/Http/Controllers/DashboardController.php:521
* @route '/manufacturing/dashboard'
*/
manufacturingDashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: manufacturingDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::manufacturingDashboard
* @see app/Http/Controllers/DashboardController.php:521
* @route '/manufacturing/dashboard'
*/
manufacturingDashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: manufacturingDashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DashboardController::manufacturingDashboard
* @see app/Http/Controllers/DashboardController.php:521
* @route '/manufacturing/dashboard'
*/
const manufacturingDashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: manufacturingDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::manufacturingDashboard
* @see app/Http/Controllers/DashboardController.php:521
* @route '/manufacturing/dashboard'
*/
manufacturingDashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: manufacturingDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::manufacturingDashboard
* @see app/Http/Controllers/DashboardController.php:521
* @route '/manufacturing/dashboard'
*/
manufacturingDashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: manufacturingDashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

manufacturingDashboard.form = manufacturingDashboardForm

const DashboardController = { dashboard, manufacturingDashboard }

export default DashboardController