import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RollProductionController::index
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/production/roll-based',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RollProductionController::index
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RollProductionController::index
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RollProductionController::index
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RollProductionController::index
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RollProductionController::index
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RollProductionController::index
* @see app/Http/Controllers/RollProductionController.php:29
* @route '/production/roll-based'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\RollProductionController::simulate
* @see app/Http/Controllers/RollProductionController.php:66
* @route '/production/roll-based/simulate'
*/
export const simulate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simulate.url(options),
    method: 'post',
})

simulate.definition = {
    methods: ["post"],
    url: '/production/roll-based/simulate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RollProductionController::simulate
* @see app/Http/Controllers/RollProductionController.php:66
* @route '/production/roll-based/simulate'
*/
simulate.url = (options?: RouteQueryOptions) => {
    return simulate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RollProductionController::simulate
* @see app/Http/Controllers/RollProductionController.php:66
* @route '/production/roll-based/simulate'
*/
simulate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simulate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RollProductionController::simulate
* @see app/Http/Controllers/RollProductionController.php:66
* @route '/production/roll-based/simulate'
*/
const simulateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: simulate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RollProductionController::simulate
* @see app/Http/Controllers/RollProductionController.php:66
* @route '/production/roll-based/simulate'
*/
simulateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: simulate.url(options),
    method: 'post',
})

simulate.form = simulateForm

/**
* @see \App\Http\Controllers\RollProductionController::split
* @see app/Http/Controllers/RollProductionController.php:233
* @route '/production/roll-based/split'
*/
export const split = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: split.url(options),
    method: 'post',
})

split.definition = {
    methods: ["post"],
    url: '/production/roll-based/split',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RollProductionController::split
* @see app/Http/Controllers/RollProductionController.php:233
* @route '/production/roll-based/split'
*/
split.url = (options?: RouteQueryOptions) => {
    return split.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RollProductionController::split
* @see app/Http/Controllers/RollProductionController.php:233
* @route '/production/roll-based/split'
*/
split.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: split.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RollProductionController::split
* @see app/Http/Controllers/RollProductionController.php:233
* @route '/production/roll-based/split'
*/
const splitForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: split.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RollProductionController::split
* @see app/Http/Controllers/RollProductionController.php:233
* @route '/production/roll-based/split'
*/
splitForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: split.url(options),
    method: 'post',
})

split.form = splitForm

/**
* @see \App\Http\Controllers\RollProductionController::produce
* @see app/Http/Controllers/RollProductionController.php:253
* @route '/production/roll-based/produce'
*/
export const produce = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: produce.url(options),
    method: 'post',
})

produce.definition = {
    methods: ["post"],
    url: '/production/roll-based/produce',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RollProductionController::produce
* @see app/Http/Controllers/RollProductionController.php:253
* @route '/production/roll-based/produce'
*/
produce.url = (options?: RouteQueryOptions) => {
    return produce.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RollProductionController::produce
* @see app/Http/Controllers/RollProductionController.php:253
* @route '/production/roll-based/produce'
*/
produce.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: produce.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RollProductionController::produce
* @see app/Http/Controllers/RollProductionController.php:253
* @route '/production/roll-based/produce'
*/
const produceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: produce.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RollProductionController::produce
* @see app/Http/Controllers/RollProductionController.php:253
* @route '/production/roll-based/produce'
*/
produceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: produce.url(options),
    method: 'post',
})

produce.form = produceForm

const RollProductionController = { index, simulate, split, produce }

export default RollProductionController