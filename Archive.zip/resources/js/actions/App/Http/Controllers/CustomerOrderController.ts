import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CustomerOrderController::indexCrud
* @see app/Http/Controllers/CustomerOrderController.php:290
* @route '/orders-crud'
*/
export const indexCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

indexCrud.definition = {
    methods: ["get","head"],
    url: '/orders-crud',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::indexCrud
* @see app/Http/Controllers/CustomerOrderController.php:290
* @route '/orders-crud'
*/
indexCrud.url = (options?: RouteQueryOptions) => {
    return indexCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::indexCrud
* @see app/Http/Controllers/CustomerOrderController.php:290
* @route '/orders-crud'
*/
indexCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::indexCrud
* @see app/Http/Controllers/CustomerOrderController.php:290
* @route '/orders-crud'
*/
indexCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::indexCrud
* @see app/Http/Controllers/CustomerOrderController.php:290
* @route '/orders-crud'
*/
const indexCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::indexCrud
* @see app/Http/Controllers/CustomerOrderController.php:290
* @route '/orders-crud'
*/
indexCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::indexCrud
* @see app/Http/Controllers/CustomerOrderController.php:290
* @route '/orders-crud'
*/
indexCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexCrud.form = indexCrudForm

/**
* @see \App\Http\Controllers\CustomerOrderController::createCrud
* @see app/Http/Controllers/CustomerOrderController.php:1096
* @route '/orders-crud/create'
*/
export const createCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

createCrud.definition = {
    methods: ["get","head"],
    url: '/orders-crud/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::createCrud
* @see app/Http/Controllers/CustomerOrderController.php:1096
* @route '/orders-crud/create'
*/
createCrud.url = (options?: RouteQueryOptions) => {
    return createCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::createCrud
* @see app/Http/Controllers/CustomerOrderController.php:1096
* @route '/orders-crud/create'
*/
createCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::createCrud
* @see app/Http/Controllers/CustomerOrderController.php:1096
* @route '/orders-crud/create'
*/
createCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::createCrud
* @see app/Http/Controllers/CustomerOrderController.php:1096
* @route '/orders-crud/create'
*/
const createCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::createCrud
* @see app/Http/Controllers/CustomerOrderController.php:1096
* @route '/orders-crud/create'
*/
createCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::createCrud
* @see app/Http/Controllers/CustomerOrderController.php:1096
* @route '/orders-crud/create'
*/
createCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

createCrud.form = createCrudForm

/**
* @see \App\Http\Controllers\CustomerOrderController::storeCrud
* @see app/Http/Controllers/CustomerOrderController.php:1278
* @route '/orders-crud'
*/
export const storeCrud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

storeCrud.definition = {
    methods: ["post"],
    url: '/orders-crud',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::storeCrud
* @see app/Http/Controllers/CustomerOrderController.php:1278
* @route '/orders-crud'
*/
storeCrud.url = (options?: RouteQueryOptions) => {
    return storeCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::storeCrud
* @see app/Http/Controllers/CustomerOrderController.php:1278
* @route '/orders-crud'
*/
storeCrud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::storeCrud
* @see app/Http/Controllers/CustomerOrderController.php:1278
* @route '/orders-crud'
*/
const storeCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::storeCrud
* @see app/Http/Controllers/CustomerOrderController.php:1278
* @route '/orders-crud'
*/
storeCrudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

storeCrud.form = storeCrudForm

/**
* @see \App\Http\Controllers\CustomerOrderController::showCrud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
export const showCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

showCrud.definition = {
    methods: ["get","head"],
    url: '/orders-crud/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::showCrud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
showCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return showCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::showCrud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
showCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::showCrud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
showCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::showCrud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
const showCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::showCrud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
showCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::showCrud
* @see app/Http/Controllers/CustomerOrderController.php:985
* @route '/orders-crud/{id}'
*/
showCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showCrud.form = showCrudForm

/**
* @see \App\Http\Controllers\CustomerOrderController::editCrud
* @see app/Http/Controllers/CustomerOrderController.php:1101
* @route '/orders-crud/{id}/edit'
*/
export const editCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

editCrud.definition = {
    methods: ["get","head"],
    url: '/orders-crud/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::editCrud
* @see app/Http/Controllers/CustomerOrderController.php:1101
* @route '/orders-crud/{id}/edit'
*/
editCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return editCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::editCrud
* @see app/Http/Controllers/CustomerOrderController.php:1101
* @route '/orders-crud/{id}/edit'
*/
editCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::editCrud
* @see app/Http/Controllers/CustomerOrderController.php:1101
* @route '/orders-crud/{id}/edit'
*/
editCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::editCrud
* @see app/Http/Controllers/CustomerOrderController.php:1101
* @route '/orders-crud/{id}/edit'
*/
const editCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::editCrud
* @see app/Http/Controllers/CustomerOrderController.php:1101
* @route '/orders-crud/{id}/edit'
*/
editCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::editCrud
* @see app/Http/Controllers/CustomerOrderController.php:1101
* @route '/orders-crud/{id}/edit'
*/
editCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editCrud.form = editCrudForm

/**
* @see \App\Http\Controllers\CustomerOrderController::updateCrud
* @see app/Http/Controllers/CustomerOrderController.php:1219
* @route '/orders-crud/{id}'
*/
export const updateCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

updateCrud.definition = {
    methods: ["put"],
    url: '/orders-crud/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::updateCrud
* @see app/Http/Controllers/CustomerOrderController.php:1219
* @route '/orders-crud/{id}'
*/
updateCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::updateCrud
* @see app/Http/Controllers/CustomerOrderController.php:1219
* @route '/orders-crud/{id}'
*/
updateCrud.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::updateCrud
* @see app/Http/Controllers/CustomerOrderController.php:1219
* @route '/orders-crud/{id}'
*/
const updateCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::updateCrud
* @see app/Http/Controllers/CustomerOrderController.php:1219
* @route '/orders-crud/{id}'
*/
updateCrudForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateCrud.form = updateCrudForm

/**
* @see \App\Http\Controllers\CustomerOrderController::destroyCrud
* @see app/Http/Controllers/CustomerOrderController.php:1192
* @route '/orders-crud/{id}'
*/
export const destroyCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

destroyCrud.definition = {
    methods: ["delete"],
    url: '/orders-crud/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::destroyCrud
* @see app/Http/Controllers/CustomerOrderController.php:1192
* @route '/orders-crud/{id}'
*/
destroyCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroyCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::destroyCrud
* @see app/Http/Controllers/CustomerOrderController.php:1192
* @route '/orders-crud/{id}'
*/
destroyCrud.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::destroyCrud
* @see app/Http/Controllers/CustomerOrderController.php:1192
* @route '/orders-crud/{id}'
*/
const destroyCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::destroyCrud
* @see app/Http/Controllers/CustomerOrderController.php:1192
* @route '/orders-crud/{id}'
*/
destroyCrudForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyCrud.form = destroyCrudForm

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::index
* @see app/Http/Controllers/CustomerOrderController.php:89
* @route '/orders'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\CustomerOrderController::store
* @see app/Http/Controllers/CustomerOrderController.php:677
* @route '/orders'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::store
* @see app/Http/Controllers/CustomerOrderController.php:677
* @route '/orders'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::store
* @see app/Http/Controllers/CustomerOrderController.php:677
* @route '/orders'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::store
* @see app/Http/Controllers/CustomerOrderController.php:677
* @route '/orders'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::store
* @see app/Http/Controllers/CustomerOrderController.php:677
* @route '/orders'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
export const show = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/orders/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
show.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return show.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
show.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
show.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
const showForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
showForm.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::show
* @see app/Http/Controllers/CustomerOrderController.php:950
* @route '/orders/{order}'
*/
showForm.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
export const edit = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/orders/{order}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
edit.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return edit.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
edit.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
edit.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
const editForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
editForm.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::edit
* @see app/Http/Controllers/CustomerOrderController.php:1286
* @route '/orders/{order}/edit'
*/
editForm.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
export const update = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/orders/{order}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
update.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return update.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
update.put = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
update.patch = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
const updateForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
updateForm.put = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::update
* @see app/Http/Controllers/CustomerOrderController.php:1298
* @route '/orders/{order}'
*/
updateForm.patch = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1399
* @route '/orders/{order}'
*/
export const destroy = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/orders/{order}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1399
* @route '/orders/{order}'
*/
destroy.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return destroy.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1399
* @route '/orders/{order}'
*/
destroy.delete = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1399
* @route '/orders/{order}'
*/
const destroyForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::destroy
* @see app/Http/Controllers/CustomerOrderController.php:1399
* @route '/orders/{order}'
*/
destroyForm.delete = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\CustomerOrderController::general_orders
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
export const general_orders = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: general_orders.url(options),
    method: 'get',
})

general_orders.definition = {
    methods: ["get","head"],
    url: '/general-orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::general_orders
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
general_orders.url = (options?: RouteQueryOptions) => {
    return general_orders.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::general_orders
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
general_orders.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: general_orders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::general_orders
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
general_orders.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: general_orders.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::general_orders
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
const general_ordersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: general_orders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::general_orders
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
general_ordersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: general_orders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::general_orders
* @see app/Http/Controllers/CustomerOrderController.php:94
* @route '/general-orders'
*/
general_ordersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: general_orders.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

general_orders.form = general_ordersForm

/**
* @see \App\Http\Controllers\CustomerOrderController::online_orders
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
export const online_orders = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: online_orders.url(options),
    method: 'get',
})

online_orders.definition = {
    methods: ["get","head"],
    url: '/online-orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::online_orders
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
online_orders.url = (options?: RouteQueryOptions) => {
    return online_orders.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::online_orders
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
online_orders.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: online_orders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::online_orders
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
online_orders.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: online_orders.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::online_orders
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
const online_ordersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: online_orders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::online_orders
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
online_ordersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: online_orders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::online_orders
* @see app/Http/Controllers/CustomerOrderController.php:379
* @route '/online-orders'
*/
online_ordersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: online_orders.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

online_orders.form = online_ordersForm

/**
* @see \App\Http\Controllers\CustomerOrderController::showOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
export const showOnlineOrder = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showOnlineOrder.url(args, options),
    method: 'get',
})

showOnlineOrder.definition = {
    methods: ["get","head"],
    url: '/online-orders/{unique_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::showOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
showOnlineOrder.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return showOnlineOrder.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::showOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
showOnlineOrder.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showOnlineOrder.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::showOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
showOnlineOrder.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showOnlineOrder.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::showOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
const showOnlineOrderForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showOnlineOrder.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::showOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
showOnlineOrderForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showOnlineOrder.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::showOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1416
* @route '/online-orders/{unique_id}'
*/
showOnlineOrderForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showOnlineOrder.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showOnlineOrder.form = showOnlineOrderForm

/**
* @see \App\Http\Controllers\CustomerOrderController::destroyOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1645
* @route '/online-orders/{unique_id}'
*/
export const destroyOnlineOrder = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyOnlineOrder.url(args, options),
    method: 'delete',
})

destroyOnlineOrder.definition = {
    methods: ["delete"],
    url: '/online-orders/{unique_id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::destroyOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1645
* @route '/online-orders/{unique_id}'
*/
destroyOnlineOrder.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return destroyOnlineOrder.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::destroyOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1645
* @route '/online-orders/{unique_id}'
*/
destroyOnlineOrder.delete = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyOnlineOrder.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::destroyOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1645
* @route '/online-orders/{unique_id}'
*/
const destroyOnlineOrderForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyOnlineOrder.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::destroyOnlineOrder
* @see app/Http/Controllers/CustomerOrderController.php:1645
* @route '/online-orders/{unique_id}'
*/
destroyOnlineOrderForm.delete = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyOnlineOrder.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyOnlineOrder.form = destroyOnlineOrderForm

/**
* @see \App\Http\Controllers\CustomerOrderController::approveOrder
* @see app/Http/Controllers/CustomerOrderController.php:1491
* @route '/online-orders/{unique_id}/approve'
*/
export const approveOrder = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveOrder.url(args, options),
    method: 'post',
})

approveOrder.definition = {
    methods: ["post"],
    url: '/online-orders/{unique_id}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::approveOrder
* @see app/Http/Controllers/CustomerOrderController.php:1491
* @route '/online-orders/{unique_id}/approve'
*/
approveOrder.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return approveOrder.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::approveOrder
* @see app/Http/Controllers/CustomerOrderController.php:1491
* @route '/online-orders/{unique_id}/approve'
*/
approveOrder.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveOrder.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::approveOrder
* @see app/Http/Controllers/CustomerOrderController.php:1491
* @route '/online-orders/{unique_id}/approve'
*/
const approveOrderForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approveOrder.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::approveOrder
* @see app/Http/Controllers/CustomerOrderController.php:1491
* @route '/online-orders/{unique_id}/approve'
*/
approveOrderForm.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approveOrder.url(args, options),
    method: 'post',
})

approveOrder.form = approveOrderForm

/**
* @see \App\Http\Controllers\CustomerOrderController::rejectOrder
* @see app/Http/Controllers/CustomerOrderController.php:1584
* @route '/online-orders/{unique_id}/reject'
*/
export const rejectOrder = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectOrder.url(args, options),
    method: 'post',
})

rejectOrder.definition = {
    methods: ["post"],
    url: '/online-orders/{unique_id}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::rejectOrder
* @see app/Http/Controllers/CustomerOrderController.php:1584
* @route '/online-orders/{unique_id}/reject'
*/
rejectOrder.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return rejectOrder.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::rejectOrder
* @see app/Http/Controllers/CustomerOrderController.php:1584
* @route '/online-orders/{unique_id}/reject'
*/
rejectOrder.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectOrder.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::rejectOrder
* @see app/Http/Controllers/CustomerOrderController.php:1584
* @route '/online-orders/{unique_id}/reject'
*/
const rejectOrderForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rejectOrder.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::rejectOrder
* @see app/Http/Controllers/CustomerOrderController.php:1584
* @route '/online-orders/{unique_id}/reject'
*/
rejectOrderForm.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rejectOrder.url(args, options),
    method: 'post',
})

rejectOrder.form = rejectOrderForm

/**
* @see \App\Http\Controllers\CustomerOrderController::markAsPaid
* @see app/Http/Controllers/CustomerOrderController.php:1319
* @route '/online-orders/{unique_id}/pay'
*/
export const markAsPaid = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAsPaid.url(args, options),
    method: 'post',
})

markAsPaid.definition = {
    methods: ["post"],
    url: '/online-orders/{unique_id}/pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::markAsPaid
* @see app/Http/Controllers/CustomerOrderController.php:1319
* @route '/online-orders/{unique_id}/pay'
*/
markAsPaid.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return markAsPaid.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::markAsPaid
* @see app/Http/Controllers/CustomerOrderController.php:1319
* @route '/online-orders/{unique_id}/pay'
*/
markAsPaid.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAsPaid.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::markAsPaid
* @see app/Http/Controllers/CustomerOrderController.php:1319
* @route '/online-orders/{unique_id}/pay'
*/
const markAsPaidForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markAsPaid.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::markAsPaid
* @see app/Http/Controllers/CustomerOrderController.php:1319
* @route '/online-orders/{unique_id}/pay'
*/
markAsPaidForm.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markAsPaid.url(args, options),
    method: 'post',
})

markAsPaid.form = markAsPaidForm

/**
* @see \App\Http\Controllers\CustomerOrderController::updateDeliveryStatus
* @see app/Http/Controllers/CustomerOrderController.php:1615
* @route '/online-orders/{unique_id}/delivery-status'
*/
export const updateDeliveryStatus = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateDeliveryStatus.url(args, options),
    method: 'post',
})

updateDeliveryStatus.definition = {
    methods: ["post"],
    url: '/online-orders/{unique_id}/delivery-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::updateDeliveryStatus
* @see app/Http/Controllers/CustomerOrderController.php:1615
* @route '/online-orders/{unique_id}/delivery-status'
*/
updateDeliveryStatus.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return updateDeliveryStatus.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::updateDeliveryStatus
* @see app/Http/Controllers/CustomerOrderController.php:1615
* @route '/online-orders/{unique_id}/delivery-status'
*/
updateDeliveryStatus.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateDeliveryStatus.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::updateDeliveryStatus
* @see app/Http/Controllers/CustomerOrderController.php:1615
* @route '/online-orders/{unique_id}/delivery-status'
*/
const updateDeliveryStatusForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateDeliveryStatus.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::updateDeliveryStatus
* @see app/Http/Controllers/CustomerOrderController.php:1615
* @route '/online-orders/{unique_id}/delivery-status'
*/
updateDeliveryStatusForm.post = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateDeliveryStatus.url(args, options),
    method: 'post',
})

updateDeliveryStatus.form = updateDeliveryStatusForm

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_add_more
* @see app/Http/Controllers/CustomerOrderController.php:852
* @route '/orders_add_more'
*/
export const orders_add_more = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: orders_add_more.url(options),
    method: 'post',
})

orders_add_more.definition = {
    methods: ["post"],
    url: '/orders_add_more',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_add_more
* @see app/Http/Controllers/CustomerOrderController.php:852
* @route '/orders_add_more'
*/
orders_add_more.url = (options?: RouteQueryOptions) => {
    return orders_add_more.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_add_more
* @see app/Http/Controllers/CustomerOrderController.php:852
* @route '/orders_add_more'
*/
orders_add_more.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: orders_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_add_more
* @see app/Http/Controllers/CustomerOrderController.php:852
* @route '/orders_add_more'
*/
const orders_add_moreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: orders_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::orders_add_more
* @see app/Http/Controllers/CustomerOrderController.php:852
* @route '/orders_add_more'
*/
orders_add_moreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: orders_add_more.url(options),
    method: 'post',
})

orders_add_more.form = orders_add_moreForm

/**
* @see \App\Http\Controllers\CustomerOrderController::edit_orders_status
* @see app/Http/Controllers/CustomerOrderController.php:685
* @route '/orders/editstatus/{unique_id}'
*/
export const edit_orders_status = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: edit_orders_status.url(args, options),
    method: 'put',
})

edit_orders_status.definition = {
    methods: ["put"],
    url: '/orders/editstatus/{unique_id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::edit_orders_status
* @see app/Http/Controllers/CustomerOrderController.php:685
* @route '/orders/editstatus/{unique_id}'
*/
edit_orders_status.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return edit_orders_status.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::edit_orders_status
* @see app/Http/Controllers/CustomerOrderController.php:685
* @route '/orders/editstatus/{unique_id}'
*/
edit_orders_status.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: edit_orders_status.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::edit_orders_status
* @see app/Http/Controllers/CustomerOrderController.php:685
* @route '/orders/editstatus/{unique_id}'
*/
const edit_orders_statusForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: edit_orders_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::edit_orders_status
* @see app/Http/Controllers/CustomerOrderController.php:685
* @route '/orders/editstatus/{unique_id}'
*/
edit_orders_statusForm.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: edit_orders_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

edit_orders_status.form = edit_orders_statusForm

/**
* @see \App\Http\Controllers\CustomerOrderController::toggleStatus
* @see app/Http/Controllers/CustomerOrderController.php:528
* @route '/cart-toggle-status'
*/
export const toggleStatus = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleStatus.url(options),
    method: 'post',
})

toggleStatus.definition = {
    methods: ["post"],
    url: '/cart-toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerOrderController::toggleStatus
* @see app/Http/Controllers/CustomerOrderController.php:528
* @route '/cart-toggle-status'
*/
toggleStatus.url = (options?: RouteQueryOptions) => {
    return toggleStatus.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerOrderController::toggleStatus
* @see app/Http/Controllers/CustomerOrderController.php:528
* @route '/cart-toggle-status'
*/
toggleStatus.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleStatus.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::toggleStatus
* @see app/Http/Controllers/CustomerOrderController.php:528
* @route '/cart-toggle-status'
*/
const toggleStatusForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleStatus.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CustomerOrderController::toggleStatus
* @see app/Http/Controllers/CustomerOrderController.php:528
* @route '/cart-toggle-status'
*/
toggleStatusForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleStatus.url(options),
    method: 'post',
})

toggleStatus.form = toggleStatusForm

const CustomerOrderController = { indexCrud, createCrud, storeCrud, showCrud, editCrud, updateCrud, destroyCrud, index, store, show, edit, update, destroy, general_orders, online_orders, showOnlineOrder, destroyOnlineOrder, approveOrder, rejectOrder, markAsPaid, updateDeliveryStatus, orders_add_more, edit_orders_status, toggleStatus }

export default CustomerOrderController