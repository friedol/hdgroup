import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/finance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dashboard
* @see app/Http/Controllers/FinancialAnalyticsController.php:24
* @route '/finance'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
const cashFlowLedger6676f9c68bb76fea750ca09620e30642 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cashFlowLedger6676f9c68bb76fea750ca09620e30642.url(options),
    method: 'get',
})

cashFlowLedger6676f9c68bb76fea750ca09620e30642.definition = {
    methods: ["get","head"],
    url: '/finance/cash-flow',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
cashFlowLedger6676f9c68bb76fea750ca09620e30642.url = (options?: RouteQueryOptions) => {
    return cashFlowLedger6676f9c68bb76fea750ca09620e30642.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
cashFlowLedger6676f9c68bb76fea750ca09620e30642.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cashFlowLedger6676f9c68bb76fea750ca09620e30642.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
cashFlowLedger6676f9c68bb76fea750ca09620e30642.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cashFlowLedger6676f9c68bb76fea750ca09620e30642.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
const cashFlowLedger6676f9c68bb76fea750ca09620e30642Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashFlowLedger6676f9c68bb76fea750ca09620e30642.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
cashFlowLedger6676f9c68bb76fea750ca09620e30642Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashFlowLedger6676f9c68bb76fea750ca09620e30642.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow'
*/
cashFlowLedger6676f9c68bb76fea750ca09620e30642Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashFlowLedger6676f9c68bb76fea750ca09620e30642.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

cashFlowLedger6676f9c68bb76fea750ca09620e30642.form = cashFlowLedger6676f9c68bb76fea750ca09620e30642Form
/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
const cashFlowLedgerececef4efc6754e2d15f474f75a646ee = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cashFlowLedgerececef4efc6754e2d15f474f75a646ee.url(options),
    method: 'get',
})

cashFlowLedgerececef4efc6754e2d15f474f75a646ee.definition = {
    methods: ["get","head"],
    url: '/finance/cash-flow/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
cashFlowLedgerececef4efc6754e2d15f474f75a646ee.url = (options?: RouteQueryOptions) => {
    return cashFlowLedgerececef4efc6754e2d15f474f75a646ee.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
cashFlowLedgerececef4efc6754e2d15f474f75a646ee.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cashFlowLedgerececef4efc6754e2d15f474f75a646ee.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
cashFlowLedgerececef4efc6754e2d15f474f75a646ee.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cashFlowLedgerececef4efc6754e2d15f474f75a646ee.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
const cashFlowLedgerececef4efc6754e2d15f474f75a646eeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashFlowLedgerececef4efc6754e2d15f474f75a646ee.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
cashFlowLedgerececef4efc6754e2d15f474f75a646eeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashFlowLedgerececef4efc6754e2d15f474f75a646ee.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::cashFlowLedger
* @see app/Http/Controllers/FinancialAnalyticsController.php:165
* @route '/finance/cash-flow/print'
*/
cashFlowLedgerececef4efc6754e2d15f474f75a646eeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashFlowLedgerececef4efc6754e2d15f474f75a646ee.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

cashFlowLedgerececef4efc6754e2d15f474f75a646ee.form = cashFlowLedgerececef4efc6754e2d15f474f75a646eeForm

export const cashFlowLedger = {
    '/finance/cash-flow': cashFlowLedger6676f9c68bb76fea750ca09620e30642,
    '/finance/cash-flow/print': cashFlowLedgerececef4efc6754e2d15f474f75a646ee,
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
export const dailyReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyReport.url(options),
    method: 'get',
})

dailyReport.definition = {
    methods: ["get","head"],
    url: '/finance/daily-report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
dailyReport.url = (options?: RouteQueryOptions) => {
    return dailyReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
dailyReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyReport.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
dailyReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dailyReport.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
const dailyReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReport.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
dailyReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReport.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReport
* @see app/Http/Controllers/FinancialAnalyticsController.php:1450
* @route '/finance/daily-report'
*/
dailyReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReport.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dailyReport.form = dailyReportForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrint
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
export const dailyReportPrint = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyReportPrint.url(options),
    method: 'get',
})

dailyReportPrint.definition = {
    methods: ["get","head"],
    url: '/finance/daily-report/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrint
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
dailyReportPrint.url = (options?: RouteQueryOptions) => {
    return dailyReportPrint.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrint
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
dailyReportPrint.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyReportPrint.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrint
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
dailyReportPrint.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dailyReportPrint.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrint
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
const dailyReportPrintForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReportPrint.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrint
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
dailyReportPrintForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReportPrint.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrint
* @see app/Http/Controllers/FinancialAnalyticsController.php:1491
* @route '/finance/daily-report/pdf'
*/
dailyReportPrintForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReportPrint.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dailyReportPrint.form = dailyReportPrintForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportDownloadPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
export const dailyReportDownloadPDF = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyReportDownloadPDF.url(options),
    method: 'get',
})

dailyReportDownloadPDF.definition = {
    methods: ["get","head"],
    url: '/finance/daily-report/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportDownloadPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
dailyReportDownloadPDF.url = (options?: RouteQueryOptions) => {
    return dailyReportDownloadPDF.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportDownloadPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
dailyReportDownloadPDF.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyReportDownloadPDF.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportDownloadPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
dailyReportDownloadPDF.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dailyReportDownloadPDF.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportDownloadPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
const dailyReportDownloadPDFForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReportDownloadPDF.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportDownloadPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
dailyReportDownloadPDFForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReportDownloadPDF.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportDownloadPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1563
* @route '/finance/daily-report/download'
*/
dailyReportDownloadPDFForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReportDownloadPDF.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dailyReportDownloadPDF.form = dailyReportDownloadPDFForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrintPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
export const dailyReportPrintPDF = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyReportPrintPDF.url(options),
    method: 'get',
})

dailyReportPrintPDF.definition = {
    methods: ["get","head"],
    url: '/finance/daily-report/print-pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrintPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
dailyReportPrintPDF.url = (options?: RouteQueryOptions) => {
    return dailyReportPrintPDF.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrintPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
dailyReportPrintPDF.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyReportPrintPDF.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrintPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
dailyReportPrintPDF.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dailyReportPrintPDF.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrintPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
const dailyReportPrintPDFForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReportPrintPDF.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrintPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
dailyReportPrintPDFForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReportPrintPDF.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::dailyReportPrintPDF
* @see app/Http/Controllers/FinancialAnalyticsController.php:1646
* @route '/finance/daily-report/print-pdf'
*/
dailyReportPrintPDFForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dailyReportPrintPDF.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dailyReportPrintPDF.form = dailyReportPrintPDFForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
export const balanceSheet = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balanceSheet.url(options),
    method: 'get',
})

balanceSheet.definition = {
    methods: ["get","head"],
    url: '/finance/balance-sheet',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
balanceSheet.url = (options?: RouteQueryOptions) => {
    return balanceSheet.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
balanceSheet.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balanceSheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
balanceSheet.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: balanceSheet.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
const balanceSheetForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balanceSheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
balanceSheetForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balanceSheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheet
* @see app/Http/Controllers/FinancialAnalyticsController.php:632
* @route '/finance/balance-sheet'
*/
balanceSheetForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balanceSheet.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

balanceSheet.form = balanceSheetForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheetPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:849
* @route '/finance/balance-sheet/pdf'
*/
export const balanceSheetPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balanceSheetPdf.url(options),
    method: 'get',
})

balanceSheetPdf.definition = {
    methods: ["get","head"],
    url: '/finance/balance-sheet/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheetPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:849
* @route '/finance/balance-sheet/pdf'
*/
balanceSheetPdf.url = (options?: RouteQueryOptions) => {
    return balanceSheetPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheetPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:849
* @route '/finance/balance-sheet/pdf'
*/
balanceSheetPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balanceSheetPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheetPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:849
* @route '/finance/balance-sheet/pdf'
*/
balanceSheetPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: balanceSheetPdf.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheetPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:849
* @route '/finance/balance-sheet/pdf'
*/
const balanceSheetPdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balanceSheetPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheetPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:849
* @route '/finance/balance-sheet/pdf'
*/
balanceSheetPdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balanceSheetPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::balanceSheetPdf
* @see app/Http/Controllers/FinancialAnalyticsController.php:849
* @route '/finance/balance-sheet/pdf'
*/
balanceSheetPdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balanceSheetPdf.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

balanceSheetPdf.form = balanceSheetPdfForm

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
export const reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

reports.definition = {
    methods: ["get","head"],
    url: '/finance/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
reports.url = (options?: RouteQueryOptions) => {
    return reports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reports.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
const reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FinancialAnalyticsController::reports
* @see app/Http/Controllers/FinancialAnalyticsController.php:1088
* @route '/finance/reports'
*/
reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

reports.form = reportsForm

const FinancialAnalyticsController = { dashboard, cashFlowLedger, dailyReport, dailyReportPrint, dailyReportDownloadPDF, dailyReportPrintPDF, balanceSheet, balanceSheetPdf, reports }

export default FinancialAnalyticsController