import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PaymentRequestController::index
* @see app/Http/Controllers/PaymentRequestController.php:15
* @route '/payment-requests'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/payment-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentRequestController::index
* @see app/Http/Controllers/PaymentRequestController.php:15
* @route '/payment-requests'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentRequestController::index
* @see app/Http/Controllers/PaymentRequestController.php:15
* @route '/payment-requests'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::index
* @see app/Http/Controllers/PaymentRequestController.php:15
* @route '/payment-requests'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::index
* @see app/Http/Controllers/PaymentRequestController.php:15
* @route '/payment-requests'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::index
* @see app/Http/Controllers/PaymentRequestController.php:15
* @route '/payment-requests'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::index
* @see app/Http/Controllers/PaymentRequestController.php:15
* @route '/payment-requests'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\PaymentRequestController::store
* @see app/Http/Controllers/PaymentRequestController.php:72
* @route '/payment-requests'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/payment-requests',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PaymentRequestController::store
* @see app/Http/Controllers/PaymentRequestController.php:72
* @route '/payment-requests'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentRequestController::store
* @see app/Http/Controllers/PaymentRequestController.php:72
* @route '/payment-requests'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::store
* @see app/Http/Controllers/PaymentRequestController.php:72
* @route '/payment-requests'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::store
* @see app/Http/Controllers/PaymentRequestController.php:72
* @route '/payment-requests'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\PaymentRequestController::markSent
* @see app/Http/Controllers/PaymentRequestController.php:97
* @route '/payment-requests/{paymentRequest}/sent'
*/
export const markSent = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markSent.url(args, options),
    method: 'patch',
})

markSent.definition = {
    methods: ["patch"],
    url: '/payment-requests/{paymentRequest}/sent',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\PaymentRequestController::markSent
* @see app/Http/Controllers/PaymentRequestController.php:97
* @route '/payment-requests/{paymentRequest}/sent'
*/
markSent.url = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { paymentRequest: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { paymentRequest: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            paymentRequest: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        paymentRequest: typeof args.paymentRequest === 'object'
        ? args.paymentRequest.id
        : args.paymentRequest,
    }

    return markSent.definition.url
            .replace('{paymentRequest}', parsedArgs.paymentRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentRequestController::markSent
* @see app/Http/Controllers/PaymentRequestController.php:97
* @route '/payment-requests/{paymentRequest}/sent'
*/
markSent.patch = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markSent.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::markSent
* @see app/Http/Controllers/PaymentRequestController.php:97
* @route '/payment-requests/{paymentRequest}/sent'
*/
const markSentForm = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markSent.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::markSent
* @see app/Http/Controllers/PaymentRequestController.php:97
* @route '/payment-requests/{paymentRequest}/sent'
*/
markSentForm.patch = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markSent.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

markSent.form = markSentForm

/**
* @see \App\Http\Controllers\PaymentRequestController::markPaid
* @see app/Http/Controllers/PaymentRequestController.php:103
* @route '/payment-requests/{paymentRequest}/paid'
*/
export const markPaid = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markPaid.url(args, options),
    method: 'patch',
})

markPaid.definition = {
    methods: ["patch"],
    url: '/payment-requests/{paymentRequest}/paid',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\PaymentRequestController::markPaid
* @see app/Http/Controllers/PaymentRequestController.php:103
* @route '/payment-requests/{paymentRequest}/paid'
*/
markPaid.url = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { paymentRequest: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { paymentRequest: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            paymentRequest: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        paymentRequest: typeof args.paymentRequest === 'object'
        ? args.paymentRequest.id
        : args.paymentRequest,
    }

    return markPaid.definition.url
            .replace('{paymentRequest}', parsedArgs.paymentRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentRequestController::markPaid
* @see app/Http/Controllers/PaymentRequestController.php:103
* @route '/payment-requests/{paymentRequest}/paid'
*/
markPaid.patch = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markPaid.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::markPaid
* @see app/Http/Controllers/PaymentRequestController.php:103
* @route '/payment-requests/{paymentRequest}/paid'
*/
const markPaidForm = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markPaid.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::markPaid
* @see app/Http/Controllers/PaymentRequestController.php:103
* @route '/payment-requests/{paymentRequest}/paid'
*/
markPaidForm.patch = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markPaid.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

markPaid.form = markPaidForm

/**
* @see \App\Http\Controllers\PaymentRequestController::cancel
* @see app/Http/Controllers/PaymentRequestController.php:109
* @route '/payment-requests/{paymentRequest}/cancel'
*/
export const cancel = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: cancel.url(args, options),
    method: 'patch',
})

cancel.definition = {
    methods: ["patch"],
    url: '/payment-requests/{paymentRequest}/cancel',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\PaymentRequestController::cancel
* @see app/Http/Controllers/PaymentRequestController.php:109
* @route '/payment-requests/{paymentRequest}/cancel'
*/
cancel.url = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { paymentRequest: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { paymentRequest: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            paymentRequest: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        paymentRequest: typeof args.paymentRequest === 'object'
        ? args.paymentRequest.id
        : args.paymentRequest,
    }

    return cancel.definition.url
            .replace('{paymentRequest}', parsedArgs.paymentRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentRequestController::cancel
* @see app/Http/Controllers/PaymentRequestController.php:109
* @route '/payment-requests/{paymentRequest}/cancel'
*/
cancel.patch = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: cancel.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::cancel
* @see app/Http/Controllers/PaymentRequestController.php:109
* @route '/payment-requests/{paymentRequest}/cancel'
*/
const cancelForm = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::cancel
* @see app/Http/Controllers/PaymentRequestController.php:109
* @route '/payment-requests/{paymentRequest}/cancel'
*/
cancelForm.patch = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

cancel.form = cancelForm

/**
* @see \App\Http\Controllers\PaymentRequestController::destroy
* @see app/Http/Controllers/PaymentRequestController.php:115
* @route '/payment-requests/{paymentRequest}'
*/
export const destroy = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/payment-requests/{paymentRequest}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PaymentRequestController::destroy
* @see app/Http/Controllers/PaymentRequestController.php:115
* @route '/payment-requests/{paymentRequest}'
*/
destroy.url = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { paymentRequest: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { paymentRequest: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            paymentRequest: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        paymentRequest: typeof args.paymentRequest === 'object'
        ? args.paymentRequest.id
        : args.paymentRequest,
    }

    return destroy.definition.url
            .replace('{paymentRequest}', parsedArgs.paymentRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentRequestController::destroy
* @see app/Http/Controllers/PaymentRequestController.php:115
* @route '/payment-requests/{paymentRequest}'
*/
destroy.delete = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::destroy
* @see app/Http/Controllers/PaymentRequestController.php:115
* @route '/payment-requests/{paymentRequest}'
*/
const destroyForm = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentRequestController::destroy
* @see app/Http/Controllers/PaymentRequestController.php:115
* @route '/payment-requests/{paymentRequest}'
*/
destroyForm.delete = (args: { paymentRequest: number | { id: number } } | [paymentRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const PaymentRequestController = { index, store, markSent, markPaid, cancel, destroy }

export default PaymentRequestController