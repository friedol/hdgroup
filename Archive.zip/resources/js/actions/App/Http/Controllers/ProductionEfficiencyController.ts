import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/production-efficiency',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::dashboard
* @see app/Http/Controllers/ProductionEfficiencyController.php:15
* @route '/production-efficiency'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:20
* @route '/production-efficiency/metrics'
*/
export const getEfficiencyMetrics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEfficiencyMetrics.url(options),
    method: 'get',
})

getEfficiencyMetrics.definition = {
    methods: ["get","head"],
    url: '/production-efficiency/metrics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:20
* @route '/production-efficiency/metrics'
*/
getEfficiencyMetrics.url = (options?: RouteQueryOptions) => {
    return getEfficiencyMetrics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:20
* @route '/production-efficiency/metrics'
*/
getEfficiencyMetrics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEfficiencyMetrics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:20
* @route '/production-efficiency/metrics'
*/
getEfficiencyMetrics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEfficiencyMetrics.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:20
* @route '/production-efficiency/metrics'
*/
const getEfficiencyMetricsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getEfficiencyMetrics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:20
* @route '/production-efficiency/metrics'
*/
getEfficiencyMetricsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getEfficiencyMetrics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:20
* @route '/production-efficiency/metrics'
*/
getEfficiencyMetricsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getEfficiencyMetrics.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getEfficiencyMetrics.form = getEfficiencyMetricsForm

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getBranchEfficiencyComparison
* @see app/Http/Controllers/ProductionEfficiencyController.php:63
* @route '/production-efficiency/branch-comparison'
*/
export const getBranchEfficiencyComparison = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getBranchEfficiencyComparison.url(options),
    method: 'get',
})

getBranchEfficiencyComparison.definition = {
    methods: ["get","head"],
    url: '/production-efficiency/branch-comparison',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getBranchEfficiencyComparison
* @see app/Http/Controllers/ProductionEfficiencyController.php:63
* @route '/production-efficiency/branch-comparison'
*/
getBranchEfficiencyComparison.url = (options?: RouteQueryOptions) => {
    return getBranchEfficiencyComparison.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getBranchEfficiencyComparison
* @see app/Http/Controllers/ProductionEfficiencyController.php:63
* @route '/production-efficiency/branch-comparison'
*/
getBranchEfficiencyComparison.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getBranchEfficiencyComparison.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getBranchEfficiencyComparison
* @see app/Http/Controllers/ProductionEfficiencyController.php:63
* @route '/production-efficiency/branch-comparison'
*/
getBranchEfficiencyComparison.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getBranchEfficiencyComparison.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getBranchEfficiencyComparison
* @see app/Http/Controllers/ProductionEfficiencyController.php:63
* @route '/production-efficiency/branch-comparison'
*/
const getBranchEfficiencyComparisonForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getBranchEfficiencyComparison.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getBranchEfficiencyComparison
* @see app/Http/Controllers/ProductionEfficiencyController.php:63
* @route '/production-efficiency/branch-comparison'
*/
getBranchEfficiencyComparisonForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getBranchEfficiencyComparison.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getBranchEfficiencyComparison
* @see app/Http/Controllers/ProductionEfficiencyController.php:63
* @route '/production-efficiency/branch-comparison'
*/
getBranchEfficiencyComparisonForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getBranchEfficiencyComparison.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getBranchEfficiencyComparison.form = getBranchEfficiencyComparisonForm

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyTrends
* @see app/Http/Controllers/ProductionEfficiencyController.php:115
* @route '/production-efficiency/trends'
*/
export const getEfficiencyTrends = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEfficiencyTrends.url(options),
    method: 'get',
})

getEfficiencyTrends.definition = {
    methods: ["get","head"],
    url: '/production-efficiency/trends',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyTrends
* @see app/Http/Controllers/ProductionEfficiencyController.php:115
* @route '/production-efficiency/trends'
*/
getEfficiencyTrends.url = (options?: RouteQueryOptions) => {
    return getEfficiencyTrends.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyTrends
* @see app/Http/Controllers/ProductionEfficiencyController.php:115
* @route '/production-efficiency/trends'
*/
getEfficiencyTrends.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEfficiencyTrends.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyTrends
* @see app/Http/Controllers/ProductionEfficiencyController.php:115
* @route '/production-efficiency/trends'
*/
getEfficiencyTrends.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEfficiencyTrends.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyTrends
* @see app/Http/Controllers/ProductionEfficiencyController.php:115
* @route '/production-efficiency/trends'
*/
const getEfficiencyTrendsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getEfficiencyTrends.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyTrends
* @see app/Http/Controllers/ProductionEfficiencyController.php:115
* @route '/production-efficiency/trends'
*/
getEfficiencyTrendsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getEfficiencyTrends.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencyTrends
* @see app/Http/Controllers/ProductionEfficiencyController.php:115
* @route '/production-efficiency/trends'
*/
getEfficiencyTrendsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getEfficiencyTrends.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getEfficiencyTrends.form = getEfficiencyTrendsForm

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getMaterialWasteAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:134
* @route '/production-efficiency/waste-analysis'
*/
export const getMaterialWasteAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMaterialWasteAnalysis.url(options),
    method: 'get',
})

getMaterialWasteAnalysis.definition = {
    methods: ["get","head"],
    url: '/production-efficiency/waste-analysis',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getMaterialWasteAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:134
* @route '/production-efficiency/waste-analysis'
*/
getMaterialWasteAnalysis.url = (options?: RouteQueryOptions) => {
    return getMaterialWasteAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getMaterialWasteAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:134
* @route '/production-efficiency/waste-analysis'
*/
getMaterialWasteAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMaterialWasteAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getMaterialWasteAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:134
* @route '/production-efficiency/waste-analysis'
*/
getMaterialWasteAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getMaterialWasteAnalysis.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getMaterialWasteAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:134
* @route '/production-efficiency/waste-analysis'
*/
const getMaterialWasteAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMaterialWasteAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getMaterialWasteAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:134
* @route '/production-efficiency/waste-analysis'
*/
getMaterialWasteAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMaterialWasteAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getMaterialWasteAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:134
* @route '/production-efficiency/waste-analysis'
*/
getMaterialWasteAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMaterialWasteAnalysis.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getMaterialWasteAnalysis.form = getMaterialWasteAnalysisForm

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getLaborCostAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:156
* @route '/production-efficiency/labor-costs'
*/
export const getLaborCostAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getLaborCostAnalysis.url(options),
    method: 'get',
})

getLaborCostAnalysis.definition = {
    methods: ["get","head"],
    url: '/production-efficiency/labor-costs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getLaborCostAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:156
* @route '/production-efficiency/labor-costs'
*/
getLaborCostAnalysis.url = (options?: RouteQueryOptions) => {
    return getLaborCostAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getLaborCostAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:156
* @route '/production-efficiency/labor-costs'
*/
getLaborCostAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getLaborCostAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getLaborCostAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:156
* @route '/production-efficiency/labor-costs'
*/
getLaborCostAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getLaborCostAnalysis.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getLaborCostAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:156
* @route '/production-efficiency/labor-costs'
*/
const getLaborCostAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getLaborCostAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getLaborCostAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:156
* @route '/production-efficiency/labor-costs'
*/
getLaborCostAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getLaborCostAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getLaborCostAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:156
* @route '/production-efficiency/labor-costs'
*/
getLaborCostAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getLaborCostAnalysis.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getLaborCostAnalysis.form = getLaborCostAnalysisForm

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getDowntimeAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:178
* @route '/production-efficiency/downtime'
*/
export const getDowntimeAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDowntimeAnalysis.url(options),
    method: 'get',
})

getDowntimeAnalysis.definition = {
    methods: ["get","head"],
    url: '/production-efficiency/downtime',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getDowntimeAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:178
* @route '/production-efficiency/downtime'
*/
getDowntimeAnalysis.url = (options?: RouteQueryOptions) => {
    return getDowntimeAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getDowntimeAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:178
* @route '/production-efficiency/downtime'
*/
getDowntimeAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDowntimeAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getDowntimeAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:178
* @route '/production-efficiency/downtime'
*/
getDowntimeAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getDowntimeAnalysis.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getDowntimeAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:178
* @route '/production-efficiency/downtime'
*/
const getDowntimeAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDowntimeAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getDowntimeAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:178
* @route '/production-efficiency/downtime'
*/
getDowntimeAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDowntimeAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getDowntimeAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:178
* @route '/production-efficiency/downtime'
*/
getDowntimeAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDowntimeAnalysis.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getDowntimeAnalysis.form = getDowntimeAnalysisForm

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getCostVarianceAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:200
* @route '/production-efficiency/cost-variance'
*/
export const getCostVarianceAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCostVarianceAnalysis.url(options),
    method: 'get',
})

getCostVarianceAnalysis.definition = {
    methods: ["get","head"],
    url: '/production-efficiency/cost-variance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getCostVarianceAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:200
* @route '/production-efficiency/cost-variance'
*/
getCostVarianceAnalysis.url = (options?: RouteQueryOptions) => {
    return getCostVarianceAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getCostVarianceAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:200
* @route '/production-efficiency/cost-variance'
*/
getCostVarianceAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCostVarianceAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getCostVarianceAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:200
* @route '/production-efficiency/cost-variance'
*/
getCostVarianceAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getCostVarianceAnalysis.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getCostVarianceAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:200
* @route '/production-efficiency/cost-variance'
*/
const getCostVarianceAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCostVarianceAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getCostVarianceAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:200
* @route '/production-efficiency/cost-variance'
*/
getCostVarianceAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCostVarianceAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getCostVarianceAnalysis
* @see app/Http/Controllers/ProductionEfficiencyController.php:200
* @route '/production-efficiency/cost-variance'
*/
getCostVarianceAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCostVarianceAnalysis.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getCostVarianceAnalysis.form = getCostVarianceAnalysisForm

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::storeProductionMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:223
* @route '/production-efficiency/metrics'
*/
export const storeProductionMetrics = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeProductionMetrics.url(options),
    method: 'post',
})

storeProductionMetrics.definition = {
    methods: ["post"],
    url: '/production-efficiency/metrics',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::storeProductionMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:223
* @route '/production-efficiency/metrics'
*/
storeProductionMetrics.url = (options?: RouteQueryOptions) => {
    return storeProductionMetrics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::storeProductionMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:223
* @route '/production-efficiency/metrics'
*/
storeProductionMetrics.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeProductionMetrics.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::storeProductionMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:223
* @route '/production-efficiency/metrics'
*/
const storeProductionMetricsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeProductionMetrics.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::storeProductionMetrics
* @see app/Http/Controllers/ProductionEfficiencyController.php:223
* @route '/production-efficiency/metrics'
*/
storeProductionMetricsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeProductionMetrics.url(options),
    method: 'post',
})

storeProductionMetrics.form = storeProductionMetricsForm

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencySummary
* @see app/Http/Controllers/ProductionEfficiencyController.php:259
* @route '/production-efficiency/summary'
*/
export const getEfficiencySummary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEfficiencySummary.url(options),
    method: 'get',
})

getEfficiencySummary.definition = {
    methods: ["get","head"],
    url: '/production-efficiency/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencySummary
* @see app/Http/Controllers/ProductionEfficiencyController.php:259
* @route '/production-efficiency/summary'
*/
getEfficiencySummary.url = (options?: RouteQueryOptions) => {
    return getEfficiencySummary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencySummary
* @see app/Http/Controllers/ProductionEfficiencyController.php:259
* @route '/production-efficiency/summary'
*/
getEfficiencySummary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEfficiencySummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencySummary
* @see app/Http/Controllers/ProductionEfficiencyController.php:259
* @route '/production-efficiency/summary'
*/
getEfficiencySummary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEfficiencySummary.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencySummary
* @see app/Http/Controllers/ProductionEfficiencyController.php:259
* @route '/production-efficiency/summary'
*/
const getEfficiencySummaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getEfficiencySummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencySummary
* @see app/Http/Controllers/ProductionEfficiencyController.php:259
* @route '/production-efficiency/summary'
*/
getEfficiencySummaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getEfficiencySummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionEfficiencyController::getEfficiencySummary
* @see app/Http/Controllers/ProductionEfficiencyController.php:259
* @route '/production-efficiency/summary'
*/
getEfficiencySummaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getEfficiencySummary.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getEfficiencySummary.form = getEfficiencySummaryForm

const ProductionEfficiencyController = { dashboard, getEfficiencyMetrics, getBranchEfficiencyComparison, getEfficiencyTrends, getMaterialWasteAnalysis, getLaborCostAnalysis, getDowntimeAnalysis, getCostVarianceAnalysis, storeProductionMetrics, getEfficiencySummary }

export default ProductionEfficiencyController