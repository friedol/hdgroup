import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PopupAdController::index
* @see app/Http/Controllers/PopupAdController.php:11
* @route '/settings/popup-ads'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/popup-ads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PopupAdController::index
* @see app/Http/Controllers/PopupAdController.php:11
* @route '/settings/popup-ads'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PopupAdController::index
* @see app/Http/Controllers/PopupAdController.php:11
* @route '/settings/popup-ads'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::index
* @see app/Http/Controllers/PopupAdController.php:11
* @route '/settings/popup-ads'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PopupAdController::index
* @see app/Http/Controllers/PopupAdController.php:11
* @route '/settings/popup-ads'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::index
* @see app/Http/Controllers/PopupAdController.php:11
* @route '/settings/popup-ads'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::index
* @see app/Http/Controllers/PopupAdController.php:11
* @route '/settings/popup-ads'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\PopupAdController::create
* @see app/Http/Controllers/PopupAdController.php:20
* @route '/settings/popup-ads/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/settings/popup-ads/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PopupAdController::create
* @see app/Http/Controllers/PopupAdController.php:20
* @route '/settings/popup-ads/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PopupAdController::create
* @see app/Http/Controllers/PopupAdController.php:20
* @route '/settings/popup-ads/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::create
* @see app/Http/Controllers/PopupAdController.php:20
* @route '/settings/popup-ads/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PopupAdController::create
* @see app/Http/Controllers/PopupAdController.php:20
* @route '/settings/popup-ads/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::create
* @see app/Http/Controllers/PopupAdController.php:20
* @route '/settings/popup-ads/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::create
* @see app/Http/Controllers/PopupAdController.php:20
* @route '/settings/popup-ads/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\PopupAdController::store
* @see app/Http/Controllers/PopupAdController.php:27
* @route '/settings/popup-ads'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/popup-ads',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PopupAdController::store
* @see app/Http/Controllers/PopupAdController.php:27
* @route '/settings/popup-ads'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PopupAdController::store
* @see app/Http/Controllers/PopupAdController.php:27
* @route '/settings/popup-ads'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PopupAdController::store
* @see app/Http/Controllers/PopupAdController.php:27
* @route '/settings/popup-ads'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PopupAdController::store
* @see app/Http/Controllers/PopupAdController.php:27
* @route '/settings/popup-ads'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\PopupAdController::updateSortOrder
* @see app/Http/Controllers/PopupAdController.php:130
* @route '/settings/popup-ads/sort-order'
*/
export const updateSortOrder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSortOrder.url(options),
    method: 'post',
})

updateSortOrder.definition = {
    methods: ["post"],
    url: '/settings/popup-ads/sort-order',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PopupAdController::updateSortOrder
* @see app/Http/Controllers/PopupAdController.php:130
* @route '/settings/popup-ads/sort-order'
*/
updateSortOrder.url = (options?: RouteQueryOptions) => {
    return updateSortOrder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PopupAdController::updateSortOrder
* @see app/Http/Controllers/PopupAdController.php:130
* @route '/settings/popup-ads/sort-order'
*/
updateSortOrder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSortOrder.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PopupAdController::updateSortOrder
* @see app/Http/Controllers/PopupAdController.php:130
* @route '/settings/popup-ads/sort-order'
*/
const updateSortOrderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateSortOrder.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PopupAdController::updateSortOrder
* @see app/Http/Controllers/PopupAdController.php:130
* @route '/settings/popup-ads/sort-order'
*/
updateSortOrderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateSortOrder.url(options),
    method: 'post',
})

updateSortOrder.form = updateSortOrderForm

/**
* @see \App\Http\Controllers\PopupAdController::show
* @see app/Http/Controllers/PopupAdController.php:63
* @route '/settings/popup-ads/{ad}'
*/
export const show = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/settings/popup-ads/{ad}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PopupAdController::show
* @see app/Http/Controllers/PopupAdController.php:63
* @route '/settings/popup-ads/{ad}'
*/
show.url = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ad: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { ad: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            ad: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        ad: typeof args.ad === 'object'
        ? args.ad.id
        : args.ad,
    }

    return show.definition.url
            .replace('{ad}', parsedArgs.ad.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PopupAdController::show
* @see app/Http/Controllers/PopupAdController.php:63
* @route '/settings/popup-ads/{ad}'
*/
show.get = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::show
* @see app/Http/Controllers/PopupAdController.php:63
* @route '/settings/popup-ads/{ad}'
*/
show.head = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PopupAdController::show
* @see app/Http/Controllers/PopupAdController.php:63
* @route '/settings/popup-ads/{ad}'
*/
const showForm = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::show
* @see app/Http/Controllers/PopupAdController.php:63
* @route '/settings/popup-ads/{ad}'
*/
showForm.get = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::show
* @see app/Http/Controllers/PopupAdController.php:63
* @route '/settings/popup-ads/{ad}'
*/
showForm.head = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\PopupAdController::edit
* @see app/Http/Controllers/PopupAdController.php:71
* @route '/settings/popup-ads/{ad}/edit'
*/
export const edit = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/popup-ads/{ad}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PopupAdController::edit
* @see app/Http/Controllers/PopupAdController.php:71
* @route '/settings/popup-ads/{ad}/edit'
*/
edit.url = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ad: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { ad: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            ad: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        ad: typeof args.ad === 'object'
        ? args.ad.id
        : args.ad,
    }

    return edit.definition.url
            .replace('{ad}', parsedArgs.ad.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PopupAdController::edit
* @see app/Http/Controllers/PopupAdController.php:71
* @route '/settings/popup-ads/{ad}/edit'
*/
edit.get = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::edit
* @see app/Http/Controllers/PopupAdController.php:71
* @route '/settings/popup-ads/{ad}/edit'
*/
edit.head = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PopupAdController::edit
* @see app/Http/Controllers/PopupAdController.php:71
* @route '/settings/popup-ads/{ad}/edit'
*/
const editForm = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::edit
* @see app/Http/Controllers/PopupAdController.php:71
* @route '/settings/popup-ads/{ad}/edit'
*/
editForm.get = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PopupAdController::edit
* @see app/Http/Controllers/PopupAdController.php:71
* @route '/settings/popup-ads/{ad}/edit'
*/
editForm.head = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\PopupAdController::update
* @see app/Http/Controllers/PopupAdController.php:79
* @route '/settings/popup-ads/{ad}'
*/
export const update = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/popup-ads/{ad}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PopupAdController::update
* @see app/Http/Controllers/PopupAdController.php:79
* @route '/settings/popup-ads/{ad}'
*/
update.url = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ad: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { ad: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            ad: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        ad: typeof args.ad === 'object'
        ? args.ad.id
        : args.ad,
    }

    return update.definition.url
            .replace('{ad}', parsedArgs.ad.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PopupAdController::update
* @see app/Http/Controllers/PopupAdController.php:79
* @route '/settings/popup-ads/{ad}'
*/
update.put = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\PopupAdController::update
* @see app/Http/Controllers/PopupAdController.php:79
* @route '/settings/popup-ads/{ad}'
*/
const updateForm = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PopupAdController::update
* @see app/Http/Controllers/PopupAdController.php:79
* @route '/settings/popup-ads/{ad}'
*/
updateForm.put = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\PopupAdController::destroy
* @see app/Http/Controllers/PopupAdController.php:116
* @route '/settings/popup-ads/{ad}'
*/
export const destroy = (args: { ad: string | number } | [ad: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/settings/popup-ads/{ad}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PopupAdController::destroy
* @see app/Http/Controllers/PopupAdController.php:116
* @route '/settings/popup-ads/{ad}'
*/
destroy.url = (args: { ad: string | number } | [ad: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ad: args }
    }

    if (Array.isArray(args)) {
        args = {
            ad: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        ad: args.ad,
    }

    return destroy.definition.url
            .replace('{ad}', parsedArgs.ad.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PopupAdController::destroy
* @see app/Http/Controllers/PopupAdController.php:116
* @route '/settings/popup-ads/{ad}'
*/
destroy.delete = (args: { ad: string | number } | [ad: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\PopupAdController::destroy
* @see app/Http/Controllers/PopupAdController.php:116
* @route '/settings/popup-ads/{ad}'
*/
const destroyForm = (args: { ad: string | number } | [ad: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PopupAdController::destroy
* @see app/Http/Controllers/PopupAdController.php:116
* @route '/settings/popup-ads/{ad}'
*/
destroyForm.delete = (args: { ad: string | number } | [ad: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const PopupAdController = { index, create, store, updateSortOrder, show, edit, update, destroy }

export default PopupAdController