import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:18
* @route '/staff-performance'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/staff-performance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:18
* @route '/staff-performance'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:18
* @route '/staff-performance'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:18
* @route '/staff-performance'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:18
* @route '/staff-performance'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:18
* @route '/staff-performance'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::dashboard
* @see app/Http/Controllers/StaffPerformanceController.php:18
* @route '/staff-performance'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\StaffPerformanceController::getSellerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:26
* @route '/staff-performance/sellers'
*/
export const getSellerPerformance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getSellerPerformance.url(options),
    method: 'get',
})

getSellerPerformance.definition = {
    methods: ["get","head"],
    url: '/staff-performance/sellers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StaffPerformanceController::getSellerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:26
* @route '/staff-performance/sellers'
*/
getSellerPerformance.url = (options?: RouteQueryOptions) => {
    return getSellerPerformance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffPerformanceController::getSellerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:26
* @route '/staff-performance/sellers'
*/
getSellerPerformance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getSellerPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getSellerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:26
* @route '/staff-performance/sellers'
*/
getSellerPerformance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getSellerPerformance.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getSellerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:26
* @route '/staff-performance/sellers'
*/
const getSellerPerformanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getSellerPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getSellerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:26
* @route '/staff-performance/sellers'
*/
getSellerPerformanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getSellerPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getSellerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:26
* @route '/staff-performance/sellers'
*/
getSellerPerformanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getSellerPerformance.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getSellerPerformance.form = getSellerPerformanceForm

/**
* @see \App\Http\Controllers\StaffPerformanceController::getBranchManagerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:90
* @route '/staff-performance/managers'
*/
export const getBranchManagerPerformance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getBranchManagerPerformance.url(options),
    method: 'get',
})

getBranchManagerPerformance.definition = {
    methods: ["get","head"],
    url: '/staff-performance/managers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StaffPerformanceController::getBranchManagerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:90
* @route '/staff-performance/managers'
*/
getBranchManagerPerformance.url = (options?: RouteQueryOptions) => {
    return getBranchManagerPerformance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffPerformanceController::getBranchManagerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:90
* @route '/staff-performance/managers'
*/
getBranchManagerPerformance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getBranchManagerPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getBranchManagerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:90
* @route '/staff-performance/managers'
*/
getBranchManagerPerformance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getBranchManagerPerformance.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getBranchManagerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:90
* @route '/staff-performance/managers'
*/
const getBranchManagerPerformanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getBranchManagerPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getBranchManagerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:90
* @route '/staff-performance/managers'
*/
getBranchManagerPerformanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getBranchManagerPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getBranchManagerPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:90
* @route '/staff-performance/managers'
*/
getBranchManagerPerformanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getBranchManagerPerformance.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getBranchManagerPerformance.form = getBranchManagerPerformanceForm

/**
* @see \App\Http\Controllers\StaffPerformanceController::getDeliveryPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:154
* @route '/staff-performance/delivery'
*/
export const getDeliveryPerformance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDeliveryPerformance.url(options),
    method: 'get',
})

getDeliveryPerformance.definition = {
    methods: ["get","head"],
    url: '/staff-performance/delivery',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StaffPerformanceController::getDeliveryPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:154
* @route '/staff-performance/delivery'
*/
getDeliveryPerformance.url = (options?: RouteQueryOptions) => {
    return getDeliveryPerformance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffPerformanceController::getDeliveryPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:154
* @route '/staff-performance/delivery'
*/
getDeliveryPerformance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDeliveryPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getDeliveryPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:154
* @route '/staff-performance/delivery'
*/
getDeliveryPerformance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getDeliveryPerformance.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getDeliveryPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:154
* @route '/staff-performance/delivery'
*/
const getDeliveryPerformanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDeliveryPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getDeliveryPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:154
* @route '/staff-performance/delivery'
*/
getDeliveryPerformanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDeliveryPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getDeliveryPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:154
* @route '/staff-performance/delivery'
*/
getDeliveryPerformanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDeliveryPerformance.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getDeliveryPerformance.form = getDeliveryPerformanceForm

/**
* @see \App\Http\Controllers\StaffPerformanceController::getStorekeeperPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:209
* @route '/staff-performance/storekeepers'
*/
export const getStorekeeperPerformance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStorekeeperPerformance.url(options),
    method: 'get',
})

getStorekeeperPerformance.definition = {
    methods: ["get","head"],
    url: '/staff-performance/storekeepers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StaffPerformanceController::getStorekeeperPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:209
* @route '/staff-performance/storekeepers'
*/
getStorekeeperPerformance.url = (options?: RouteQueryOptions) => {
    return getStorekeeperPerformance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffPerformanceController::getStorekeeperPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:209
* @route '/staff-performance/storekeepers'
*/
getStorekeeperPerformance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStorekeeperPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getStorekeeperPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:209
* @route '/staff-performance/storekeepers'
*/
getStorekeeperPerformance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getStorekeeperPerformance.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getStorekeeperPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:209
* @route '/staff-performance/storekeepers'
*/
const getStorekeeperPerformanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getStorekeeperPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getStorekeeperPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:209
* @route '/staff-performance/storekeepers'
*/
getStorekeeperPerformanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getStorekeeperPerformance.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getStorekeeperPerformance
* @see app/Http/Controllers/StaffPerformanceController.php:209
* @route '/staff-performance/storekeepers'
*/
getStorekeeperPerformanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getStorekeeperPerformance.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getStorekeeperPerformance.form = getStorekeeperPerformanceForm

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceTrends
* @see app/Http/Controllers/StaffPerformanceController.php:270
* @route '/staff-performance/trends'
*/
export const getPerformanceTrends = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPerformanceTrends.url(options),
    method: 'get',
})

getPerformanceTrends.definition = {
    methods: ["get","head"],
    url: '/staff-performance/trends',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceTrends
* @see app/Http/Controllers/StaffPerformanceController.php:270
* @route '/staff-performance/trends'
*/
getPerformanceTrends.url = (options?: RouteQueryOptions) => {
    return getPerformanceTrends.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceTrends
* @see app/Http/Controllers/StaffPerformanceController.php:270
* @route '/staff-performance/trends'
*/
getPerformanceTrends.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPerformanceTrends.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceTrends
* @see app/Http/Controllers/StaffPerformanceController.php:270
* @route '/staff-performance/trends'
*/
getPerformanceTrends.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getPerformanceTrends.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceTrends
* @see app/Http/Controllers/StaffPerformanceController.php:270
* @route '/staff-performance/trends'
*/
const getPerformanceTrendsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPerformanceTrends.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceTrends
* @see app/Http/Controllers/StaffPerformanceController.php:270
* @route '/staff-performance/trends'
*/
getPerformanceTrendsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPerformanceTrends.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceTrends
* @see app/Http/Controllers/StaffPerformanceController.php:270
* @route '/staff-performance/trends'
*/
getPerformanceTrendsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPerformanceTrends.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getPerformanceTrends.form = getPerformanceTrendsForm

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceSummary
* @see app/Http/Controllers/StaffPerformanceController.php:295
* @route '/staff-performance/summary'
*/
export const getPerformanceSummary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPerformanceSummary.url(options),
    method: 'get',
})

getPerformanceSummary.definition = {
    methods: ["get","head"],
    url: '/staff-performance/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceSummary
* @see app/Http/Controllers/StaffPerformanceController.php:295
* @route '/staff-performance/summary'
*/
getPerformanceSummary.url = (options?: RouteQueryOptions) => {
    return getPerformanceSummary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceSummary
* @see app/Http/Controllers/StaffPerformanceController.php:295
* @route '/staff-performance/summary'
*/
getPerformanceSummary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPerformanceSummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceSummary
* @see app/Http/Controllers/StaffPerformanceController.php:295
* @route '/staff-performance/summary'
*/
getPerformanceSummary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getPerformanceSummary.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceSummary
* @see app/Http/Controllers/StaffPerformanceController.php:295
* @route '/staff-performance/summary'
*/
const getPerformanceSummaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPerformanceSummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceSummary
* @see app/Http/Controllers/StaffPerformanceController.php:295
* @route '/staff-performance/summary'
*/
getPerformanceSummaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPerformanceSummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StaffPerformanceController::getPerformanceSummary
* @see app/Http/Controllers/StaffPerformanceController.php:295
* @route '/staff-performance/summary'
*/
getPerformanceSummaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPerformanceSummary.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getPerformanceSummary.form = getPerformanceSummaryForm

const StaffPerformanceController = { dashboard, getSellerPerformance, getBranchManagerPerformance, getDeliveryPerformance, getStorekeeperPerformance, getPerformanceTrends, getPerformanceSummary }

export default StaffPerformanceController