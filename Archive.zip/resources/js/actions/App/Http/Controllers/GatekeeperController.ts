import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:17
* @route '/gatekeeper'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/gatekeeper',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:17
* @route '/gatekeeper'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:17
* @route '/gatekeeper'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:17
* @route '/gatekeeper'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:17
* @route '/gatekeeper'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:17
* @route '/gatekeeper'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::index
* @see app/Http/Controllers/GatekeeperController.php:17
* @route '/gatekeeper'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:43
* @route '/gatekeeper/record-in'
*/
export const recordInForm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recordInForm.url(options),
    method: 'get',
})

recordInForm.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/record-in',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:43
* @route '/gatekeeper/record-in'
*/
recordInForm.url = (options?: RouteQueryOptions) => {
    return recordInForm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:43
* @route '/gatekeeper/record-in'
*/
recordInForm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recordInForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:43
* @route '/gatekeeper/record-in'
*/
recordInForm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: recordInForm.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:43
* @route '/gatekeeper/record-in'
*/
const recordInFormForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordInForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:43
* @route '/gatekeeper/record-in'
*/
recordInFormForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordInForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordInForm
* @see app/Http/Controllers/GatekeeperController.php:43
* @route '/gatekeeper/record-in'
*/
recordInFormForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordInForm.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

recordInForm.form = recordInFormForm

/**
* @see \App\Http\Controllers\GatekeeperController::storeRecordIn
* @see app/Http/Controllers/GatekeeperController.php:57
* @route '/gatekeeper/record-in'
*/
export const storeRecordIn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRecordIn.url(options),
    method: 'post',
})

storeRecordIn.definition = {
    methods: ["post"],
    url: '/gatekeeper/record-in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GatekeeperController::storeRecordIn
* @see app/Http/Controllers/GatekeeperController.php:57
* @route '/gatekeeper/record-in'
*/
storeRecordIn.url = (options?: RouteQueryOptions) => {
    return storeRecordIn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::storeRecordIn
* @see app/Http/Controllers/GatekeeperController.php:57
* @route '/gatekeeper/record-in'
*/
storeRecordIn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRecordIn.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::storeRecordIn
* @see app/Http/Controllers/GatekeeperController.php:57
* @route '/gatekeeper/record-in'
*/
const storeRecordInForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeRecordIn.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::storeRecordIn
* @see app/Http/Controllers/GatekeeperController.php:57
* @route '/gatekeeper/record-in'
*/
storeRecordInForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeRecordIn.url(options),
    method: 'post',
})

storeRecordIn.form = storeRecordInForm

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:95
* @route '/gatekeeper/record-out'
*/
export const recordOutForm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recordOutForm.url(options),
    method: 'get',
})

recordOutForm.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/record-out',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:95
* @route '/gatekeeper/record-out'
*/
recordOutForm.url = (options?: RouteQueryOptions) => {
    return recordOutForm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:95
* @route '/gatekeeper/record-out'
*/
recordOutForm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recordOutForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:95
* @route '/gatekeeper/record-out'
*/
recordOutForm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: recordOutForm.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:95
* @route '/gatekeeper/record-out'
*/
const recordOutFormForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordOutForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:95
* @route '/gatekeeper/record-out'
*/
recordOutFormForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordOutForm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::recordOutForm
* @see app/Http/Controllers/GatekeeperController.php:95
* @route '/gatekeeper/record-out'
*/
recordOutFormForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recordOutForm.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

recordOutForm.form = recordOutFormForm

/**
* @see \App\Http\Controllers\GatekeeperController::storeRecordOut
* @see app/Http/Controllers/GatekeeperController.php:109
* @route '/gatekeeper/record-out'
*/
export const storeRecordOut = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRecordOut.url(options),
    method: 'post',
})

storeRecordOut.definition = {
    methods: ["post"],
    url: '/gatekeeper/record-out',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GatekeeperController::storeRecordOut
* @see app/Http/Controllers/GatekeeperController.php:109
* @route '/gatekeeper/record-out'
*/
storeRecordOut.url = (options?: RouteQueryOptions) => {
    return storeRecordOut.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::storeRecordOut
* @see app/Http/Controllers/GatekeeperController.php:109
* @route '/gatekeeper/record-out'
*/
storeRecordOut.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRecordOut.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::storeRecordOut
* @see app/Http/Controllers/GatekeeperController.php:109
* @route '/gatekeeper/record-out'
*/
const storeRecordOutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeRecordOut.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::storeRecordOut
* @see app/Http/Controllers/GatekeeperController.php:109
* @route '/gatekeeper/record-out'
*/
storeRecordOutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeRecordOut.url(options),
    method: 'post',
})

storeRecordOut.form = storeRecordOutForm

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:147
* @route '/gatekeeper/{gatekeeperLog}'
*/
export const show = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/{gatekeeperLog}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:147
* @route '/gatekeeper/{gatekeeperLog}'
*/
show.url = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gatekeeperLog: args }
    }

    if (Array.isArray(args)) {
        args = {
            gatekeeperLog: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        gatekeeperLog: args.gatekeeperLog,
    }

    return show.definition.url
            .replace('{gatekeeperLog}', parsedArgs.gatekeeperLog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:147
* @route '/gatekeeper/{gatekeeperLog}'
*/
show.get = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:147
* @route '/gatekeeper/{gatekeeperLog}'
*/
show.head = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:147
* @route '/gatekeeper/{gatekeeperLog}'
*/
const showForm = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:147
* @route '/gatekeeper/{gatekeeperLog}'
*/
showForm.get = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::show
* @see app/Http/Controllers/GatekeeperController.php:147
* @route '/gatekeeper/{gatekeeperLog}'
*/
showForm.head = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
export const edit = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/{gatekeeperLog}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
edit.url = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gatekeeperLog: args }
    }

    if (Array.isArray(args)) {
        args = {
            gatekeeperLog: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        gatekeeperLog: args.gatekeeperLog,
    }

    return edit.definition.url
            .replace('{gatekeeperLog}', parsedArgs.gatekeeperLog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
edit.get = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
edit.head = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
const editForm = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
editForm.get = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::edit
* @see app/Http/Controllers/GatekeeperController.php:191
* @route '/gatekeeper/{gatekeeperLog}/edit'
*/
editForm.head = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\GatekeeperController::update
* @see app/Http/Controllers/GatekeeperController.php:201
* @route '/gatekeeper/{gatekeeperLog}'
*/
export const update = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/gatekeeper/{gatekeeperLog}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\GatekeeperController::update
* @see app/Http/Controllers/GatekeeperController.php:201
* @route '/gatekeeper/{gatekeeperLog}'
*/
update.url = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gatekeeperLog: args }
    }

    if (Array.isArray(args)) {
        args = {
            gatekeeperLog: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        gatekeeperLog: args.gatekeeperLog,
    }

    return update.definition.url
            .replace('{gatekeeperLog}', parsedArgs.gatekeeperLog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::update
* @see app/Http/Controllers/GatekeeperController.php:201
* @route '/gatekeeper/{gatekeeperLog}'
*/
update.put = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\GatekeeperController::update
* @see app/Http/Controllers/GatekeeperController.php:201
* @route '/gatekeeper/{gatekeeperLog}'
*/
const updateForm = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::update
* @see app/Http/Controllers/GatekeeperController.php:201
* @route '/gatekeeper/{gatekeeperLog}'
*/
updateForm.put = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\GatekeeperController::destroy
* @see app/Http/Controllers/GatekeeperController.php:217
* @route '/gatekeeper/{gatekeeperLog}'
*/
export const destroy = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/gatekeeper/{gatekeeperLog}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\GatekeeperController::destroy
* @see app/Http/Controllers/GatekeeperController.php:217
* @route '/gatekeeper/{gatekeeperLog}'
*/
destroy.url = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gatekeeperLog: args }
    }

    if (Array.isArray(args)) {
        args = {
            gatekeeperLog: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        gatekeeperLog: args.gatekeeperLog,
    }

    return destroy.definition.url
            .replace('{gatekeeperLog}', parsedArgs.gatekeeperLog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::destroy
* @see app/Http/Controllers/GatekeeperController.php:217
* @route '/gatekeeper/{gatekeeperLog}'
*/
destroy.delete = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\GatekeeperController::destroy
* @see app/Http/Controllers/GatekeeperController.php:217
* @route '/gatekeeper/{gatekeeperLog}'
*/
const destroyForm = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GatekeeperController::destroy
* @see app/Http/Controllers/GatekeeperController.php:217
* @route '/gatekeeper/{gatekeeperLog}'
*/
destroyForm.delete = (args: { gatekeeperLog: string | number } | [gatekeeperLog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\GatekeeperController::printLogs
* @see app/Http/Controllers/GatekeeperController.php:175
* @route '/gatekeeper/print'
*/
export const printLogs = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printLogs.url(options),
    method: 'get',
})

printLogs.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::printLogs
* @see app/Http/Controllers/GatekeeperController.php:175
* @route '/gatekeeper/print'
*/
printLogs.url = (options?: RouteQueryOptions) => {
    return printLogs.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::printLogs
* @see app/Http/Controllers/GatekeeperController.php:175
* @route '/gatekeeper/print'
*/
printLogs.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printLogs.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::printLogs
* @see app/Http/Controllers/GatekeeperController.php:175
* @route '/gatekeeper/print'
*/
printLogs.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printLogs.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::printLogs
* @see app/Http/Controllers/GatekeeperController.php:175
* @route '/gatekeeper/print'
*/
const printLogsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printLogs.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::printLogs
* @see app/Http/Controllers/GatekeeperController.php:175
* @route '/gatekeeper/print'
*/
printLogsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printLogs.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::printLogs
* @see app/Http/Controllers/GatekeeperController.php:175
* @route '/gatekeeper/print'
*/
printLogsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printLogs.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

printLogs.form = printLogsForm

/**
* @see \App\Http\Controllers\GatekeeperController::exportPDF
* @see app/Http/Controllers/GatekeeperController.php:157
* @route '/gatekeeper/export/pdf'
*/
export const exportPDF = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPDF.url(options),
    method: 'get',
})

exportPDF.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/export/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::exportPDF
* @see app/Http/Controllers/GatekeeperController.php:157
* @route '/gatekeeper/export/pdf'
*/
exportPDF.url = (options?: RouteQueryOptions) => {
    return exportPDF.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::exportPDF
* @see app/Http/Controllers/GatekeeperController.php:157
* @route '/gatekeeper/export/pdf'
*/
exportPDF.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPDF.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::exportPDF
* @see app/Http/Controllers/GatekeeperController.php:157
* @route '/gatekeeper/export/pdf'
*/
exportPDF.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportPDF.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::exportPDF
* @see app/Http/Controllers/GatekeeperController.php:157
* @route '/gatekeeper/export/pdf'
*/
const exportPDFForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportPDF.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::exportPDF
* @see app/Http/Controllers/GatekeeperController.php:157
* @route '/gatekeeper/export/pdf'
*/
exportPDFForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportPDF.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::exportPDF
* @see app/Http/Controllers/GatekeeperController.php:157
* @route '/gatekeeper/export/pdf'
*/
exportPDFForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportPDF.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

exportPDF.form = exportPDFForm

/**
* @see \App\Http\Controllers\GatekeeperController::getStats
* @see app/Http/Controllers/GatekeeperController.php:241
* @route '/gatekeeper/stats'
*/
export const getStats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStats.url(options),
    method: 'get',
})

getStats.definition = {
    methods: ["get","head"],
    url: '/gatekeeper/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GatekeeperController::getStats
* @see app/Http/Controllers/GatekeeperController.php:241
* @route '/gatekeeper/stats'
*/
getStats.url = (options?: RouteQueryOptions) => {
    return getStats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GatekeeperController::getStats
* @see app/Http/Controllers/GatekeeperController.php:241
* @route '/gatekeeper/stats'
*/
getStats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::getStats
* @see app/Http/Controllers/GatekeeperController.php:241
* @route '/gatekeeper/stats'
*/
getStats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getStats.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GatekeeperController::getStats
* @see app/Http/Controllers/GatekeeperController.php:241
* @route '/gatekeeper/stats'
*/
const getStatsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getStats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::getStats
* @see app/Http/Controllers/GatekeeperController.php:241
* @route '/gatekeeper/stats'
*/
getStatsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getStats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GatekeeperController::getStats
* @see app/Http/Controllers/GatekeeperController.php:241
* @route '/gatekeeper/stats'
*/
getStatsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getStats.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getStats.form = getStatsForm

const GatekeeperController = { index, recordInForm, storeRecordIn, recordOutForm, storeRecordOut, show, edit, update, destroy, printLogs, exportPDF, getStats }

export default GatekeeperController