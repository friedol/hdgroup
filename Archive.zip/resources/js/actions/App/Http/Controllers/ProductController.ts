import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults, validateParameters } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProductController::instock_product
* @see app/Http/Controllers/ProductController.php:981
* @route '/instock-products'
*/
export const instock_product = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: instock_product.url(options),
    method: 'get',
})

instock_product.definition = {
    methods: ["get","head"],
    url: '/instock-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::instock_product
* @see app/Http/Controllers/ProductController.php:981
* @route '/instock-products'
*/
instock_product.url = (options?: RouteQueryOptions) => {
    return instock_product.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::instock_product
* @see app/Http/Controllers/ProductController.php:981
* @route '/instock-products'
*/
instock_product.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: instock_product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::instock_product
* @see app/Http/Controllers/ProductController.php:981
* @route '/instock-products'
*/
instock_product.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: instock_product.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::instock_product
* @see app/Http/Controllers/ProductController.php:981
* @route '/instock-products'
*/
const instock_productForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: instock_product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::instock_product
* @see app/Http/Controllers/ProductController.php:981
* @route '/instock-products'
*/
instock_productForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: instock_product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::instock_product
* @see app/Http/Controllers/ProductController.php:981
* @route '/instock-products'
*/
instock_productForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: instock_product.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

instock_product.form = instock_productForm

/**
* @see \App\Http\Controllers\ProductController::outstock_product
* @see app/Http/Controllers/ProductController.php:1027
* @route '/outstock-product'
*/
export const outstock_product = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: outstock_product.url(options),
    method: 'get',
})

outstock_product.definition = {
    methods: ["get","head"],
    url: '/outstock-product',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::outstock_product
* @see app/Http/Controllers/ProductController.php:1027
* @route '/outstock-product'
*/
outstock_product.url = (options?: RouteQueryOptions) => {
    return outstock_product.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::outstock_product
* @see app/Http/Controllers/ProductController.php:1027
* @route '/outstock-product'
*/
outstock_product.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: outstock_product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::outstock_product
* @see app/Http/Controllers/ProductController.php:1027
* @route '/outstock-product'
*/
outstock_product.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: outstock_product.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::outstock_product
* @see app/Http/Controllers/ProductController.php:1027
* @route '/outstock-product'
*/
const outstock_productForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: outstock_product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::outstock_product
* @see app/Http/Controllers/ProductController.php:1027
* @route '/outstock-product'
*/
outstock_productForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: outstock_product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::outstock_product
* @see app/Http/Controllers/ProductController.php:1027
* @route '/outstock-product'
*/
outstock_productForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: outstock_product.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

outstock_product.form = outstock_productForm

/**
* @see \App\Http\Controllers\ProductController::less_product
* @see app/Http/Controllers/ProductController.php:1004
* @route '/less-product'
*/
export const less_product = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: less_product.url(options),
    method: 'get',
})

less_product.definition = {
    methods: ["get","head"],
    url: '/less-product',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::less_product
* @see app/Http/Controllers/ProductController.php:1004
* @route '/less-product'
*/
less_product.url = (options?: RouteQueryOptions) => {
    return less_product.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::less_product
* @see app/Http/Controllers/ProductController.php:1004
* @route '/less-product'
*/
less_product.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: less_product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::less_product
* @see app/Http/Controllers/ProductController.php:1004
* @route '/less-product'
*/
less_product.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: less_product.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::less_product
* @see app/Http/Controllers/ProductController.php:1004
* @route '/less-product'
*/
const less_productForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: less_product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::less_product
* @see app/Http/Controllers/ProductController.php:1004
* @route '/less-product'
*/
less_productForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: less_product.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::less_product
* @see app/Http/Controllers/ProductController.php:1004
* @route '/less-product'
*/
less_productForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: less_product.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

less_product.form = less_productForm

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:40
* @route '/all-products'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/all-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:40
* @route '/all-products'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:40
* @route '/all-products'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:40
* @route '/all-products'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:40
* @route '/all-products'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:40
* @route '/all-products'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:40
* @route '/all-products'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/all-products/create'
*/
const create8aabadf9dd7fcbff339e21f5756f24f0 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create8aabadf9dd7fcbff339e21f5756f24f0.url(options),
    method: 'get',
})

create8aabadf9dd7fcbff339e21f5756f24f0.definition = {
    methods: ["get","head"],
    url: '/all-products/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/all-products/create'
*/
create8aabadf9dd7fcbff339e21f5756f24f0.url = (options?: RouteQueryOptions) => {
    return create8aabadf9dd7fcbff339e21f5756f24f0.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/all-products/create'
*/
create8aabadf9dd7fcbff339e21f5756f24f0.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create8aabadf9dd7fcbff339e21f5756f24f0.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/all-products/create'
*/
create8aabadf9dd7fcbff339e21f5756f24f0.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create8aabadf9dd7fcbff339e21f5756f24f0.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/all-products/create'
*/
const create8aabadf9dd7fcbff339e21f5756f24f0Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create8aabadf9dd7fcbff339e21f5756f24f0.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/all-products/create'
*/
create8aabadf9dd7fcbff339e21f5756f24f0Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create8aabadf9dd7fcbff339e21f5756f24f0.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/all-products/create'
*/
create8aabadf9dd7fcbff339e21f5756f24f0Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create8aabadf9dd7fcbff339e21f5756f24f0.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create8aabadf9dd7fcbff339e21f5756f24f0.form = create8aabadf9dd7fcbff339e21f5756f24f0Form
/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/products-new/create'
*/
const create1359839b2fc4cdd66b3b95ccaac3d1cb = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create1359839b2fc4cdd66b3b95ccaac3d1cb.url(options),
    method: 'get',
})

create1359839b2fc4cdd66b3b95ccaac3d1cb.definition = {
    methods: ["get","head"],
    url: '/products-new/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/products-new/create'
*/
create1359839b2fc4cdd66b3b95ccaac3d1cb.url = (options?: RouteQueryOptions) => {
    return create1359839b2fc4cdd66b3b95ccaac3d1cb.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/products-new/create'
*/
create1359839b2fc4cdd66b3b95ccaac3d1cb.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create1359839b2fc4cdd66b3b95ccaac3d1cb.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/products-new/create'
*/
create1359839b2fc4cdd66b3b95ccaac3d1cb.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create1359839b2fc4cdd66b3b95ccaac3d1cb.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/products-new/create'
*/
const create1359839b2fc4cdd66b3b95ccaac3d1cbForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create1359839b2fc4cdd66b3b95ccaac3d1cb.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/products-new/create'
*/
create1359839b2fc4cdd66b3b95ccaac3d1cbForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create1359839b2fc4cdd66b3b95ccaac3d1cb.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::create
* @see app/Http/Controllers/ProductController.php:134
* @route '/products-new/create'
*/
create1359839b2fc4cdd66b3b95ccaac3d1cbForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create1359839b2fc4cdd66b3b95ccaac3d1cb.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create1359839b2fc4cdd66b3b95ccaac3d1cb.form = create1359839b2fc4cdd66b3b95ccaac3d1cbForm

export const create = {
    '/all-products/create': create8aabadf9dd7fcbff339e21f5756f24f0,
    '/products-new/create': create1359839b2fc4cdd66b3b95ccaac3d1cb,
}

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:297
* @route '/all-products'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/all-products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:297
* @route '/all-products'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:297
* @route '/all-products'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:297
* @route '/all-products'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:297
* @route '/all-products'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\ProductController::edit
* @see app/Http/Controllers/ProductController.php:808
* @route '/all-products/{all_product}/edit'
*/
export const edit = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/all-products/{all_product}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::edit
* @see app/Http/Controllers/ProductController.php:808
* @route '/all-products/{all_product}/edit'
*/
edit.url = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { all_product: args }
    }

    if (Array.isArray(args)) {
        args = {
            all_product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        all_product: args.all_product,
    }

    return edit.definition.url
            .replace('{all_product}', parsedArgs.all_product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::edit
* @see app/Http/Controllers/ProductController.php:808
* @route '/all-products/{all_product}/edit'
*/
edit.get = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::edit
* @see app/Http/Controllers/ProductController.php:808
* @route '/all-products/{all_product}/edit'
*/
edit.head = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::edit
* @see app/Http/Controllers/ProductController.php:808
* @route '/all-products/{all_product}/edit'
*/
const editForm = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::edit
* @see app/Http/Controllers/ProductController.php:808
* @route '/all-products/{all_product}/edit'
*/
editForm.get = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::edit
* @see app/Http/Controllers/ProductController.php:808
* @route '/all-products/{all_product}/edit'
*/
editForm.head = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:625
* @route '/all-products/{all_product}'
*/
export const update = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/all-products/{all_product}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:625
* @route '/all-products/{all_product}'
*/
update.url = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { all_product: args }
    }

    if (Array.isArray(args)) {
        args = {
            all_product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        all_product: args.all_product,
    }

    return update.definition.url
            .replace('{all_product}', parsedArgs.all_product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:625
* @route '/all-products/{all_product}'
*/
update.put = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:625
* @route '/all-products/{all_product}'
*/
update.patch = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:625
* @route '/all-products/{all_product}'
*/
const updateForm = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:625
* @route '/all-products/{all_product}'
*/
updateForm.put = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:625
* @route '/all-products/{all_product}'
*/
updateForm.patch = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:889
* @route '/all-products/{all_product}'
*/
export const destroy = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/all-products/{all_product}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:889
* @route '/all-products/{all_product}'
*/
destroy.url = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { all_product: args }
    }

    if (Array.isArray(args)) {
        args = {
            all_product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        all_product: args.all_product,
    }

    return destroy.definition.url
            .replace('{all_product}', parsedArgs.all_product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:889
* @route '/all-products/{all_product}'
*/
destroy.delete = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:889
* @route '/all-products/{all_product}'
*/
const destroyForm = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:889
* @route '/all-products/{all_product}'
*/
destroyForm.delete = (args: { all_product: string | number } | [all_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:161
* @route '/all-products/{id}/{year?}/{month?}'
*/
export const show = (args: { id: string | number, year?: string | number, month?: string | number } | [id: string | number, year: string | number, month: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/all-products/{id}/{year?}/{month?}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:161
* @route '/all-products/{id}/{year?}/{month?}'
*/
show.url = (args: { id: string | number, year?: string | number, month?: string | number } | [id: string | number, year: string | number, month: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            id: args[0],
            year: args[1],
            month: args[2],
        }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
        "year",
        "month",
    ])

    const parsedArgs = {
        id: args.id,
        year: args.year,
        month: args.month,
    }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace('{year?}', parsedArgs.year?.toString() ?? '')
            .replace('{month?}', parsedArgs.month?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:161
* @route '/all-products/{id}/{year?}/{month?}'
*/
show.get = (args: { id: string | number, year?: string | number, month?: string | number } | [id: string | number, year: string | number, month: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:161
* @route '/all-products/{id}/{year?}/{month?}'
*/
show.head = (args: { id: string | number, year?: string | number, month?: string | number } | [id: string | number, year: string | number, month: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:161
* @route '/all-products/{id}/{year?}/{month?}'
*/
const showForm = (args: { id: string | number, year?: string | number, month?: string | number } | [id: string | number, year: string | number, month: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:161
* @route '/all-products/{id}/{year?}/{month?}'
*/
showForm.get = (args: { id: string | number, year?: string | number, month?: string | number } | [id: string | number, year: string | number, month: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:161
* @route '/all-products/{id}/{year?}/{month?}'
*/
showForm.head = (args: { id: string | number, year?: string | number, month?: string | number } | [id: string | number, year: string | number, month: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\ProductController::indexCrud
* @see app/Http/Controllers/ProductController.php:1054
* @route '/products-new'
*/
export const indexCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

indexCrud.definition = {
    methods: ["get","head"],
    url: '/products-new',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::indexCrud
* @see app/Http/Controllers/ProductController.php:1054
* @route '/products-new'
*/
indexCrud.url = (options?: RouteQueryOptions) => {
    return indexCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::indexCrud
* @see app/Http/Controllers/ProductController.php:1054
* @route '/products-new'
*/
indexCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::indexCrud
* @see app/Http/Controllers/ProductController.php:1054
* @route '/products-new'
*/
indexCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::indexCrud
* @see app/Http/Controllers/ProductController.php:1054
* @route '/products-new'
*/
const indexCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::indexCrud
* @see app/Http/Controllers/ProductController.php:1054
* @route '/products-new'
*/
indexCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::indexCrud
* @see app/Http/Controllers/ProductController.php:1054
* @route '/products-new'
*/
indexCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexCrud.form = indexCrudForm

/**
* @see \App\Http\Controllers\ProductController::storeCrud
* @see app/Http/Controllers/ProductController.php:1175
* @route '/products-new'
*/
export const storeCrud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

storeCrud.definition = {
    methods: ["post"],
    url: '/products-new',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductController::storeCrud
* @see app/Http/Controllers/ProductController.php:1175
* @route '/products-new'
*/
storeCrud.url = (options?: RouteQueryOptions) => {
    return storeCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::storeCrud
* @see app/Http/Controllers/ProductController.php:1175
* @route '/products-new'
*/
storeCrud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::storeCrud
* @see app/Http/Controllers/ProductController.php:1175
* @route '/products-new'
*/
const storeCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::storeCrud
* @see app/Http/Controllers/ProductController.php:1175
* @route '/products-new'
*/
storeCrudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

storeCrud.form = storeCrudForm

/**
* @see \App\Http\Controllers\ProductController::showCrud
* @see app/Http/Controllers/ProductController.php:1343
* @route '/products-new/{id}'
*/
export const showCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

showCrud.definition = {
    methods: ["get","head"],
    url: '/products-new/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::showCrud
* @see app/Http/Controllers/ProductController.php:1343
* @route '/products-new/{id}'
*/
showCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return showCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::showCrud
* @see app/Http/Controllers/ProductController.php:1343
* @route '/products-new/{id}'
*/
showCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::showCrud
* @see app/Http/Controllers/ProductController.php:1343
* @route '/products-new/{id}'
*/
showCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::showCrud
* @see app/Http/Controllers/ProductController.php:1343
* @route '/products-new/{id}'
*/
const showCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::showCrud
* @see app/Http/Controllers/ProductController.php:1343
* @route '/products-new/{id}'
*/
showCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::showCrud
* @see app/Http/Controllers/ProductController.php:1343
* @route '/products-new/{id}'
*/
showCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showCrud.form = showCrudForm

/**
* @see \App\Http\Controllers\ProductController::editCrud
* @see app/Http/Controllers/ProductController.php:1474
* @route '/products-new/{id}/edit'
*/
export const editCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

editCrud.definition = {
    methods: ["get","head"],
    url: '/products-new/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::editCrud
* @see app/Http/Controllers/ProductController.php:1474
* @route '/products-new/{id}/edit'
*/
editCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return editCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::editCrud
* @see app/Http/Controllers/ProductController.php:1474
* @route '/products-new/{id}/edit'
*/
editCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::editCrud
* @see app/Http/Controllers/ProductController.php:1474
* @route '/products-new/{id}/edit'
*/
editCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::editCrud
* @see app/Http/Controllers/ProductController.php:1474
* @route '/products-new/{id}/edit'
*/
const editCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::editCrud
* @see app/Http/Controllers/ProductController.php:1474
* @route '/products-new/{id}/edit'
*/
editCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::editCrud
* @see app/Http/Controllers/ProductController.php:1474
* @route '/products-new/{id}/edit'
*/
editCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editCrud.form = editCrudForm

/**
* @see \App\Http\Controllers\ProductController::updateCrud
* @see app/Http/Controllers/ProductController.php:1547
* @route '/products-new/{id}'
*/
export const updateCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

updateCrud.definition = {
    methods: ["put"],
    url: '/products-new/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ProductController::updateCrud
* @see app/Http/Controllers/ProductController.php:1547
* @route '/products-new/{id}'
*/
updateCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::updateCrud
* @see app/Http/Controllers/ProductController.php:1547
* @route '/products-new/{id}'
*/
updateCrud.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ProductController::updateCrud
* @see app/Http/Controllers/ProductController.php:1547
* @route '/products-new/{id}'
*/
const updateCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::updateCrud
* @see app/Http/Controllers/ProductController.php:1547
* @route '/products-new/{id}'
*/
updateCrudForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateCrud.form = updateCrudForm

/**
* @see \App\Http\Controllers\ProductController::reactivateCrud
* @see app/Http/Controllers/ProductController.php:1713
* @route '/products-new/{id}/reactivate'
*/
export const reactivateCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reactivateCrud.url(args, options),
    method: 'post',
})

reactivateCrud.definition = {
    methods: ["post"],
    url: '/products-new/{id}/reactivate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductController::reactivateCrud
* @see app/Http/Controllers/ProductController.php:1713
* @route '/products-new/{id}/reactivate'
*/
reactivateCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return reactivateCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::reactivateCrud
* @see app/Http/Controllers/ProductController.php:1713
* @route '/products-new/{id}/reactivate'
*/
reactivateCrud.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reactivateCrud.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::reactivateCrud
* @see app/Http/Controllers/ProductController.php:1713
* @route '/products-new/{id}/reactivate'
*/
const reactivateCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reactivateCrud.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::reactivateCrud
* @see app/Http/Controllers/ProductController.php:1713
* @route '/products-new/{id}/reactivate'
*/
reactivateCrudForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reactivateCrud.url(args, options),
    method: 'post',
})

reactivateCrud.form = reactivateCrudForm

/**
* @see \App\Http\Controllers\ProductController::destroyCrud
* @see app/Http/Controllers/ProductController.php:1738
* @route '/products-new/{id}'
*/
export const destroyCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

destroyCrud.definition = {
    methods: ["delete"],
    url: '/products-new/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProductController::destroyCrud
* @see app/Http/Controllers/ProductController.php:1738
* @route '/products-new/{id}'
*/
destroyCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroyCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::destroyCrud
* @see app/Http/Controllers/ProductController.php:1738
* @route '/products-new/{id}'
*/
destroyCrud.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ProductController::destroyCrud
* @see app/Http/Controllers/ProductController.php:1738
* @route '/products-new/{id}'
*/
const destroyCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::destroyCrud
* @see app/Http/Controllers/ProductController.php:1738
* @route '/products-new/{id}'
*/
destroyCrudForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyCrud.form = destroyCrudForm

/**
* @see \App\Http\Controllers\ProductController::toggleStatus
* @see app/Http/Controllers/ProductController.php:948
* @route '/product-toggle-status'
*/
export const toggleStatus = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleStatus.url(options),
    method: 'post',
})

toggleStatus.definition = {
    methods: ["post"],
    url: '/product-toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductController::toggleStatus
* @see app/Http/Controllers/ProductController.php:948
* @route '/product-toggle-status'
*/
toggleStatus.url = (options?: RouteQueryOptions) => {
    return toggleStatus.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::toggleStatus
* @see app/Http/Controllers/ProductController.php:948
* @route '/product-toggle-status'
*/
toggleStatus.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleStatus.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::toggleStatus
* @see app/Http/Controllers/ProductController.php:948
* @route '/product-toggle-status'
*/
const toggleStatusForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleStatus.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::toggleStatus
* @see app/Http/Controllers/ProductController.php:948
* @route '/product-toggle-status'
*/
toggleStatusForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleStatus.url(options),
    method: 'post',
})

toggleStatus.form = toggleStatusForm

/**
* @see \App\Http\Controllers\ProductController::toggleVisibility
* @see app/Http/Controllers/ProductController.php:962
* @route '/product-toggle-visibility'
*/
export const toggleVisibility = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleVisibility.url(options),
    method: 'post',
})

toggleVisibility.definition = {
    methods: ["post"],
    url: '/product-toggle-visibility',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductController::toggleVisibility
* @see app/Http/Controllers/ProductController.php:962
* @route '/product-toggle-visibility'
*/
toggleVisibility.url = (options?: RouteQueryOptions) => {
    return toggleVisibility.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::toggleVisibility
* @see app/Http/Controllers/ProductController.php:962
* @route '/product-toggle-visibility'
*/
toggleVisibility.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleVisibility.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::toggleVisibility
* @see app/Http/Controllers/ProductController.php:962
* @route '/product-toggle-visibility'
*/
const toggleVisibilityForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleVisibility.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::toggleVisibility
* @see app/Http/Controllers/ProductController.php:962
* @route '/product-toggle-visibility'
*/
toggleVisibilityForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleVisibility.url(options),
    method: 'post',
})

toggleVisibility.form = toggleVisibilityForm

const ProductController = { instock_product, outstock_product, less_product, index, create, store, edit, update, destroy, show, indexCrud, storeCrud, showCrud, editCrud, updateCrud, reactivateCrud, destroyCrud, toggleStatus, toggleVisibility }

export default ProductController