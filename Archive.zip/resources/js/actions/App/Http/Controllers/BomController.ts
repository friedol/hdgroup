import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\BomController::indexCrud
* @see app/Http/Controllers/BomController.php:575
* @route '/boms-crud'
*/
export const indexCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

indexCrud.definition = {
    methods: ["get","head"],
    url: '/boms-crud',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::indexCrud
* @see app/Http/Controllers/BomController.php:575
* @route '/boms-crud'
*/
indexCrud.url = (options?: RouteQueryOptions) => {
    return indexCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::indexCrud
* @see app/Http/Controllers/BomController.php:575
* @route '/boms-crud'
*/
indexCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::indexCrud
* @see app/Http/Controllers/BomController.php:575
* @route '/boms-crud'
*/
indexCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::indexCrud
* @see app/Http/Controllers/BomController.php:575
* @route '/boms-crud'
*/
const indexCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::indexCrud
* @see app/Http/Controllers/BomController.php:575
* @route '/boms-crud'
*/
indexCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::indexCrud
* @see app/Http/Controllers/BomController.php:575
* @route '/boms-crud'
*/
indexCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexCrud.form = indexCrudForm

/**
* @see \App\Http\Controllers\BomController::createCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
export const createCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

createCrud.definition = {
    methods: ["get","head"],
    url: '/boms-crud/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::createCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
createCrud.url = (options?: RouteQueryOptions) => {
    return createCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::createCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
createCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::createCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
createCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::createCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
const createCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::createCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
createCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::createCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/create'
*/
createCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

createCrud.form = createCrudForm

/**
* @see \App\Http\Controllers\BomController::storeCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud'
*/
export const storeCrud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

storeCrud.definition = {
    methods: ["post"],
    url: '/boms-crud',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BomController::storeCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud'
*/
storeCrud.url = (options?: RouteQueryOptions) => {
    return storeCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::storeCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud'
*/
storeCrud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::storeCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud'
*/
const storeCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::storeCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud'
*/
storeCrudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

storeCrud.form = storeCrudForm

/**
* @see \App\Http\Controllers\BomController::showCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
export const showCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

showCrud.definition = {
    methods: ["get","head"],
    url: '/boms-crud/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::showCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
showCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return showCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::showCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
showCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::showCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
showCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::showCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
const showCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::showCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
showCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::showCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
showCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showCrud.form = showCrudForm

/**
* @see \App\Http\Controllers\BomController::editCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}/edit'
*/
export const editCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

editCrud.definition = {
    methods: ["get","head"],
    url: '/boms-crud/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::editCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}/edit'
*/
editCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return editCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::editCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}/edit'
*/
editCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::editCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}/edit'
*/
editCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::editCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}/edit'
*/
const editCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::editCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}/edit'
*/
editCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::editCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}/edit'
*/
editCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editCrud.form = editCrudForm

/**
* @see \App\Http\Controllers\BomController::updateCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
export const updateCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

updateCrud.definition = {
    methods: ["put"],
    url: '/boms-crud/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\BomController::updateCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
updateCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::updateCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
updateCrud.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\BomController::updateCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
const updateCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::updateCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
updateCrudForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateCrud.form = updateCrudForm

/**
* @see \App\Http\Controllers\BomController::destroyCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
export const destroyCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

destroyCrud.definition = {
    methods: ["delete"],
    url: '/boms-crud/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\BomController::destroyCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
destroyCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroyCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::destroyCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
destroyCrud.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\BomController::destroyCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
const destroyCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::destroyCrud
* @see app/Http/Controllers/BomController.php:0
* @route '/boms-crud/{id}'
*/
destroyCrudForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyCrud.form = destroyCrudForm

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/boms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::index
* @see app/Http/Controllers/BomController.php:538
* @route '/boms'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/boms/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::create
* @see app/Http/Controllers/BomController.php:580
* @route '/boms/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:602
* @route '/boms'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/boms',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:602
* @route '/boms'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:602
* @route '/boms'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:602
* @route '/boms'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::store
* @see app/Http/Controllers/BomController.php:602
* @route '/boms'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
export const show = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/boms/{bom}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
show.url = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bom: args }
    }

    if (Array.isArray(args)) {
        args = {
            bom: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        bom: args.bom,
    }

    return show.definition.url
            .replace('{bom}', parsedArgs.bom.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
show.get = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
show.head = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
const showForm = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
showForm.get = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::show
* @see app/Http/Controllers/BomController.php:682
* @route '/boms/{bom}'
*/
showForm.head = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
export const edit = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/boms/{bom}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
edit.url = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bom: args }
    }

    if (Array.isArray(args)) {
        args = {
            bom: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        bom: args.bom,
    }

    return edit.definition.url
            .replace('{bom}', parsedArgs.bom.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
edit.get = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
edit.head = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
const editForm = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
editForm.get = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::edit
* @see app/Http/Controllers/BomController.php:692
* @route '/boms/{bom}/edit'
*/
editForm.head = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
export const update = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/boms/{bom}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
update.url = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bom: args }
    }

    if (Array.isArray(args)) {
        args = {
            bom: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        bom: args.bom,
    }

    return update.definition.url
            .replace('{bom}', parsedArgs.bom.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
update.put = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
update.patch = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
const updateForm = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
updateForm.put = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::update
* @see app/Http/Controllers/BomController.php:717
* @route '/boms/{bom}'
*/
updateForm.patch = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:810
* @route '/boms/{bom}'
*/
export const destroy = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/boms/{bom}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:810
* @route '/boms/{bom}'
*/
destroy.url = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bom: args }
    }

    if (Array.isArray(args)) {
        args = {
            bom: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        bom: args.bom,
    }

    return destroy.definition.url
            .replace('{bom}', parsedArgs.bom.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:810
* @route '/boms/{bom}'
*/
destroy.delete = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:810
* @route '/boms/{bom}'
*/
const destroyForm = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::destroy
* @see app/Http/Controllers/BomController.php:810
* @route '/boms/{bom}'
*/
destroyForm.delete = (args: { bom: string | number } | [bom: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\BomController::rawMaterialsIndex
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
export const rawMaterialsIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialsIndex.url(options),
    method: 'get',
})

rawMaterialsIndex.definition = {
    methods: ["get","head"],
    url: '/raw-materials',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::rawMaterialsIndex
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
rawMaterialsIndex.url = (options?: RouteQueryOptions) => {
    return rawMaterialsIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::rawMaterialsIndex
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
rawMaterialsIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialsIndex.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsIndex
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
rawMaterialsIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: rawMaterialsIndex.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsIndex
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
const rawMaterialsIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsIndex.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsIndex
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
rawMaterialsIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsIndex.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsIndex
* @see app/Http/Controllers/BomController.php:24
* @route '/raw-materials'
*/
rawMaterialsIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsIndex.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

rawMaterialsIndex.form = rawMaterialsIndexForm

/**
* @see \App\Http\Controllers\BomController::rawMaterialsCreate
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
export const rawMaterialsCreate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialsCreate.url(options),
    method: 'get',
})

rawMaterialsCreate.definition = {
    methods: ["get","head"],
    url: '/raw-materials/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::rawMaterialsCreate
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
rawMaterialsCreate.url = (options?: RouteQueryOptions) => {
    return rawMaterialsCreate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::rawMaterialsCreate
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
rawMaterialsCreate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialsCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsCreate
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
rawMaterialsCreate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: rawMaterialsCreate.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsCreate
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
const rawMaterialsCreateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsCreate
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
rawMaterialsCreateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsCreate
* @see app/Http/Controllers/BomController.php:105
* @route '/raw-materials/create'
*/
rawMaterialsCreateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsCreate.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

rawMaterialsCreate.form = rawMaterialsCreateForm

/**
* @see \App\Http\Controllers\BomController::rawMaterialsStore
* @see app/Http/Controllers/BomController.php:130
* @route '/raw-materials'
*/
export const rawMaterialsStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rawMaterialsStore.url(options),
    method: 'post',
})

rawMaterialsStore.definition = {
    methods: ["post"],
    url: '/raw-materials',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BomController::rawMaterialsStore
* @see app/Http/Controllers/BomController.php:130
* @route '/raw-materials'
*/
rawMaterialsStore.url = (options?: RouteQueryOptions) => {
    return rawMaterialsStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::rawMaterialsStore
* @see app/Http/Controllers/BomController.php:130
* @route '/raw-materials'
*/
rawMaterialsStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rawMaterialsStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsStore
* @see app/Http/Controllers/BomController.php:130
* @route '/raw-materials'
*/
const rawMaterialsStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rawMaterialsStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsStore
* @see app/Http/Controllers/BomController.php:130
* @route '/raw-materials'
*/
rawMaterialsStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rawMaterialsStore.url(options),
    method: 'post',
})

rawMaterialsStore.form = rawMaterialsStoreForm

/**
* @see \App\Http\Controllers\BomController::rawMaterialsShow
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
export const rawMaterialsShow = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialsShow.url(args, options),
    method: 'get',
})

rawMaterialsShow.definition = {
    methods: ["get","head"],
    url: '/raw-materials/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::rawMaterialsShow
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
rawMaterialsShow.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return rawMaterialsShow.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::rawMaterialsShow
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
rawMaterialsShow.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialsShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsShow
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
rawMaterialsShow.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: rawMaterialsShow.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsShow
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
const rawMaterialsShowForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsShow
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
rawMaterialsShowForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsShow
* @see app/Http/Controllers/BomController.php:291
* @route '/raw-materials/{id}'
*/
rawMaterialsShowForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsShow.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

rawMaterialsShow.form = rawMaterialsShowForm

/**
* @see \App\Http\Controllers\BomController::rawMaterialsEdit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
export const rawMaterialsEdit = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialsEdit.url(args, options),
    method: 'get',
})

rawMaterialsEdit.definition = {
    methods: ["get","head"],
    url: '/raw-materials/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::rawMaterialsEdit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
rawMaterialsEdit.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return rawMaterialsEdit.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::rawMaterialsEdit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
rawMaterialsEdit.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialsEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsEdit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
rawMaterialsEdit.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: rawMaterialsEdit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsEdit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
const rawMaterialsEditForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsEdit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
rawMaterialsEditForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsEdit
* @see app/Http/Controllers/BomController.php:338
* @route '/raw-materials/{id}/edit'
*/
rawMaterialsEditForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsEdit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

rawMaterialsEdit.form = rawMaterialsEditForm

/**
* @see \App\Http\Controllers\BomController::rawMaterialsUpdate
* @see app/Http/Controllers/BomController.php:366
* @route '/raw-materials/{id}'
*/
export const rawMaterialsUpdate = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: rawMaterialsUpdate.url(args, options),
    method: 'put',
})

rawMaterialsUpdate.definition = {
    methods: ["put"],
    url: '/raw-materials/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\BomController::rawMaterialsUpdate
* @see app/Http/Controllers/BomController.php:366
* @route '/raw-materials/{id}'
*/
rawMaterialsUpdate.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return rawMaterialsUpdate.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::rawMaterialsUpdate
* @see app/Http/Controllers/BomController.php:366
* @route '/raw-materials/{id}'
*/
rawMaterialsUpdate.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: rawMaterialsUpdate.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsUpdate
* @see app/Http/Controllers/BomController.php:366
* @route '/raw-materials/{id}'
*/
const rawMaterialsUpdateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rawMaterialsUpdate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsUpdate
* @see app/Http/Controllers/BomController.php:366
* @route '/raw-materials/{id}'
*/
rawMaterialsUpdateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rawMaterialsUpdate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

rawMaterialsUpdate.form = rawMaterialsUpdateForm

/**
* @see \App\Http\Controllers\BomController::rawMaterialsDestroy
* @see app/Http/Controllers/BomController.php:489
* @route '/raw-materials/{id}'
*/
export const rawMaterialsDestroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: rawMaterialsDestroy.url(args, options),
    method: 'delete',
})

rawMaterialsDestroy.definition = {
    methods: ["delete"],
    url: '/raw-materials/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\BomController::rawMaterialsDestroy
* @see app/Http/Controllers/BomController.php:489
* @route '/raw-materials/{id}'
*/
rawMaterialsDestroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return rawMaterialsDestroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::rawMaterialsDestroy
* @see app/Http/Controllers/BomController.php:489
* @route '/raw-materials/{id}'
*/
rawMaterialsDestroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: rawMaterialsDestroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsDestroy
* @see app/Http/Controllers/BomController.php:489
* @route '/raw-materials/{id}'
*/
const rawMaterialsDestroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rawMaterialsDestroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsDestroy
* @see app/Http/Controllers/BomController.php:489
* @route '/raw-materials/{id}'
*/
rawMaterialsDestroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rawMaterialsDestroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

rawMaterialsDestroy.form = rawMaterialsDestroyForm

/**
* @see \App\Http\Controllers\BomController::rawMaterialsAdjustStock
* @see app/Http/Controllers/BomController.php:501
* @route '/raw-materials/{id}/adjust'
*/
export const rawMaterialsAdjustStock = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rawMaterialsAdjustStock.url(args, options),
    method: 'post',
})

rawMaterialsAdjustStock.definition = {
    methods: ["post"],
    url: '/raw-materials/{id}/adjust',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BomController::rawMaterialsAdjustStock
* @see app/Http/Controllers/BomController.php:501
* @route '/raw-materials/{id}/adjust'
*/
rawMaterialsAdjustStock.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return rawMaterialsAdjustStock.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::rawMaterialsAdjustStock
* @see app/Http/Controllers/BomController.php:501
* @route '/raw-materials/{id}/adjust'
*/
rawMaterialsAdjustStock.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rawMaterialsAdjustStock.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsAdjustStock
* @see app/Http/Controllers/BomController.php:501
* @route '/raw-materials/{id}/adjust'
*/
const rawMaterialsAdjustStockForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rawMaterialsAdjustStock.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsAdjustStock
* @see app/Http/Controllers/BomController.php:501
* @route '/raw-materials/{id}/adjust'
*/
rawMaterialsAdjustStockForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rawMaterialsAdjustStock.url(args, options),
    method: 'post',
})

rawMaterialsAdjustStock.form = rawMaterialsAdjustStockForm

/**
* @see \App\Http\Controllers\BomController::rawMaterialsJson
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
export const rawMaterialsJson = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialsJson.url(args, options),
    method: 'get',
})

rawMaterialsJson.definition = {
    methods: ["get","head"],
    url: '/raw-materials/{id}/json',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BomController::rawMaterialsJson
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
rawMaterialsJson.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return rawMaterialsJson.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::rawMaterialsJson
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
rawMaterialsJson.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialsJson.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsJson
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
rawMaterialsJson.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: rawMaterialsJson.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsJson
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
const rawMaterialsJsonForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsJson.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsJson
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
rawMaterialsJsonForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsJson.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BomController::rawMaterialsJson
* @see app/Http/Controllers/BomController.php:301
* @route '/raw-materials/{id}/json'
*/
rawMaterialsJsonForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialsJson.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

rawMaterialsJson.form = rawMaterialsJsonForm

/**
* @see \App\Http\Controllers\BomController::calculateCost
* @see app/Http/Controllers/BomController.php:836
* @route '/boms/calculate-cost'
*/
export const calculateCost = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: calculateCost.url(options),
    method: 'post',
})

calculateCost.definition = {
    methods: ["post"],
    url: '/boms/calculate-cost',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BomController::calculateCost
* @see app/Http/Controllers/BomController.php:836
* @route '/boms/calculate-cost'
*/
calculateCost.url = (options?: RouteQueryOptions) => {
    return calculateCost.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::calculateCost
* @see app/Http/Controllers/BomController.php:836
* @route '/boms/calculate-cost'
*/
calculateCost.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: calculateCost.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::calculateCost
* @see app/Http/Controllers/BomController.php:836
* @route '/boms/calculate-cost'
*/
const calculateCostForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: calculateCost.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::calculateCost
* @see app/Http/Controllers/BomController.php:836
* @route '/boms/calculate-cost'
*/
calculateCostForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: calculateCost.url(options),
    method: 'post',
})

calculateCost.form = calculateCostForm

/**
* @see \App\Http\Controllers\BomController::activate
* @see app/Http/Controllers/BomController.php:775
* @route '/boms/{id}/activate'
*/
export const activate = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: activate.url(args, options),
    method: 'put',
})

activate.definition = {
    methods: ["put"],
    url: '/boms/{id}/activate',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\BomController::activate
* @see app/Http/Controllers/BomController.php:775
* @route '/boms/{id}/activate'
*/
activate.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return activate.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::activate
* @see app/Http/Controllers/BomController.php:775
* @route '/boms/{id}/activate'
*/
activate.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: activate.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\BomController::activate
* @see app/Http/Controllers/BomController.php:775
* @route '/boms/{id}/activate'
*/
const activateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: activate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::activate
* @see app/Http/Controllers/BomController.php:775
* @route '/boms/{id}/activate'
*/
activateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: activate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

activate.form = activateForm

/**
* @see \App\Http\Controllers\BomController::deactivate
* @see app/Http/Controllers/BomController.php:800
* @route '/boms/{id}/deactivate'
*/
export const deactivate = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: deactivate.url(args, options),
    method: 'put',
})

deactivate.definition = {
    methods: ["put"],
    url: '/boms/{id}/deactivate',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\BomController::deactivate
* @see app/Http/Controllers/BomController.php:800
* @route '/boms/{id}/deactivate'
*/
deactivate.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return deactivate.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BomController::deactivate
* @see app/Http/Controllers/BomController.php:800
* @route '/boms/{id}/deactivate'
*/
deactivate.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: deactivate.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\BomController::deactivate
* @see app/Http/Controllers/BomController.php:800
* @route '/boms/{id}/deactivate'
*/
const deactivateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deactivate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BomController::deactivate
* @see app/Http/Controllers/BomController.php:800
* @route '/boms/{id}/deactivate'
*/
deactivateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deactivate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

deactivate.form = deactivateForm

const BomController = { indexCrud, createCrud, storeCrud, showCrud, editCrud, updateCrud, destroyCrud, index, create, store, show, edit, update, destroy, rawMaterialsIndex, rawMaterialsCreate, rawMaterialsStore, rawMaterialsShow, rawMaterialsEdit, rawMaterialsUpdate, rawMaterialsDestroy, rawMaterialsAdjustStock, rawMaterialsJson, calculateCost, activate, deactivate }

export default BomController