import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
export const track = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track.url(args, options),
    method: 'get',
})

track.definition = {
    methods: ["get","head"],
    url: '/track/{deliveryNumber}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
track.url = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deliveryNumber: args }
    }

    if (Array.isArray(args)) {
        args = {
            deliveryNumber: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        deliveryNumber: args.deliveryNumber,
    }

    return track.definition.url
            .replace('{deliveryNumber}', parsedArgs.deliveryNumber.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
track.get = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
track.head = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: track.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
const trackForm = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
trackForm.get = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::track
* @see app/Http/Controllers/DeliveryTrackingController.php:15
* @route '/track/{deliveryNumber}'
*/
trackForm.head = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

track.form = trackForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::driverDashboard
* @see app/Http/Controllers/DeliveryTrackingController.php:36
* @route '/driver-dashboard'
*/
export const driverDashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: driverDashboard.url(options),
    method: 'get',
})

driverDashboard.definition = {
    methods: ["get","head"],
    url: '/driver-dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::driverDashboard
* @see app/Http/Controllers/DeliveryTrackingController.php:36
* @route '/driver-dashboard'
*/
driverDashboard.url = (options?: RouteQueryOptions) => {
    return driverDashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::driverDashboard
* @see app/Http/Controllers/DeliveryTrackingController.php:36
* @route '/driver-dashboard'
*/
driverDashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: driverDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::driverDashboard
* @see app/Http/Controllers/DeliveryTrackingController.php:36
* @route '/driver-dashboard'
*/
driverDashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: driverDashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::driverDashboard
* @see app/Http/Controllers/DeliveryTrackingController.php:36
* @route '/driver-dashboard'
*/
const driverDashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: driverDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::driverDashboard
* @see app/Http/Controllers/DeliveryTrackingController.php:36
* @route '/driver-dashboard'
*/
driverDashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: driverDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::driverDashboard
* @see app/Http/Controllers/DeliveryTrackingController.php:36
* @route '/driver-dashboard'
*/
driverDashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: driverDashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

driverDashboard.form = driverDashboardForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::acceptDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:82
* @route '/deliveries/{delivery}/accept'
*/
export const acceptDelivery = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: acceptDelivery.url(args, options),
    method: 'put',
})

acceptDelivery.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/accept',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::acceptDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:82
* @route '/deliveries/{delivery}/accept'
*/
acceptDelivery.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return acceptDelivery.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::acceptDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:82
* @route '/deliveries/{delivery}/accept'
*/
acceptDelivery.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: acceptDelivery.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::acceptDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:82
* @route '/deliveries/{delivery}/accept'
*/
const acceptDeliveryForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: acceptDelivery.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::acceptDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:82
* @route '/deliveries/{delivery}/accept'
*/
acceptDeliveryForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: acceptDelivery.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

acceptDelivery.form = acceptDeliveryForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::pickupDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:98
* @route '/deliveries/{delivery}/pickup'
*/
export const pickupDelivery = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: pickupDelivery.url(args, options),
    method: 'put',
})

pickupDelivery.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/pickup',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::pickupDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:98
* @route '/deliveries/{delivery}/pickup'
*/
pickupDelivery.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return pickupDelivery.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::pickupDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:98
* @route '/deliveries/{delivery}/pickup'
*/
pickupDelivery.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: pickupDelivery.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::pickupDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:98
* @route '/deliveries/{delivery}/pickup'
*/
const pickupDeliveryForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pickupDelivery.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::pickupDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:98
* @route '/deliveries/{delivery}/pickup'
*/
pickupDeliveryForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pickupDelivery.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

pickupDelivery.form = pickupDeliveryForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::inTransit
* @see app/Http/Controllers/DeliveryTrackingController.php:132
* @route '/deliveries/{delivery}/in-transit'
*/
export const inTransit = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: inTransit.url(args, options),
    method: 'put',
})

inTransit.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/in-transit',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::inTransit
* @see app/Http/Controllers/DeliveryTrackingController.php:132
* @route '/deliveries/{delivery}/in-transit'
*/
inTransit.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return inTransit.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::inTransit
* @see app/Http/Controllers/DeliveryTrackingController.php:132
* @route '/deliveries/{delivery}/in-transit'
*/
inTransit.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: inTransit.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::inTransit
* @see app/Http/Controllers/DeliveryTrackingController.php:132
* @route '/deliveries/{delivery}/in-transit'
*/
const inTransitForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: inTransit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::inTransit
* @see app/Http/Controllers/DeliveryTrackingController.php:132
* @route '/deliveries/{delivery}/in-transit'
*/
inTransitForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: inTransit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

inTransit.form = inTransitForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::completeDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:164
* @route '/deliveries/{delivery}/complete'
*/
export const completeDelivery = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: completeDelivery.url(args, options),
    method: 'put',
})

completeDelivery.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/complete',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::completeDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:164
* @route '/deliveries/{delivery}/complete'
*/
completeDelivery.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return completeDelivery.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::completeDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:164
* @route '/deliveries/{delivery}/complete'
*/
completeDelivery.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: completeDelivery.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::completeDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:164
* @route '/deliveries/{delivery}/complete'
*/
const completeDeliveryForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: completeDelivery.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::completeDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:164
* @route '/deliveries/{delivery}/complete'
*/
completeDeliveryForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: completeDelivery.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

completeDelivery.form = completeDeliveryForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::failDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:224
* @route '/deliveries/{delivery}/fail'
*/
export const failDelivery = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: failDelivery.url(args, options),
    method: 'put',
})

failDelivery.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/fail',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::failDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:224
* @route '/deliveries/{delivery}/fail'
*/
failDelivery.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return failDelivery.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::failDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:224
* @route '/deliveries/{delivery}/fail'
*/
failDelivery.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: failDelivery.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::failDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:224
* @route '/deliveries/{delivery}/fail'
*/
const failDeliveryForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: failDelivery.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::failDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:224
* @route '/deliveries/{delivery}/fail'
*/
failDeliveryForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: failDelivery.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

failDelivery.form = failDeliveryForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::rateDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:246
* @route '/deliveries/{delivery}/rate'
*/
export const rateDelivery = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: rateDelivery.url(args, options),
    method: 'put',
})

rateDelivery.definition = {
    methods: ["put"],
    url: '/deliveries/{delivery}/rate',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::rateDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:246
* @route '/deliveries/{delivery}/rate'
*/
rateDelivery.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { delivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            delivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        delivery: typeof args.delivery === 'object'
        ? args.delivery.id
        : args.delivery,
    }

    return rateDelivery.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::rateDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:246
* @route '/deliveries/{delivery}/rate'
*/
rateDelivery.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: rateDelivery.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::rateDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:246
* @route '/deliveries/{delivery}/rate'
*/
const rateDeliveryForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rateDelivery.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::rateDelivery
* @see app/Http/Controllers/DeliveryTrackingController.php:246
* @route '/deliveries/{delivery}/rate'
*/
rateDeliveryForm.put = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rateDelivery.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

rateDelivery.form = rateDeliveryForm

/**
* @see \App\Http\Controllers\DeliveryTrackingController::getDeliveryData
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
export const getDeliveryData = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDeliveryData.url(args, options),
    method: 'get',
})

getDeliveryData.definition = {
    methods: ["get","head"],
    url: '/api/delivery/{deliveryNumber}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeliveryTrackingController::getDeliveryData
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
getDeliveryData.url = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deliveryNumber: args }
    }

    if (Array.isArray(args)) {
        args = {
            deliveryNumber: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        deliveryNumber: args.deliveryNumber,
    }

    return getDeliveryData.definition.url
            .replace('{deliveryNumber}', parsedArgs.deliveryNumber.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeliveryTrackingController::getDeliveryData
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
getDeliveryData.get = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDeliveryData.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::getDeliveryData
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
getDeliveryData.head = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getDeliveryData.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::getDeliveryData
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
const getDeliveryDataForm = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDeliveryData.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::getDeliveryData
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
getDeliveryDataForm.get = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDeliveryData.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeliveryTrackingController::getDeliveryData
* @see app/Http/Controllers/DeliveryTrackingController.php:268
* @route '/api/delivery/{deliveryNumber}'
*/
getDeliveryDataForm.head = (args: { deliveryNumber: string | number } | [deliveryNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDeliveryData.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getDeliveryData.form = getDeliveryDataForm

const DeliveryTrackingController = { track, driverDashboard, acceptDelivery, pickupDelivery, inTransit, completeDelivery, failDelivery, rateDelivery, getDeliveryData }

export default DeliveryTrackingController