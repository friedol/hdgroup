import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:22
* @route '/stock-adjustments'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/stock-adjustments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:22
* @route '/stock-adjustments'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:22
* @route '/stock-adjustments'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:22
* @route '/stock-adjustments'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:22
* @route '/stock-adjustments'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:22
* @route '/stock-adjustments'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:22
* @route '/stock-adjustments'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\StockAdjustmentController::store
* @see app/Http/Controllers/StockAdjustmentController.php:45
* @route '/stock-adjustments'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/stock-adjustments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockAdjustmentController::store
* @see app/Http/Controllers/StockAdjustmentController.php:45
* @route '/stock-adjustments'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockAdjustmentController::store
* @see app/Http/Controllers/StockAdjustmentController.php:45
* @route '/stock-adjustments'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::store
* @see app/Http/Controllers/StockAdjustmentController.php:45
* @route '/stock-adjustments'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::store
* @see app/Http/Controllers/StockAdjustmentController.php:45
* @route '/stock-adjustments'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\StockAdjustmentController::destroy
* @see app/Http/Controllers/StockAdjustmentController.php:111
* @route '/stock-adjustments/{stock_adjustment}'
*/
export const destroy = (args: { stock_adjustment: string | number } | [stock_adjustment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/stock-adjustments/{stock_adjustment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\StockAdjustmentController::destroy
* @see app/Http/Controllers/StockAdjustmentController.php:111
* @route '/stock-adjustments/{stock_adjustment}'
*/
destroy.url = (args: { stock_adjustment: string | number } | [stock_adjustment: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { stock_adjustment: args }
    }

    if (Array.isArray(args)) {
        args = {
            stock_adjustment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        stock_adjustment: args.stock_adjustment,
    }

    return destroy.definition.url
            .replace('{stock_adjustment}', parsedArgs.stock_adjustment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockAdjustmentController::destroy
* @see app/Http/Controllers/StockAdjustmentController.php:111
* @route '/stock-adjustments/{stock_adjustment}'
*/
destroy.delete = (args: { stock_adjustment: string | number } | [stock_adjustment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::destroy
* @see app/Http/Controllers/StockAdjustmentController.php:111
* @route '/stock-adjustments/{stock_adjustment}'
*/
const destroyForm = (args: { stock_adjustment: string | number } | [stock_adjustment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::destroy
* @see app/Http/Controllers/StockAdjustmentController.php:111
* @route '/stock-adjustments/{stock_adjustment}'
*/
destroyForm.delete = (args: { stock_adjustment: string | number } | [stock_adjustment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\StockAdjustmentController::approve
* @see app/Http/Controllers/StockAdjustmentController.php:124
* @route '/stock-adjustments/{id}/approve'
*/
export const approve = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/stock-adjustments/{id}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockAdjustmentController::approve
* @see app/Http/Controllers/StockAdjustmentController.php:124
* @route '/stock-adjustments/{id}/approve'
*/
approve.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return approve.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockAdjustmentController::approve
* @see app/Http/Controllers/StockAdjustmentController.php:124
* @route '/stock-adjustments/{id}/approve'
*/
approve.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::approve
* @see app/Http/Controllers/StockAdjustmentController.php:124
* @route '/stock-adjustments/{id}/approve'
*/
const approveForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::approve
* @see app/Http/Controllers/StockAdjustmentController.php:124
* @route '/stock-adjustments/{id}/approve'
*/
approveForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

approve.form = approveForm

/**
* @see \App\Http\Controllers\StockAdjustmentController::reject
* @see app/Http/Controllers/StockAdjustmentController.php:134
* @route '/stock-adjustments/{id}/reject'
*/
export const reject = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/stock-adjustments/{id}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockAdjustmentController::reject
* @see app/Http/Controllers/StockAdjustmentController.php:134
* @route '/stock-adjustments/{id}/reject'
*/
reject.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return reject.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockAdjustmentController::reject
* @see app/Http/Controllers/StockAdjustmentController.php:134
* @route '/stock-adjustments/{id}/reject'
*/
reject.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::reject
* @see app/Http/Controllers/StockAdjustmentController.php:134
* @route '/stock-adjustments/{id}/reject'
*/
const rejectForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::reject
* @see app/Http/Controllers/StockAdjustmentController.php:134
* @route '/stock-adjustments/{id}/reject'
*/
rejectForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, options),
    method: 'post',
})

reject.form = rejectForm

const StockAdjustmentController = { index, store, destroy, approve, reject }

export default StockAdjustmentController