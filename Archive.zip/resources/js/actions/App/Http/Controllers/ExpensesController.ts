import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ExpensesController::indexCrud
* @see app/Http/Controllers/ExpensesController.php:34
* @route '/expenses-crud'
*/
export const indexCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

indexCrud.definition = {
    methods: ["get","head"],
    url: '/expenses-crud',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpensesController::indexCrud
* @see app/Http/Controllers/ExpensesController.php:34
* @route '/expenses-crud'
*/
indexCrud.url = (options?: RouteQueryOptions) => {
    return indexCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::indexCrud
* @see app/Http/Controllers/ExpensesController.php:34
* @route '/expenses-crud'
*/
indexCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::indexCrud
* @see app/Http/Controllers/ExpensesController.php:34
* @route '/expenses-crud'
*/
indexCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExpensesController::indexCrud
* @see app/Http/Controllers/ExpensesController.php:34
* @route '/expenses-crud'
*/
const indexCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::indexCrud
* @see app/Http/Controllers/ExpensesController.php:34
* @route '/expenses-crud'
*/
indexCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::indexCrud
* @see app/Http/Controllers/ExpensesController.php:34
* @route '/expenses-crud'
*/
indexCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexCrud.form = indexCrudForm

/**
* @see \App\Http\Controllers\ExpensesController::createCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/create'
*/
export const createCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

createCrud.definition = {
    methods: ["get","head"],
    url: '/expenses-crud/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpensesController::createCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/create'
*/
createCrud.url = (options?: RouteQueryOptions) => {
    return createCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::createCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/create'
*/
createCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::createCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/create'
*/
createCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExpensesController::createCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/create'
*/
const createCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::createCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/create'
*/
createCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::createCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/create'
*/
createCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

createCrud.form = createCrudForm

/**
* @see \App\Http\Controllers\ExpensesController::storeCrud
* @see app/Http/Controllers/ExpensesController.php:90
* @route '/expenses-crud'
*/
export const storeCrud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

storeCrud.definition = {
    methods: ["post"],
    url: '/expenses-crud',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ExpensesController::storeCrud
* @see app/Http/Controllers/ExpensesController.php:90
* @route '/expenses-crud'
*/
storeCrud.url = (options?: RouteQueryOptions) => {
    return storeCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::storeCrud
* @see app/Http/Controllers/ExpensesController.php:90
* @route '/expenses-crud'
*/
storeCrud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::storeCrud
* @see app/Http/Controllers/ExpensesController.php:90
* @route '/expenses-crud'
*/
const storeCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::storeCrud
* @see app/Http/Controllers/ExpensesController.php:90
* @route '/expenses-crud'
*/
storeCrudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

storeCrud.form = storeCrudForm

/**
* @see \App\Http\Controllers\ExpensesController::showCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}'
*/
export const showCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

showCrud.definition = {
    methods: ["get","head"],
    url: '/expenses-crud/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpensesController::showCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}'
*/
showCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return showCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::showCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}'
*/
showCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::showCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}'
*/
showCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExpensesController::showCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}'
*/
const showCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::showCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}'
*/
showCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::showCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}'
*/
showCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showCrud.form = showCrudForm

/**
* @see \App\Http\Controllers\ExpensesController::editCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}/edit'
*/
export const editCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

editCrud.definition = {
    methods: ["get","head"],
    url: '/expenses-crud/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpensesController::editCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}/edit'
*/
editCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return editCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::editCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}/edit'
*/
editCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::editCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}/edit'
*/
editCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExpensesController::editCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}/edit'
*/
const editCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::editCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}/edit'
*/
editCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::editCrud
* @see app/Http/Controllers/ExpensesController.php:0
* @route '/expenses-crud/{id}/edit'
*/
editCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editCrud.form = editCrudForm

/**
* @see \App\Http\Controllers\ExpensesController::updateCrud
* @see app/Http/Controllers/ExpensesController.php:114
* @route '/expenses-crud/{id}'
*/
export const updateCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

updateCrud.definition = {
    methods: ["put"],
    url: '/expenses-crud/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ExpensesController::updateCrud
* @see app/Http/Controllers/ExpensesController.php:114
* @route '/expenses-crud/{id}'
*/
updateCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::updateCrud
* @see app/Http/Controllers/ExpensesController.php:114
* @route '/expenses-crud/{id}'
*/
updateCrud.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ExpensesController::updateCrud
* @see app/Http/Controllers/ExpensesController.php:114
* @route '/expenses-crud/{id}'
*/
const updateCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::updateCrud
* @see app/Http/Controllers/ExpensesController.php:114
* @route '/expenses-crud/{id}'
*/
updateCrudForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateCrud.form = updateCrudForm

/**
* @see \App\Http\Controllers\ExpensesController::destroyCrud
* @see app/Http/Controllers/ExpensesController.php:129
* @route '/expenses-crud/{id}'
*/
export const destroyCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

destroyCrud.definition = {
    methods: ["delete"],
    url: '/expenses-crud/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ExpensesController::destroyCrud
* @see app/Http/Controllers/ExpensesController.php:129
* @route '/expenses-crud/{id}'
*/
destroyCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroyCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::destroyCrud
* @see app/Http/Controllers/ExpensesController.php:129
* @route '/expenses-crud/{id}'
*/
destroyCrud.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ExpensesController::destroyCrud
* @see app/Http/Controllers/ExpensesController.php:129
* @route '/expenses-crud/{id}'
*/
const destroyCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::destroyCrud
* @see app/Http/Controllers/ExpensesController.php:129
* @route '/expenses-crud/{id}'
*/
destroyCrudForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyCrud.form = destroyCrudForm

/**
* @see \App\Http\Controllers\ExpensesController::index
* @see app/Http/Controllers/ExpensesController.php:17
* @route '/expenses'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/expenses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpensesController::index
* @see app/Http/Controllers/ExpensesController.php:17
* @route '/expenses'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::index
* @see app/Http/Controllers/ExpensesController.php:17
* @route '/expenses'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::index
* @see app/Http/Controllers/ExpensesController.php:17
* @route '/expenses'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExpensesController::index
* @see app/Http/Controllers/ExpensesController.php:17
* @route '/expenses'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::index
* @see app/Http/Controllers/ExpensesController.php:17
* @route '/expenses'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::index
* @see app/Http/Controllers/ExpensesController.php:17
* @route '/expenses'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ExpensesController::store
* @see app/Http/Controllers/ExpensesController.php:171
* @route '/expenses'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/expenses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ExpensesController::store
* @see app/Http/Controllers/ExpensesController.php:171
* @route '/expenses'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::store
* @see app/Http/Controllers/ExpensesController.php:171
* @route '/expenses'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::store
* @see app/Http/Controllers/ExpensesController.php:171
* @route '/expenses'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::store
* @see app/Http/Controllers/ExpensesController.php:171
* @route '/expenses'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\ExpensesController::show
* @see app/Http/Controllers/ExpensesController.php:203
* @route '/expenses/{expense}'
*/
export const show = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/expenses/{expense}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpensesController::show
* @see app/Http/Controllers/ExpensesController.php:203
* @route '/expenses/{expense}'
*/
show.url = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expense: args }
    }

    if (Array.isArray(args)) {
        args = {
            expense: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        expense: args.expense,
    }

    return show.definition.url
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::show
* @see app/Http/Controllers/ExpensesController.php:203
* @route '/expenses/{expense}'
*/
show.get = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::show
* @see app/Http/Controllers/ExpensesController.php:203
* @route '/expenses/{expense}'
*/
show.head = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExpensesController::show
* @see app/Http/Controllers/ExpensesController.php:203
* @route '/expenses/{expense}'
*/
const showForm = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::show
* @see app/Http/Controllers/ExpensesController.php:203
* @route '/expenses/{expense}'
*/
showForm.get = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::show
* @see app/Http/Controllers/ExpensesController.php:203
* @route '/expenses/{expense}'
*/
showForm.head = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\ExpensesController::edit
* @see app/Http/Controllers/ExpensesController.php:225
* @route '/expenses/{expense}/edit'
*/
export const edit = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/expenses/{expense}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpensesController::edit
* @see app/Http/Controllers/ExpensesController.php:225
* @route '/expenses/{expense}/edit'
*/
edit.url = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expense: args }
    }

    if (Array.isArray(args)) {
        args = {
            expense: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        expense: args.expense,
    }

    return edit.definition.url
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::edit
* @see app/Http/Controllers/ExpensesController.php:225
* @route '/expenses/{expense}/edit'
*/
edit.get = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::edit
* @see app/Http/Controllers/ExpensesController.php:225
* @route '/expenses/{expense}/edit'
*/
edit.head = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExpensesController::edit
* @see app/Http/Controllers/ExpensesController.php:225
* @route '/expenses/{expense}/edit'
*/
const editForm = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::edit
* @see app/Http/Controllers/ExpensesController.php:225
* @route '/expenses/{expense}/edit'
*/
editForm.get = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::edit
* @see app/Http/Controllers/ExpensesController.php:225
* @route '/expenses/{expense}/edit'
*/
editForm.head = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\ExpensesController::update
* @see app/Http/Controllers/ExpensesController.php:233
* @route '/expenses/{expense}'
*/
export const update = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/expenses/{expense}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ExpensesController::update
* @see app/Http/Controllers/ExpensesController.php:233
* @route '/expenses/{expense}'
*/
update.url = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expense: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { expense: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            expense: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        expense: typeof args.expense === 'object'
        ? args.expense.id
        : args.expense,
    }

    return update.definition.url
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::update
* @see app/Http/Controllers/ExpensesController.php:233
* @route '/expenses/{expense}'
*/
update.put = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ExpensesController::update
* @see app/Http/Controllers/ExpensesController.php:233
* @route '/expenses/{expense}'
*/
update.patch = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\ExpensesController::update
* @see app/Http/Controllers/ExpensesController.php:233
* @route '/expenses/{expense}'
*/
const updateForm = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::update
* @see app/Http/Controllers/ExpensesController.php:233
* @route '/expenses/{expense}'
*/
updateForm.put = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::update
* @see app/Http/Controllers/ExpensesController.php:233
* @route '/expenses/{expense}'
*/
updateForm.patch = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\ExpensesController::destroy
* @see app/Http/Controllers/ExpensesController.php:261
* @route '/expenses/{expense}'
*/
export const destroy = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/expenses/{expense}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ExpensesController::destroy
* @see app/Http/Controllers/ExpensesController.php:261
* @route '/expenses/{expense}'
*/
destroy.url = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expense: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { expense: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            expense: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        expense: typeof args.expense === 'object'
        ? args.expense.id
        : args.expense,
    }

    return destroy.definition.url
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::destroy
* @see app/Http/Controllers/ExpensesController.php:261
* @route '/expenses/{expense}'
*/
destroy.delete = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ExpensesController::destroy
* @see app/Http/Controllers/ExpensesController.php:261
* @route '/expenses/{expense}'
*/
const destroyForm = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ExpensesController::destroy
* @see app/Http/Controllers/ExpensesController.php:261
* @route '/expenses/{expense}'
*/
destroyForm.delete = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\ExpensesController::reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
export const reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

reports.definition = {
    methods: ["get","head"],
    url: '/expenses_reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpensesController::reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
reports.url = (options?: RouteQueryOptions) => {
    return reports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reports.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExpensesController::reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
const reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::reports
* @see app/Http/Controllers/ExpensesController.php:136
* @route '/expenses_reports'
*/
reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

reports.form = reportsForm

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
export const voucher = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: voucher.url(args, options),
    method: 'get',
})

voucher.definition = {
    methods: ["get","head"],
    url: '/finance/expenses/{expense}/voucher',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
voucher.url = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expense: args }
    }

    if (Array.isArray(args)) {
        args = {
            expense: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        expense: args.expense,
    }

    return voucher.definition.url
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
voucher.get = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: voucher.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
voucher.head = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: voucher.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
const voucherForm = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
voucherForm.get = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ExpensesController::voucher
* @see app/Http/Controllers/ExpensesController.php:210
* @route '/finance/expenses/{expense}/voucher'
*/
voucherForm.head = (args: { expense: string | number } | [expense: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

voucher.form = voucherForm

const ExpensesController = { indexCrud, createCrud, storeCrud, showCrud, editCrud, updateCrud, destroyCrud, index, store, show, edit, update, destroy, reports, voucher }

export default ExpensesController