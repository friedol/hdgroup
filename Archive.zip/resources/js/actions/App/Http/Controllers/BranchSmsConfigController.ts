import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\BranchSmsConfigController::show
* @see app/Http/Controllers/BranchSmsConfigController.php:15
* @route '/settings/sms-config/{branchId}'
*/
export const show = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/settings/sms-config/{branchId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BranchSmsConfigController::show
* @see app/Http/Controllers/BranchSmsConfigController.php:15
* @route '/settings/sms-config/{branchId}'
*/
show.url = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { branchId: args }
    }

    if (Array.isArray(args)) {
        args = {
            branchId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        branchId: args.branchId,
    }

    return show.definition.url
            .replace('{branchId}', parsedArgs.branchId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BranchSmsConfigController::show
* @see app/Http/Controllers/BranchSmsConfigController.php:15
* @route '/settings/sms-config/{branchId}'
*/
show.get = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BranchSmsConfigController::show
* @see app/Http/Controllers/BranchSmsConfigController.php:15
* @route '/settings/sms-config/{branchId}'
*/
show.head = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BranchSmsConfigController::show
* @see app/Http/Controllers/BranchSmsConfigController.php:15
* @route '/settings/sms-config/{branchId}'
*/
const showForm = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BranchSmsConfigController::show
* @see app/Http/Controllers/BranchSmsConfigController.php:15
* @route '/settings/sms-config/{branchId}'
*/
showForm.get = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BranchSmsConfigController::show
* @see app/Http/Controllers/BranchSmsConfigController.php:15
* @route '/settings/sms-config/{branchId}'
*/
showForm.head = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\BranchSmsConfigController::store
* @see app/Http/Controllers/BranchSmsConfigController.php:27
* @route '/settings/sms-config/{branchId}'
*/
export const store = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/sms-config/{branchId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BranchSmsConfigController::store
* @see app/Http/Controllers/BranchSmsConfigController.php:27
* @route '/settings/sms-config/{branchId}'
*/
store.url = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { branchId: args }
    }

    if (Array.isArray(args)) {
        args = {
            branchId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        branchId: args.branchId,
    }

    return store.definition.url
            .replace('{branchId}', parsedArgs.branchId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BranchSmsConfigController::store
* @see app/Http/Controllers/BranchSmsConfigController.php:27
* @route '/settings/sms-config/{branchId}'
*/
store.post = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BranchSmsConfigController::store
* @see app/Http/Controllers/BranchSmsConfigController.php:27
* @route '/settings/sms-config/{branchId}'
*/
const storeForm = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BranchSmsConfigController::store
* @see app/Http/Controllers/BranchSmsConfigController.php:27
* @route '/settings/sms-config/{branchId}'
*/
storeForm.post = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\BranchSmsConfigController::test
* @see app/Http/Controllers/BranchSmsConfigController.php:58
* @route '/settings/sms-config/{branchId}/test'
*/
export const test = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(args, options),
    method: 'post',
})

test.definition = {
    methods: ["post"],
    url: '/settings/sms-config/{branchId}/test',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BranchSmsConfigController::test
* @see app/Http/Controllers/BranchSmsConfigController.php:58
* @route '/settings/sms-config/{branchId}/test'
*/
test.url = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { branchId: args }
    }

    if (Array.isArray(args)) {
        args = {
            branchId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        branchId: args.branchId,
    }

    return test.definition.url
            .replace('{branchId}', parsedArgs.branchId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BranchSmsConfigController::test
* @see app/Http/Controllers/BranchSmsConfigController.php:58
* @route '/settings/sms-config/{branchId}/test'
*/
test.post = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BranchSmsConfigController::test
* @see app/Http/Controllers/BranchSmsConfigController.php:58
* @route '/settings/sms-config/{branchId}/test'
*/
const testForm = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: test.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\BranchSmsConfigController::test
* @see app/Http/Controllers/BranchSmsConfigController.php:58
* @route '/settings/sms-config/{branchId}/test'
*/
testForm.post = (args: { branchId: string | number } | [branchId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: test.url(args, options),
    method: 'post',
})

test.form = testForm

const BranchSmsConfigController = { show, store, test }

export default BranchSmsConfigController