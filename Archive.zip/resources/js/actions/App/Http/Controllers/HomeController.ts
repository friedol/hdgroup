import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\HomeController::home_page
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
export const home_page = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home_page.url(options),
    method: 'get',
})

home_page.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::home_page
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
home_page.url = (options?: RouteQueryOptions) => {
    return home_page.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::home_page
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
home_page.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home_page.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::home_page
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
home_page.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home_page.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::home_page
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
const home_pageForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home_page.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::home_page
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
home_pageForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home_page.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::home_page
* @see app/Http/Controllers/HomeController.php:124
* @route '/'
*/
home_pageForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home_page.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

home_page.form = home_pageForm

/**
* @see \App\Http\Controllers\HomeController::category
* @see app/Http/Controllers/HomeController.php:305
* @route '/all/category'
*/
export const category = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: category.url(options),
    method: 'get',
})

category.definition = {
    methods: ["get","head"],
    url: '/all/category',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::category
* @see app/Http/Controllers/HomeController.php:305
* @route '/all/category'
*/
category.url = (options?: RouteQueryOptions) => {
    return category.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::category
* @see app/Http/Controllers/HomeController.php:305
* @route '/all/category'
*/
category.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: category.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::category
* @see app/Http/Controllers/HomeController.php:305
* @route '/all/category'
*/
category.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: category.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::category
* @see app/Http/Controllers/HomeController.php:305
* @route '/all/category'
*/
const categoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: category.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::category
* @see app/Http/Controllers/HomeController.php:305
* @route '/all/category'
*/
categoryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: category.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::category
* @see app/Http/Controllers/HomeController.php:305
* @route '/all/category'
*/
categoryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: category.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

category.form = categoryForm

/**
* @see \App\Http\Controllers\HomeController::filter_product
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
export const filter_product = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filter_product.url(args, options),
    method: 'get',
})

filter_product.definition = {
    methods: ["get","head"],
    url: '/category/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::filter_product
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
filter_product.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return filter_product.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::filter_product
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
filter_product.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filter_product.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::filter_product
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
filter_product.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: filter_product.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::filter_product
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
const filter_productForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter_product.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::filter_product
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
filter_productForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter_product.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::filter_product
* @see app/Http/Controllers/HomeController.php:266
* @route '/category/{id}'
*/
filter_productForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter_product.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

filter_product.form = filter_productForm

/**
* @see \App\Http\Controllers\HomeController::help_desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
export const help_desk = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: help_desk.url(options),
    method: 'get',
})

help_desk.definition = {
    methods: ["get","head"],
    url: '/help/desk',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::help_desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
help_desk.url = (options?: RouteQueryOptions) => {
    return help_desk.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::help_desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
help_desk.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: help_desk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::help_desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
help_desk.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: help_desk.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::help_desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
const help_deskForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: help_desk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::help_desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
help_deskForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: help_desk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::help_desk
* @see app/Http/Controllers/HomeController.php:54
* @route '/help/desk'
*/
help_deskForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: help_desk.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

help_desk.form = help_deskForm

/**
* @see \App\Http\Controllers\HomeController::saveFeedback
* @see app/Http/Controllers/HomeController.php:94
* @route '/help/desk/save'
*/
export const saveFeedback = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveFeedback.url(options),
    method: 'post',
})

saveFeedback.definition = {
    methods: ["post"],
    url: '/help/desk/save',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HomeController::saveFeedback
* @see app/Http/Controllers/HomeController.php:94
* @route '/help/desk/save'
*/
saveFeedback.url = (options?: RouteQueryOptions) => {
    return saveFeedback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::saveFeedback
* @see app/Http/Controllers/HomeController.php:94
* @route '/help/desk/save'
*/
saveFeedback.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveFeedback.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HomeController::saveFeedback
* @see app/Http/Controllers/HomeController.php:94
* @route '/help/desk/save'
*/
const saveFeedbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: saveFeedback.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HomeController::saveFeedback
* @see app/Http/Controllers/HomeController.php:94
* @route '/help/desk/save'
*/
saveFeedbackForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: saveFeedback.url(options),
    method: 'post',
})

saveFeedback.form = saveFeedbackForm

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
export const about = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})

about.definition = {
    methods: ["get","head"],
    url: '/about',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
about.url = (options?: RouteQueryOptions) => {
    return about.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
about.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
about.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: about.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
const aboutForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: about.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
aboutForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: about.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::about
* @see app/Http/Controllers/HomeController.php:59
* @route '/about'
*/
aboutForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: about.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

about.form = aboutForm

/**
* @see \App\Http\Controllers\HomeController::searchProduct
* @see app/Http/Controllers/HomeController.php:194
* @route '/product/find'
*/
export const searchProduct = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchProduct.url(options),
    method: 'get',
})

searchProduct.definition = {
    methods: ["get","head"],
    url: '/product/find',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::searchProduct
* @see app/Http/Controllers/HomeController.php:194
* @route '/product/find'
*/
searchProduct.url = (options?: RouteQueryOptions) => {
    return searchProduct.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::searchProduct
* @see app/Http/Controllers/HomeController.php:194
* @route '/product/find'
*/
searchProduct.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchProduct.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::searchProduct
* @see app/Http/Controllers/HomeController.php:194
* @route '/product/find'
*/
searchProduct.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: searchProduct.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::searchProduct
* @see app/Http/Controllers/HomeController.php:194
* @route '/product/find'
*/
const searchProductForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchProduct.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::searchProduct
* @see app/Http/Controllers/HomeController.php:194
* @route '/product/find'
*/
searchProductForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchProduct.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::searchProduct
* @see app/Http/Controllers/HomeController.php:194
* @route '/product/find'
*/
searchProductForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: searchProduct.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

searchProduct.form = searchProductForm

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
export const contact = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})

contact.definition = {
    methods: ["get","head"],
    url: '/contact',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
contact.url = (options?: RouteQueryOptions) => {
    return contact.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
contact.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
contact.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contact.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
const contactForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: contact.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
contactForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: contact.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::contact
* @see app/Http/Controllers/HomeController.php:64
* @route '/contact'
*/
contactForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: contact.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

contact.form = contactForm

/**
* @see \App\Http\Controllers\HomeController::submitContact
* @see app/Http/Controllers/HomeController.php:105
* @route '/contact/message'
*/
export const submitContact = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitContact.url(options),
    method: 'post',
})

submitContact.definition = {
    methods: ["post"],
    url: '/contact/message',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HomeController::submitContact
* @see app/Http/Controllers/HomeController.php:105
* @route '/contact/message'
*/
submitContact.url = (options?: RouteQueryOptions) => {
    return submitContact.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::submitContact
* @see app/Http/Controllers/HomeController.php:105
* @route '/contact/message'
*/
submitContact.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitContact.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HomeController::submitContact
* @see app/Http/Controllers/HomeController.php:105
* @route '/contact/message'
*/
const submitContactForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitContact.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HomeController::submitContact
* @see app/Http/Controllers/HomeController.php:105
* @route '/contact/message'
*/
submitContactForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitContact.url(options),
    method: 'post',
})

submitContact.form = submitContactForm

/**
* @see \App\Http\Controllers\HomeController::all_products
* @see app/Http/Controllers/HomeController.php:369
* @route '/shop/products'
*/
export const all_products = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all_products.url(options),
    method: 'get',
})

all_products.definition = {
    methods: ["get","head"],
    url: '/shop/products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::all_products
* @see app/Http/Controllers/HomeController.php:369
* @route '/shop/products'
*/
all_products.url = (options?: RouteQueryOptions) => {
    return all_products.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::all_products
* @see app/Http/Controllers/HomeController.php:369
* @route '/shop/products'
*/
all_products.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all_products.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::all_products
* @see app/Http/Controllers/HomeController.php:369
* @route '/shop/products'
*/
all_products.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: all_products.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::all_products
* @see app/Http/Controllers/HomeController.php:369
* @route '/shop/products'
*/
const all_productsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: all_products.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::all_products
* @see app/Http/Controllers/HomeController.php:369
* @route '/shop/products'
*/
all_productsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: all_products.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::all_products
* @see app/Http/Controllers/HomeController.php:369
* @route '/shop/products'
*/
all_productsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: all_products.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

all_products.form = all_productsForm

/**
* @see \App\Http\Controllers\HomeController::categories_page
* @see app/Http/Controllers/HomeController.php:398
* @route '/shop/categories'
*/
export const categories_page = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories_page.url(options),
    method: 'get',
})

categories_page.definition = {
    methods: ["get","head"],
    url: '/shop/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::categories_page
* @see app/Http/Controllers/HomeController.php:398
* @route '/shop/categories'
*/
categories_page.url = (options?: RouteQueryOptions) => {
    return categories_page.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::categories_page
* @see app/Http/Controllers/HomeController.php:398
* @route '/shop/categories'
*/
categories_page.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories_page.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::categories_page
* @see app/Http/Controllers/HomeController.php:398
* @route '/shop/categories'
*/
categories_page.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: categories_page.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::categories_page
* @see app/Http/Controllers/HomeController.php:398
* @route '/shop/categories'
*/
const categories_pageForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: categories_page.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::categories_page
* @see app/Http/Controllers/HomeController.php:398
* @route '/shop/categories'
*/
categories_pageForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: categories_page.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::categories_page
* @see app/Http/Controllers/HomeController.php:398
* @route '/shop/categories'
*/
categories_pageForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: categories_page.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

categories_page.form = categories_pageForm

const HomeController = { home_page, category, filter_product, help_desk, saveFeedback, about, searchProduct, contact, submitContact, all_products, categories_page }

export default HomeController