import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\HumanResourceController::payrollDashboard
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
export const payrollDashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payrollDashboard.url(options),
    method: 'get',
})

payrollDashboard.definition = {
    methods: ["get","head"],
    url: '/hr/payroll',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HumanResourceController::payrollDashboard
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
payrollDashboard.url = (options?: RouteQueryOptions) => {
    return payrollDashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HumanResourceController::payrollDashboard
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
payrollDashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payrollDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::payrollDashboard
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
payrollDashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: payrollDashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HumanResourceController::payrollDashboard
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
const payrollDashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payrollDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::payrollDashboard
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
payrollDashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payrollDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::payrollDashboard
* @see app/Http/Controllers/HumanResourceController.php:12
* @route '/hr/payroll'
*/
payrollDashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payrollDashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

payrollDashboard.form = payrollDashboardForm

/**
* @see \App\Http\Controllers\HumanResourceController::getPayrollSummary
* @see app/Http/Controllers/HumanResourceController.php:17
* @route '/hr/payroll/summary'
*/
export const getPayrollSummary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPayrollSummary.url(options),
    method: 'get',
})

getPayrollSummary.definition = {
    methods: ["get","head"],
    url: '/hr/payroll/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HumanResourceController::getPayrollSummary
* @see app/Http/Controllers/HumanResourceController.php:17
* @route '/hr/payroll/summary'
*/
getPayrollSummary.url = (options?: RouteQueryOptions) => {
    return getPayrollSummary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HumanResourceController::getPayrollSummary
* @see app/Http/Controllers/HumanResourceController.php:17
* @route '/hr/payroll/summary'
*/
getPayrollSummary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPayrollSummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::getPayrollSummary
* @see app/Http/Controllers/HumanResourceController.php:17
* @route '/hr/payroll/summary'
*/
getPayrollSummary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getPayrollSummary.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HumanResourceController::getPayrollSummary
* @see app/Http/Controllers/HumanResourceController.php:17
* @route '/hr/payroll/summary'
*/
const getPayrollSummaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPayrollSummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::getPayrollSummary
* @see app/Http/Controllers/HumanResourceController.php:17
* @route '/hr/payroll/summary'
*/
getPayrollSummaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPayrollSummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::getPayrollSummary
* @see app/Http/Controllers/HumanResourceController.php:17
* @route '/hr/payroll/summary'
*/
getPayrollSummaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPayrollSummary.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getPayrollSummary.form = getPayrollSummaryForm

/**
* @see \App\Http\Controllers\HumanResourceController::getStaffList
* @see app/Http/Controllers/HumanResourceController.php:79
* @route '/hr/payroll/list'
*/
export const getStaffList = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStaffList.url(options),
    method: 'get',
})

getStaffList.definition = {
    methods: ["get","head"],
    url: '/hr/payroll/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HumanResourceController::getStaffList
* @see app/Http/Controllers/HumanResourceController.php:79
* @route '/hr/payroll/list'
*/
getStaffList.url = (options?: RouteQueryOptions) => {
    return getStaffList.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HumanResourceController::getStaffList
* @see app/Http/Controllers/HumanResourceController.php:79
* @route '/hr/payroll/list'
*/
getStaffList.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStaffList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::getStaffList
* @see app/Http/Controllers/HumanResourceController.php:79
* @route '/hr/payroll/list'
*/
getStaffList.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getStaffList.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HumanResourceController::getStaffList
* @see app/Http/Controllers/HumanResourceController.php:79
* @route '/hr/payroll/list'
*/
const getStaffListForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getStaffList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::getStaffList
* @see app/Http/Controllers/HumanResourceController.php:79
* @route '/hr/payroll/list'
*/
getStaffListForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getStaffList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HumanResourceController::getStaffList
* @see app/Http/Controllers/HumanResourceController.php:79
* @route '/hr/payroll/list'
*/
getStaffListForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getStaffList.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getStaffList.form = getStaffListForm

/**
* @see \App\Http\Controllers\HumanResourceController::processPayout
* @see app/Http/Controllers/HumanResourceController.php:100
* @route '/hr/payroll/process'
*/
export const processPayout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: processPayout.url(options),
    method: 'post',
})

processPayout.definition = {
    methods: ["post"],
    url: '/hr/payroll/process',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HumanResourceController::processPayout
* @see app/Http/Controllers/HumanResourceController.php:100
* @route '/hr/payroll/process'
*/
processPayout.url = (options?: RouteQueryOptions) => {
    return processPayout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HumanResourceController::processPayout
* @see app/Http/Controllers/HumanResourceController.php:100
* @route '/hr/payroll/process'
*/
processPayout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: processPayout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HumanResourceController::processPayout
* @see app/Http/Controllers/HumanResourceController.php:100
* @route '/hr/payroll/process'
*/
const processPayoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: processPayout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HumanResourceController::processPayout
* @see app/Http/Controllers/HumanResourceController.php:100
* @route '/hr/payroll/process'
*/
processPayoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: processPayout.url(options),
    method: 'post',
})

processPayout.form = processPayoutForm

/**
* @see \App\Http\Controllers\HumanResourceController::updateSalary
* @see app/Http/Controllers/HumanResourceController.php:158
* @route '/hr/staff/{id}/update-salary'
*/
export const updateSalary = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSalary.url(args, options),
    method: 'post',
})

updateSalary.definition = {
    methods: ["post"],
    url: '/hr/staff/{id}/update-salary',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HumanResourceController::updateSalary
* @see app/Http/Controllers/HumanResourceController.php:158
* @route '/hr/staff/{id}/update-salary'
*/
updateSalary.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateSalary.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HumanResourceController::updateSalary
* @see app/Http/Controllers/HumanResourceController.php:158
* @route '/hr/staff/{id}/update-salary'
*/
updateSalary.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSalary.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HumanResourceController::updateSalary
* @see app/Http/Controllers/HumanResourceController.php:158
* @route '/hr/staff/{id}/update-salary'
*/
const updateSalaryForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateSalary.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HumanResourceController::updateSalary
* @see app/Http/Controllers/HumanResourceController.php:158
* @route '/hr/staff/{id}/update-salary'
*/
updateSalaryForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateSalary.url(args, options),
    method: 'post',
})

updateSalary.form = updateSalaryForm

const HumanResourceController = { payrollDashboard, getPayrollSummary, getStaffList, processPayout, updateSalary }

export default HumanResourceController