import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
export const register = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

register.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
register.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
register.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: register.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
registerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::register
* @see app/Http/Controllers/ProfileController.php:22
* @route '/register'
*/
registerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

register.form = registerForm

/**
* @see \App\Http\Controllers\ProfileController::store_accounts
* @see app/Http/Controllers/ProfileController.php:27
* @route '/create-account'
*/
export const store_accounts = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store_accounts.url(options),
    method: 'post',
})

store_accounts.definition = {
    methods: ["post"],
    url: '/create-account',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProfileController::store_accounts
* @see app/Http/Controllers/ProfileController.php:27
* @route '/create-account'
*/
store_accounts.url = (options?: RouteQueryOptions) => {
    return store_accounts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::store_accounts
* @see app/Http/Controllers/ProfileController.php:27
* @route '/create-account'
*/
store_accounts.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store_accounts.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::store_accounts
* @see app/Http/Controllers/ProfileController.php:27
* @route '/create-account'
*/
const store_accountsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store_accounts.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::store_accounts
* @see app/Http/Controllers/ProfileController.php:27
* @route '/create-account'
*/
store_accountsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store_accounts.url(options),
    method: 'post',
})

store_accounts.form = store_accountsForm

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
export const profile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

profile.definition = {
    methods: ["get","head"],
    url: '/profile/show',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
profile.url = (options?: RouteQueryOptions) => {
    return profile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
profile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
profile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profile.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
const profileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
profileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::profile
* @see app/Http/Controllers/ProfileController.php:50
* @route '/profile/show'
*/
profileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

profile.form = profileForm

/**
* @see \App\Http\Controllers\ProfileController::changepasswordPanel
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
export const changepasswordPanel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: changepasswordPanel.url(options),
    method: 'get',
})

changepasswordPanel.definition = {
    methods: ["get","head"],
    url: '/profile/change_password',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::changepasswordPanel
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
changepasswordPanel.url = (options?: RouteQueryOptions) => {
    return changepasswordPanel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::changepasswordPanel
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
changepasswordPanel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: changepasswordPanel.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::changepasswordPanel
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
changepasswordPanel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: changepasswordPanel.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::changepasswordPanel
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
const changepasswordPanelForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: changepasswordPanel.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::changepasswordPanel
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
changepasswordPanelForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: changepasswordPanel.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::changepasswordPanel
* @see app/Http/Controllers/ProfileController.php:107
* @route '/profile/change_password'
*/
changepasswordPanelForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: changepasswordPanel.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

changepasswordPanel.form = changepasswordPanelForm

/**
* @see \App\Http\Controllers\ProfileController::change_password
* @see app/Http/Controllers/ProfileController.php:111
* @route '/password/change'
*/
export const change_password = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: change_password.url(options),
    method: 'post',
})

change_password.definition = {
    methods: ["post"],
    url: '/password/change',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProfileController::change_password
* @see app/Http/Controllers/ProfileController.php:111
* @route '/password/change'
*/
change_password.url = (options?: RouteQueryOptions) => {
    return change_password.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::change_password
* @see app/Http/Controllers/ProfileController.php:111
* @route '/password/change'
*/
change_password.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: change_password.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::change_password
* @see app/Http/Controllers/ProfileController.php:111
* @route '/password/change'
*/
const change_passwordForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: change_password.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::change_password
* @see app/Http/Controllers/ProfileController.php:111
* @route '/password/change'
*/
change_passwordForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: change_password.url(options),
    method: 'post',
})

change_password.form = change_passwordForm

/**
* @see \App\Http\Controllers\ProfileController::updateProfile
* @see app/Http/Controllers/ProfileController.php:54
* @route '/profile/update'
*/
export const updateProfile = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateProfile.url(options),
    method: 'post',
})

updateProfile.definition = {
    methods: ["post"],
    url: '/profile/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProfileController::updateProfile
* @see app/Http/Controllers/ProfileController.php:54
* @route '/profile/update'
*/
updateProfile.url = (options?: RouteQueryOptions) => {
    return updateProfile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::updateProfile
* @see app/Http/Controllers/ProfileController.php:54
* @route '/profile/update'
*/
updateProfile.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateProfile.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::updateProfile
* @see app/Http/Controllers/ProfileController.php:54
* @route '/profile/update'
*/
const updateProfileForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateProfile.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::updateProfile
* @see app/Http/Controllers/ProfileController.php:54
* @route '/profile/update'
*/
updateProfileForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateProfile.url(options),
    method: 'post',
})

updateProfile.form = updateProfileForm

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::index
* @see app/Http/Controllers/ProfileController.php:17
* @route '/profile'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ProfileController::store
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/profile',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProfileController::store
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::store
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::store
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::store
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
export const show = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/profile/{profile}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
show.url = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { profile: args }
    }

    if (Array.isArray(args)) {
        args = {
            profile: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        profile: args.profile,
    }

    return show.definition.url
            .replace('{profile}', parsedArgs.profile.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
show.get = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
show.head = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
const showForm = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
showForm.get = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::show
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
showForm.head = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
export const edit = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/profile/{profile}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
edit.url = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { profile: args }
    }

    if (Array.isArray(args)) {
        args = {
            profile: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        profile: args.profile,
    }

    return edit.definition.url
            .replace('{profile}', parsedArgs.profile.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
edit.get = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
edit.head = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
const editForm = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
editForm.get = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProfileController::edit
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}/edit'
*/
editForm.head = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
export const update = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/profile/{profile}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
update.url = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { profile: args }
    }

    if (Array.isArray(args)) {
        args = {
            profile: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        profile: args.profile,
    }

    return update.definition.url
            .replace('{profile}', parsedArgs.profile.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
update.put = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
update.patch = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
const updateForm = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
updateForm.put = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::update
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
updateForm.patch = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\ProfileController::destroy
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
export const destroy = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/profile/{profile}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProfileController::destroy
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
destroy.url = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { profile: args }
    }

    if (Array.isArray(args)) {
        args = {
            profile: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        profile: args.profile,
    }

    return destroy.definition.url
            .replace('{profile}', parsedArgs.profile.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProfileController::destroy
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
destroy.delete = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ProfileController::destroy
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
const destroyForm = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProfileController::destroy
* @see app/Http/Controllers/ProfileController.php:0
* @route '/profile/{profile}'
*/
destroyForm.delete = (args: { profile: string | number } | [profile: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const ProfileController = { register, store_accounts, profile, changepasswordPanel, change_password, updateProfile, index, store, show, edit, update, destroy }

export default ProfileController