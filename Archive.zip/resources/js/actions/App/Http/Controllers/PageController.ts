import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PageController::invalidate_users
* @see app/Http/Controllers/PageController.php:993
* @route '/logout'
*/
export const invalidate_users = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invalidate_users.url(options),
    method: 'post',
})

invalidate_users.definition = {
    methods: ["post"],
    url: '/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PageController::invalidate_users
* @see app/Http/Controllers/PageController.php:993
* @route '/logout'
*/
invalidate_users.url = (options?: RouteQueryOptions) => {
    return invalidate_users.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::invalidate_users
* @see app/Http/Controllers/PageController.php:993
* @route '/logout'
*/
invalidate_users.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invalidate_users.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PageController::invalidate_users
* @see app/Http/Controllers/PageController.php:993
* @route '/logout'
*/
const invalidate_usersForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: invalidate_users.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PageController::invalidate_users
* @see app/Http/Controllers/PageController.php:993
* @route '/logout'
*/
invalidate_usersForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: invalidate_users.url(options),
    method: 'post',
})

invalidate_users.form = invalidate_usersForm

/**
* @see \App\Http\Controllers\PageController::index
* @see app/Http/Controllers/PageController.php:31
* @route '/index'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/index',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PageController::index
* @see app/Http/Controllers/PageController.php:31
* @route '/index'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::index
* @see app/Http/Controllers/PageController.php:31
* @route '/index'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::index
* @see app/Http/Controllers/PageController.php:31
* @route '/index'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PageController::index
* @see app/Http/Controllers/PageController.php:31
* @route '/index'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::index
* @see app/Http/Controllers/PageController.php:31
* @route '/index'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::index
* @see app/Http/Controllers/PageController.php:31
* @route '/index'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\PageController::authentication
* @see app/Http/Controllers/PageController.php:877
* @route '/authenticate'
*/
export const authentication = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: authentication.url(options),
    method: 'post',
})

authentication.definition = {
    methods: ["post"],
    url: '/authenticate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PageController::authentication
* @see app/Http/Controllers/PageController.php:877
* @route '/authenticate'
*/
authentication.url = (options?: RouteQueryOptions) => {
    return authentication.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::authentication
* @see app/Http/Controllers/PageController.php:877
* @route '/authenticate'
*/
authentication.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: authentication.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PageController::authentication
* @see app/Http/Controllers/PageController.php:877
* @route '/authenticate'
*/
const authenticationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: authentication.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PageController::authentication
* @see app/Http/Controllers/PageController.php:877
* @route '/authenticate'
*/
authenticationForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: authentication.url(options),
    method: 'post',
})

authentication.form = authenticationForm

/**
* @see \App\Http\Controllers\PageController::reset_password
* @see app/Http/Controllers/PageController.php:1275
* @route '/reset-password'
*/
export const reset_password = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reset_password.url(options),
    method: 'get',
})

reset_password.definition = {
    methods: ["get","head"],
    url: '/reset-password',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PageController::reset_password
* @see app/Http/Controllers/PageController.php:1275
* @route '/reset-password'
*/
reset_password.url = (options?: RouteQueryOptions) => {
    return reset_password.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::reset_password
* @see app/Http/Controllers/PageController.php:1275
* @route '/reset-password'
*/
reset_password.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reset_password.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::reset_password
* @see app/Http/Controllers/PageController.php:1275
* @route '/reset-password'
*/
reset_password.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reset_password.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PageController::reset_password
* @see app/Http/Controllers/PageController.php:1275
* @route '/reset-password'
*/
const reset_passwordForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reset_password.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::reset_password
* @see app/Http/Controllers/PageController.php:1275
* @route '/reset-password'
*/
reset_passwordForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reset_password.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::reset_password
* @see app/Http/Controllers/PageController.php:1275
* @route '/reset-password'
*/
reset_passwordForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reset_password.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

reset_password.form = reset_passwordForm

/**
* @see \App\Http\Controllers\PageController::sales_recommended
* @see app/Http/Controllers/PageController.php:471
* @route '/sales_recommended'
*/
export const sales_recommended = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sales_recommended.url(options),
    method: 'get',
})

sales_recommended.definition = {
    methods: ["get","head"],
    url: '/sales_recommended',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PageController::sales_recommended
* @see app/Http/Controllers/PageController.php:471
* @route '/sales_recommended'
*/
sales_recommended.url = (options?: RouteQueryOptions) => {
    return sales_recommended.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::sales_recommended
* @see app/Http/Controllers/PageController.php:471
* @route '/sales_recommended'
*/
sales_recommended.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sales_recommended.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::sales_recommended
* @see app/Http/Controllers/PageController.php:471
* @route '/sales_recommended'
*/
sales_recommended.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sales_recommended.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PageController::sales_recommended
* @see app/Http/Controllers/PageController.php:471
* @route '/sales_recommended'
*/
const sales_recommendedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sales_recommended.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::sales_recommended
* @see app/Http/Controllers/PageController.php:471
* @route '/sales_recommended'
*/
sales_recommendedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sales_recommended.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::sales_recommended
* @see app/Http/Controllers/PageController.php:471
* @route '/sales_recommended'
*/
sales_recommendedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sales_recommended.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

sales_recommended.form = sales_recommendedForm

/**
* @see \App\Http\Controllers\PageController::order_recommended
* @see app/Http/Controllers/PageController.php:525
* @route '/order_recommended'
*/
export const order_recommended = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_recommended.url(options),
    method: 'get',
})

order_recommended.definition = {
    methods: ["get","head"],
    url: '/order_recommended',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PageController::order_recommended
* @see app/Http/Controllers/PageController.php:525
* @route '/order_recommended'
*/
order_recommended.url = (options?: RouteQueryOptions) => {
    return order_recommended.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::order_recommended
* @see app/Http/Controllers/PageController.php:525
* @route '/order_recommended'
*/
order_recommended.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_recommended.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended
* @see app/Http/Controllers/PageController.php:525
* @route '/order_recommended'
*/
order_recommended.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: order_recommended.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended
* @see app/Http/Controllers/PageController.php:525
* @route '/order_recommended'
*/
const order_recommendedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended
* @see app/Http/Controllers/PageController.php:525
* @route '/order_recommended'
*/
order_recommendedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended
* @see app/Http/Controllers/PageController.php:525
* @route '/order_recommended'
*/
order_recommendedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

order_recommended.form = order_recommendedForm

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
export const order_recommended_edit = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_recommended_edit.url(args, options),
    method: 'get',
})

order_recommended_edit.definition = {
    methods: ["get","head"],
    url: '/order_recommended/{unique_id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
order_recommended_edit.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return order_recommended_edit.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
order_recommended_edit.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_recommended_edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
order_recommended_edit.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: order_recommended_edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
const order_recommended_editForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
order_recommended_editForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_edit
* @see app/Http/Controllers/PageController.php:574
* @route '/order_recommended/{unique_id}/edit'
*/
order_recommended_editForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

order_recommended_edit.form = order_recommended_editForm

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
export const order_recommended_show = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_recommended_show.url(args, options),
    method: 'get',
})

order_recommended_show.definition = {
    methods: ["get","head"],
    url: '/order_recommended/{unique_id}/show',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
order_recommended_show.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return order_recommended_show.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
order_recommended_show.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_recommended_show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
order_recommended_show.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: order_recommended_show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
const order_recommended_showForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
order_recommended_showForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_show
* @see app/Http/Controllers/PageController.php:583
* @route '/order_recommended/{unique_id}/show'
*/
order_recommended_showForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_recommended_show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

order_recommended_show.form = order_recommended_showForm

/**
* @see \App\Http\Controllers\PageController::order_recommended_update
* @see app/Http/Controllers/PageController.php:595
* @route '/order_recommended/{unique_id}/update'
*/
export const order_recommended_update = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: order_recommended_update.url(args, options),
    method: 'put',
})

order_recommended_update.definition = {
    methods: ["put"],
    url: '/order_recommended/{unique_id}/update',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PageController::order_recommended_update
* @see app/Http/Controllers/PageController.php:595
* @route '/order_recommended/{unique_id}/update'
*/
order_recommended_update.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return order_recommended_update.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PageController::order_recommended_update
* @see app/Http/Controllers/PageController.php:595
* @route '/order_recommended/{unique_id}/update'
*/
order_recommended_update.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: order_recommended_update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_update
* @see app/Http/Controllers/PageController.php:595
* @route '/order_recommended/{unique_id}/update'
*/
const order_recommended_updateForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: order_recommended_update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PageController::order_recommended_update
* @see app/Http/Controllers/PageController.php:595
* @route '/order_recommended/{unique_id}/update'
*/
order_recommended_updateForm.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: order_recommended_update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

order_recommended_update.form = order_recommended_updateForm

const PageController = { invalidate_users, index, authentication, reset_password, sales_recommended, order_recommended, order_recommended_edit, order_recommended_show, order_recommended_update }

export default PageController