import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:16
* @route '/smart-reorder'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/smart-reorder',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:16
* @route '/smart-reorder'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:16
* @route '/smart-reorder'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:16
* @route '/smart-reorder'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:16
* @route '/smart-reorder'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:16
* @route '/smart-reorder'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::dashboard
* @see app/Http/Controllers/SmartReorderController.php:16
* @route '/smart-reorder'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\SmartReorderController::getReorderSuggestions
* @see app/Http/Controllers/SmartReorderController.php:21
* @route '/smart-reorder/suggestions'
*/
export const getReorderSuggestions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getReorderSuggestions.url(options),
    method: 'get',
})

getReorderSuggestions.definition = {
    methods: ["get","head"],
    url: '/smart-reorder/suggestions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SmartReorderController::getReorderSuggestions
* @see app/Http/Controllers/SmartReorderController.php:21
* @route '/smart-reorder/suggestions'
*/
getReorderSuggestions.url = (options?: RouteQueryOptions) => {
    return getReorderSuggestions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SmartReorderController::getReorderSuggestions
* @see app/Http/Controllers/SmartReorderController.php:21
* @route '/smart-reorder/suggestions'
*/
getReorderSuggestions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getReorderSuggestions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getReorderSuggestions
* @see app/Http/Controllers/SmartReorderController.php:21
* @route '/smart-reorder/suggestions'
*/
getReorderSuggestions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getReorderSuggestions.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getReorderSuggestions
* @see app/Http/Controllers/SmartReorderController.php:21
* @route '/smart-reorder/suggestions'
*/
const getReorderSuggestionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getReorderSuggestions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getReorderSuggestions
* @see app/Http/Controllers/SmartReorderController.php:21
* @route '/smart-reorder/suggestions'
*/
getReorderSuggestionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getReorderSuggestions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getReorderSuggestions
* @see app/Http/Controllers/SmartReorderController.php:21
* @route '/smart-reorder/suggestions'
*/
getReorderSuggestionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getReorderSuggestions.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getReorderSuggestions.form = getReorderSuggestionsForm

/**
* @see \App\Http\Controllers\SmartReorderController::getMaterialDepletionPredictions
* @see app/Http/Controllers/SmartReorderController.php:33
* @route '/smart-reorder/material-predictions'
*/
export const getMaterialDepletionPredictions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMaterialDepletionPredictions.url(options),
    method: 'get',
})

getMaterialDepletionPredictions.definition = {
    methods: ["get","head"],
    url: '/smart-reorder/material-predictions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SmartReorderController::getMaterialDepletionPredictions
* @see app/Http/Controllers/SmartReorderController.php:33
* @route '/smart-reorder/material-predictions'
*/
getMaterialDepletionPredictions.url = (options?: RouteQueryOptions) => {
    return getMaterialDepletionPredictions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SmartReorderController::getMaterialDepletionPredictions
* @see app/Http/Controllers/SmartReorderController.php:33
* @route '/smart-reorder/material-predictions'
*/
getMaterialDepletionPredictions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMaterialDepletionPredictions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getMaterialDepletionPredictions
* @see app/Http/Controllers/SmartReorderController.php:33
* @route '/smart-reorder/material-predictions'
*/
getMaterialDepletionPredictions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getMaterialDepletionPredictions.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getMaterialDepletionPredictions
* @see app/Http/Controllers/SmartReorderController.php:33
* @route '/smart-reorder/material-predictions'
*/
const getMaterialDepletionPredictionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMaterialDepletionPredictions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getMaterialDepletionPredictions
* @see app/Http/Controllers/SmartReorderController.php:33
* @route '/smart-reorder/material-predictions'
*/
getMaterialDepletionPredictionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMaterialDepletionPredictions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getMaterialDepletionPredictions
* @see app/Http/Controllers/SmartReorderController.php:33
* @route '/smart-reorder/material-predictions'
*/
getMaterialDepletionPredictionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMaterialDepletionPredictions.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getMaterialDepletionPredictions.form = getMaterialDepletionPredictionsForm

/**
* @see \App\Http\Controllers\SmartReorderController::getCriticalShortageAlerts
* @see app/Http/Controllers/SmartReorderController.php:77
* @route '/smart-reorder/critical-alerts'
*/
export const getCriticalShortageAlerts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCriticalShortageAlerts.url(options),
    method: 'get',
})

getCriticalShortageAlerts.definition = {
    methods: ["get","head"],
    url: '/smart-reorder/critical-alerts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SmartReorderController::getCriticalShortageAlerts
* @see app/Http/Controllers/SmartReorderController.php:77
* @route '/smart-reorder/critical-alerts'
*/
getCriticalShortageAlerts.url = (options?: RouteQueryOptions) => {
    return getCriticalShortageAlerts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SmartReorderController::getCriticalShortageAlerts
* @see app/Http/Controllers/SmartReorderController.php:77
* @route '/smart-reorder/critical-alerts'
*/
getCriticalShortageAlerts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCriticalShortageAlerts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getCriticalShortageAlerts
* @see app/Http/Controllers/SmartReorderController.php:77
* @route '/smart-reorder/critical-alerts'
*/
getCriticalShortageAlerts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getCriticalShortageAlerts.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getCriticalShortageAlerts
* @see app/Http/Controllers/SmartReorderController.php:77
* @route '/smart-reorder/critical-alerts'
*/
const getCriticalShortageAlertsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCriticalShortageAlerts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getCriticalShortageAlerts
* @see app/Http/Controllers/SmartReorderController.php:77
* @route '/smart-reorder/critical-alerts'
*/
getCriticalShortageAlertsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCriticalShortageAlerts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getCriticalShortageAlerts
* @see app/Http/Controllers/SmartReorderController.php:77
* @route '/smart-reorder/critical-alerts'
*/
getCriticalShortageAlertsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCriticalShortageAlerts.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getCriticalShortageAlerts.form = getCriticalShortageAlertsForm

/**
* @see \App\Http\Controllers\SmartReorderController::getFinishedGoodsDepletion
* @see app/Http/Controllers/SmartReorderController.php:108
* @route '/smart-reorder/finished-goods'
*/
export const getFinishedGoodsDepletion = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getFinishedGoodsDepletion.url(options),
    method: 'get',
})

getFinishedGoodsDepletion.definition = {
    methods: ["get","head"],
    url: '/smart-reorder/finished-goods',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SmartReorderController::getFinishedGoodsDepletion
* @see app/Http/Controllers/SmartReorderController.php:108
* @route '/smart-reorder/finished-goods'
*/
getFinishedGoodsDepletion.url = (options?: RouteQueryOptions) => {
    return getFinishedGoodsDepletion.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SmartReorderController::getFinishedGoodsDepletion
* @see app/Http/Controllers/SmartReorderController.php:108
* @route '/smart-reorder/finished-goods'
*/
getFinishedGoodsDepletion.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getFinishedGoodsDepletion.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getFinishedGoodsDepletion
* @see app/Http/Controllers/SmartReorderController.php:108
* @route '/smart-reorder/finished-goods'
*/
getFinishedGoodsDepletion.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getFinishedGoodsDepletion.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getFinishedGoodsDepletion
* @see app/Http/Controllers/SmartReorderController.php:108
* @route '/smart-reorder/finished-goods'
*/
const getFinishedGoodsDepletionForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getFinishedGoodsDepletion.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getFinishedGoodsDepletion
* @see app/Http/Controllers/SmartReorderController.php:108
* @route '/smart-reorder/finished-goods'
*/
getFinishedGoodsDepletionForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getFinishedGoodsDepletion.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::getFinishedGoodsDepletion
* @see app/Http/Controllers/SmartReorderController.php:108
* @route '/smart-reorder/finished-goods'
*/
getFinishedGoodsDepletionForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getFinishedGoodsDepletion.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getFinishedGoodsDepletion.form = getFinishedGoodsDepletionForm

/**
* @see \App\Http\Controllers\SmartReorderController::updateReorderSettings
* @see app/Http/Controllers/SmartReorderController.php:139
* @route '/smart-reorder/settings/{productId}'
*/
export const updateReorderSettings = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateReorderSettings.url(args, options),
    method: 'put',
})

updateReorderSettings.definition = {
    methods: ["put"],
    url: '/smart-reorder/settings/{productId}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\SmartReorderController::updateReorderSettings
* @see app/Http/Controllers/SmartReorderController.php:139
* @route '/smart-reorder/settings/{productId}'
*/
updateReorderSettings.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return updateReorderSettings.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SmartReorderController::updateReorderSettings
* @see app/Http/Controllers/SmartReorderController.php:139
* @route '/smart-reorder/settings/{productId}'
*/
updateReorderSettings.put = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateReorderSettings.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\SmartReorderController::updateReorderSettings
* @see app/Http/Controllers/SmartReorderController.php:139
* @route '/smart-reorder/settings/{productId}'
*/
const updateReorderSettingsForm = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateReorderSettings.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SmartReorderController::updateReorderSettings
* @see app/Http/Controllers/SmartReorderController.php:139
* @route '/smart-reorder/settings/{productId}'
*/
updateReorderSettingsForm.put = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateReorderSettings.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateReorderSettings.form = updateReorderSettingsForm

/**
* @see \App\Http\Controllers\SmartReorderController::generatePurchaseOrders
* @see app/Http/Controllers/SmartReorderController.php:168
* @route '/smart-reorder/purchase-orders'
*/
export const generatePurchaseOrders = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: generatePurchaseOrders.url(options),
    method: 'get',
})

generatePurchaseOrders.definition = {
    methods: ["get","head"],
    url: '/smart-reorder/purchase-orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SmartReorderController::generatePurchaseOrders
* @see app/Http/Controllers/SmartReorderController.php:168
* @route '/smart-reorder/purchase-orders'
*/
generatePurchaseOrders.url = (options?: RouteQueryOptions) => {
    return generatePurchaseOrders.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SmartReorderController::generatePurchaseOrders
* @see app/Http/Controllers/SmartReorderController.php:168
* @route '/smart-reorder/purchase-orders'
*/
generatePurchaseOrders.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: generatePurchaseOrders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::generatePurchaseOrders
* @see app/Http/Controllers/SmartReorderController.php:168
* @route '/smart-reorder/purchase-orders'
*/
generatePurchaseOrders.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: generatePurchaseOrders.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SmartReorderController::generatePurchaseOrders
* @see app/Http/Controllers/SmartReorderController.php:168
* @route '/smart-reorder/purchase-orders'
*/
const generatePurchaseOrdersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: generatePurchaseOrders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::generatePurchaseOrders
* @see app/Http/Controllers/SmartReorderController.php:168
* @route '/smart-reorder/purchase-orders'
*/
generatePurchaseOrdersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: generatePurchaseOrders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SmartReorderController::generatePurchaseOrders
* @see app/Http/Controllers/SmartReorderController.php:168
* @route '/smart-reorder/purchase-orders'
*/
generatePurchaseOrdersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: generatePurchaseOrders.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

generatePurchaseOrders.form = generatePurchaseOrdersForm

const SmartReorderController = { dashboard, getReorderSuggestions, getMaterialDepletionPredictions, getCriticalShortageAlerts, getFinishedGoodsDepletion, updateReorderSettings, generatePurchaseOrders }

export default SmartReorderController