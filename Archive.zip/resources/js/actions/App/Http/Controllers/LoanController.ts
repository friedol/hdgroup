import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LoanController::index
* @see app/Http/Controllers/LoanController.php:84
* @route '/loans'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/loans',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::index
* @see app/Http/Controllers/LoanController.php:84
* @route '/loans'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::index
* @see app/Http/Controllers/LoanController.php:84
* @route '/loans'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::index
* @see app/Http/Controllers/LoanController.php:84
* @route '/loans'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LoanController::index
* @see app/Http/Controllers/LoanController.php:84
* @route '/loans'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::index
* @see app/Http/Controllers/LoanController.php:84
* @route '/loans'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::index
* @see app/Http/Controllers/LoanController.php:84
* @route '/loans'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\LoanController::create
* @see app/Http/Controllers/LoanController.php:75
* @route '/loans/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/loans/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::create
* @see app/Http/Controllers/LoanController.php:75
* @route '/loans/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::create
* @see app/Http/Controllers/LoanController.php:75
* @route '/loans/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::create
* @see app/Http/Controllers/LoanController.php:75
* @route '/loans/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LoanController::create
* @see app/Http/Controllers/LoanController.php:75
* @route '/loans/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::create
* @see app/Http/Controllers/LoanController.php:75
* @route '/loans/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::create
* @see app/Http/Controllers/LoanController.php:75
* @route '/loans/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\LoanController::store
* @see app/Http/Controllers/LoanController.php:191
* @route '/loans'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/loans',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LoanController::store
* @see app/Http/Controllers/LoanController.php:191
* @route '/loans'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::store
* @see app/Http/Controllers/LoanController.php:191
* @route '/loans'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::store
* @see app/Http/Controllers/LoanController.php:191
* @route '/loans'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::store
* @see app/Http/Controllers/LoanController.php:191
* @route '/loans'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\LoanController::showCrud
* @see app/Http/Controllers/LoanController.php:573
* @route '/loans/{id}'
*/
export const showCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

showCrud.definition = {
    methods: ["get","head"],
    url: '/loans/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::showCrud
* @see app/Http/Controllers/LoanController.php:573
* @route '/loans/{id}'
*/
showCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return showCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::showCrud
* @see app/Http/Controllers/LoanController.php:573
* @route '/loans/{id}'
*/
showCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::showCrud
* @see app/Http/Controllers/LoanController.php:573
* @route '/loans/{id}'
*/
showCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LoanController::showCrud
* @see app/Http/Controllers/LoanController.php:573
* @route '/loans/{id}'
*/
const showCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::showCrud
* @see app/Http/Controllers/LoanController.php:573
* @route '/loans/{id}'
*/
showCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::showCrud
* @see app/Http/Controllers/LoanController.php:573
* @route '/loans/{id}'
*/
showCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showCrud.form = showCrudForm

/**
* @see \App\Http\Controllers\LoanController::editCrud
* @see app/Http/Controllers/LoanController.php:582
* @route '/loans/{id}/edit'
*/
export const editCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

editCrud.definition = {
    methods: ["get","head"],
    url: '/loans/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::editCrud
* @see app/Http/Controllers/LoanController.php:582
* @route '/loans/{id}/edit'
*/
editCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return editCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::editCrud
* @see app/Http/Controllers/LoanController.php:582
* @route '/loans/{id}/edit'
*/
editCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::editCrud
* @see app/Http/Controllers/LoanController.php:582
* @route '/loans/{id}/edit'
*/
editCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LoanController::editCrud
* @see app/Http/Controllers/LoanController.php:582
* @route '/loans/{id}/edit'
*/
const editCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::editCrud
* @see app/Http/Controllers/LoanController.php:582
* @route '/loans/{id}/edit'
*/
editCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::editCrud
* @see app/Http/Controllers/LoanController.php:582
* @route '/loans/{id}/edit'
*/
editCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editCrud.form = editCrudForm

/**
* @see \App\Http\Controllers\LoanController::updateCrud
* @see app/Http/Controllers/LoanController.php:591
* @route '/loans/{id}'
*/
export const updateCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

updateCrud.definition = {
    methods: ["put"],
    url: '/loans/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LoanController::updateCrud
* @see app/Http/Controllers/LoanController.php:591
* @route '/loans/{id}'
*/
updateCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::updateCrud
* @see app/Http/Controllers/LoanController.php:591
* @route '/loans/{id}'
*/
updateCrud.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\LoanController::updateCrud
* @see app/Http/Controllers/LoanController.php:591
* @route '/loans/{id}'
*/
const updateCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::updateCrud
* @see app/Http/Controllers/LoanController.php:591
* @route '/loans/{id}'
*/
updateCrudForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateCrud.form = updateCrudForm

/**
* @see \App\Http\Controllers\LoanController::destroyCrud
* @see app/Http/Controllers/LoanController.php:610
* @route '/loans/{id}'
*/
export const destroyCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

destroyCrud.definition = {
    methods: ["delete"],
    url: '/loans/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\LoanController::destroyCrud
* @see app/Http/Controllers/LoanController.php:610
* @route '/loans/{id}'
*/
destroyCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroyCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::destroyCrud
* @see app/Http/Controllers/LoanController.php:610
* @route '/loans/{id}'
*/
destroyCrud.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\LoanController::destroyCrud
* @see app/Http/Controllers/LoanController.php:610
* @route '/loans/{id}'
*/
const destroyCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::destroyCrud
* @see app/Http/Controllers/LoanController.php:610
* @route '/loans/{id}'
*/
destroyCrudForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyCrud.form = destroyCrudForm

/**
* @see \App\Http\Controllers\LoanController::show
* @see app/Http/Controllers/LoanController.php:273
* @route '/loans/{loan}'
*/
export const show = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/loans/{loan}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::show
* @see app/Http/Controllers/LoanController.php:273
* @route '/loans/{loan}'
*/
show.url = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan: args }
    }

    if (Array.isArray(args)) {
        args = {
            loan: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        loan: args.loan,
    }

    return show.definition.url
            .replace('{loan}', parsedArgs.loan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::show
* @see app/Http/Controllers/LoanController.php:273
* @route '/loans/{loan}'
*/
show.get = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::show
* @see app/Http/Controllers/LoanController.php:273
* @route '/loans/{loan}'
*/
show.head = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LoanController::show
* @see app/Http/Controllers/LoanController.php:273
* @route '/loans/{loan}'
*/
const showForm = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::show
* @see app/Http/Controllers/LoanController.php:273
* @route '/loans/{loan}'
*/
showForm.get = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::show
* @see app/Http/Controllers/LoanController.php:273
* @route '/loans/{loan}'
*/
showForm.head = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\LoanController::edit
* @see app/Http/Controllers/LoanController.php:430
* @route '/loans/{loan}/edit'
*/
export const edit = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/loans/{loan}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::edit
* @see app/Http/Controllers/LoanController.php:430
* @route '/loans/{loan}/edit'
*/
edit.url = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan: args }
    }

    if (Array.isArray(args)) {
        args = {
            loan: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        loan: args.loan,
    }

    return edit.definition.url
            .replace('{loan}', parsedArgs.loan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::edit
* @see app/Http/Controllers/LoanController.php:430
* @route '/loans/{loan}/edit'
*/
edit.get = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::edit
* @see app/Http/Controllers/LoanController.php:430
* @route '/loans/{loan}/edit'
*/
edit.head = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LoanController::edit
* @see app/Http/Controllers/LoanController.php:430
* @route '/loans/{loan}/edit'
*/
const editForm = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::edit
* @see app/Http/Controllers/LoanController.php:430
* @route '/loans/{loan}/edit'
*/
editForm.get = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::edit
* @see app/Http/Controllers/LoanController.php:430
* @route '/loans/{loan}/edit'
*/
editForm.head = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\LoanController::update
* @see app/Http/Controllers/LoanController.php:495
* @route '/loans/{loan}'
*/
export const update = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/loans/{loan}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\LoanController::update
* @see app/Http/Controllers/LoanController.php:495
* @route '/loans/{loan}'
*/
update.url = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan: args }
    }

    if (Array.isArray(args)) {
        args = {
            loan: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        loan: args.loan,
    }

    return update.definition.url
            .replace('{loan}', parsedArgs.loan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::update
* @see app/Http/Controllers/LoanController.php:495
* @route '/loans/{loan}'
*/
update.put = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\LoanController::update
* @see app/Http/Controllers/LoanController.php:495
* @route '/loans/{loan}'
*/
update.patch = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\LoanController::update
* @see app/Http/Controllers/LoanController.php:495
* @route '/loans/{loan}'
*/
const updateForm = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::update
* @see app/Http/Controllers/LoanController.php:495
* @route '/loans/{loan}'
*/
updateForm.put = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::update
* @see app/Http/Controllers/LoanController.php:495
* @route '/loans/{loan}'
*/
updateForm.patch = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\LoanController::destroy
* @see app/Http/Controllers/LoanController.php:528
* @route '/loans/{loan}'
*/
export const destroy = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/loans/{loan}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\LoanController::destroy
* @see app/Http/Controllers/LoanController.php:528
* @route '/loans/{loan}'
*/
destroy.url = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loan: args }
    }

    if (Array.isArray(args)) {
        args = {
            loan: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        loan: args.loan,
    }

    return destroy.definition.url
            .replace('{loan}', parsedArgs.loan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::destroy
* @see app/Http/Controllers/LoanController.php:528
* @route '/loans/{loan}'
*/
destroy.delete = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\LoanController::destroy
* @see app/Http/Controllers/LoanController.php:528
* @route '/loans/{loan}'
*/
const destroyForm = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::destroy
* @see app/Http/Controllers/LoanController.php:528
* @route '/loans/{loan}'
*/
destroyForm.delete = (args: { loan: string | number } | [loan: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\LoanController::loans_add_more
* @see app/Http/Controllers/LoanController.php:336
* @route '/loans_add_more'
*/
export const loans_add_more = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loans_add_more.url(options),
    method: 'post',
})

loans_add_more.definition = {
    methods: ["post"],
    url: '/loans_add_more',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LoanController::loans_add_more
* @see app/Http/Controllers/LoanController.php:336
* @route '/loans_add_more'
*/
loans_add_more.url = (options?: RouteQueryOptions) => {
    return loans_add_more.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::loans_add_more
* @see app/Http/Controllers/LoanController.php:336
* @route '/loans_add_more'
*/
loans_add_more.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loans_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::loans_add_more
* @see app/Http/Controllers/LoanController.php:336
* @route '/loans_add_more'
*/
const loans_add_moreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loans_add_more.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::loans_add_more
* @see app/Http/Controllers/LoanController.php:336
* @route '/loans_add_more'
*/
loans_add_moreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loans_add_more.url(options),
    method: 'post',
})

loans_add_more.form = loans_add_moreForm

/**
* @see \App\Http\Controllers\LoanController::edit_loans_status
* @see app/Http/Controllers/LoanController.php:465
* @route '/loans/editstatus/{unique_id}'
*/
export const edit_loans_status = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: edit_loans_status.url(args, options),
    method: 'put',
})

edit_loans_status.definition = {
    methods: ["put"],
    url: '/loans/editstatus/{unique_id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LoanController::edit_loans_status
* @see app/Http/Controllers/LoanController.php:465
* @route '/loans/editstatus/{unique_id}'
*/
edit_loans_status.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return edit_loans_status.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::edit_loans_status
* @see app/Http/Controllers/LoanController.php:465
* @route '/loans/editstatus/{unique_id}'
*/
edit_loans_status.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: edit_loans_status.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\LoanController::edit_loans_status
* @see app/Http/Controllers/LoanController.php:465
* @route '/loans/editstatus/{unique_id}'
*/
const edit_loans_statusForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: edit_loans_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoanController::edit_loans_status
* @see app/Http/Controllers/LoanController.php:465
* @route '/loans/editstatus/{unique_id}'
*/
edit_loans_statusForm.put = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: edit_loans_status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

edit_loans_status.form = edit_loans_statusForm

/**
* @see \App\Http\Controllers\LoanController::reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
export const reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

reports.definition = {
    methods: ["get","head"],
    url: '/loans_reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
reports.url = (options?: RouteQueryOptions) => {
    return reports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reports.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LoanController::reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
const reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LoanController::reports
* @see app/Http/Controllers/LoanController.php:143
* @route '/loans_reports'
*/
reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

reports.form = reportsForm

const LoanController = { index, create, store, showCrud, editCrud, updateCrud, destroyCrud, show, edit, update, destroy, loans_add_more, edit_loans_status, reports }

export default LoanController