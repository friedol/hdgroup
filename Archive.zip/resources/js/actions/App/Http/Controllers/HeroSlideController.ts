import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\HeroSlideController::index
* @see app/Http/Controllers/HeroSlideController.php:11
* @route '/settings/hero-slides'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/hero-slides',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeroSlideController::index
* @see app/Http/Controllers/HeroSlideController.php:11
* @route '/settings/hero-slides'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeroSlideController::index
* @see app/Http/Controllers/HeroSlideController.php:11
* @route '/settings/hero-slides'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::index
* @see app/Http/Controllers/HeroSlideController.php:11
* @route '/settings/hero-slides'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HeroSlideController::index
* @see app/Http/Controllers/HeroSlideController.php:11
* @route '/settings/hero-slides'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::index
* @see app/Http/Controllers/HeroSlideController.php:11
* @route '/settings/hero-slides'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::index
* @see app/Http/Controllers/HeroSlideController.php:11
* @route '/settings/hero-slides'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\HeroSlideController::create
* @see app/Http/Controllers/HeroSlideController.php:21
* @route '/settings/hero-slides/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/settings/hero-slides/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeroSlideController::create
* @see app/Http/Controllers/HeroSlideController.php:21
* @route '/settings/hero-slides/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeroSlideController::create
* @see app/Http/Controllers/HeroSlideController.php:21
* @route '/settings/hero-slides/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::create
* @see app/Http/Controllers/HeroSlideController.php:21
* @route '/settings/hero-slides/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HeroSlideController::create
* @see app/Http/Controllers/HeroSlideController.php:21
* @route '/settings/hero-slides/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::create
* @see app/Http/Controllers/HeroSlideController.php:21
* @route '/settings/hero-slides/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::create
* @see app/Http/Controllers/HeroSlideController.php:21
* @route '/settings/hero-slides/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\HeroSlideController::store
* @see app/Http/Controllers/HeroSlideController.php:28
* @route '/settings/hero-slides'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/hero-slides',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HeroSlideController::store
* @see app/Http/Controllers/HeroSlideController.php:28
* @route '/settings/hero-slides'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeroSlideController::store
* @see app/Http/Controllers/HeroSlideController.php:28
* @route '/settings/hero-slides'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HeroSlideController::store
* @see app/Http/Controllers/HeroSlideController.php:28
* @route '/settings/hero-slides'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HeroSlideController::store
* @see app/Http/Controllers/HeroSlideController.php:28
* @route '/settings/hero-slides'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\HeroSlideController::updateSortOrder
* @see app/Http/Controllers/HeroSlideController.php:128
* @route '/settings/hero-slides/sort-order'
*/
export const updateSortOrder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSortOrder.url(options),
    method: 'post',
})

updateSortOrder.definition = {
    methods: ["post"],
    url: '/settings/hero-slides/sort-order',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HeroSlideController::updateSortOrder
* @see app/Http/Controllers/HeroSlideController.php:128
* @route '/settings/hero-slides/sort-order'
*/
updateSortOrder.url = (options?: RouteQueryOptions) => {
    return updateSortOrder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeroSlideController::updateSortOrder
* @see app/Http/Controllers/HeroSlideController.php:128
* @route '/settings/hero-slides/sort-order'
*/
updateSortOrder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSortOrder.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HeroSlideController::updateSortOrder
* @see app/Http/Controllers/HeroSlideController.php:128
* @route '/settings/hero-slides/sort-order'
*/
const updateSortOrderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateSortOrder.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HeroSlideController::updateSortOrder
* @see app/Http/Controllers/HeroSlideController.php:128
* @route '/settings/hero-slides/sort-order'
*/
updateSortOrderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateSortOrder.url(options),
    method: 'post',
})

updateSortOrder.form = updateSortOrderForm

/**
* @see \App\Http\Controllers\HeroSlideController::show
* @see app/Http/Controllers/HeroSlideController.php:64
* @route '/settings/hero-slides/{heroSlide}'
*/
export const show = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/settings/hero-slides/{heroSlide}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeroSlideController::show
* @see app/Http/Controllers/HeroSlideController.php:64
* @route '/settings/hero-slides/{heroSlide}'
*/
show.url = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { heroSlide: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { heroSlide: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            heroSlide: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        heroSlide: typeof args.heroSlide === 'object'
        ? args.heroSlide.id
        : args.heroSlide,
    }

    return show.definition.url
            .replace('{heroSlide}', parsedArgs.heroSlide.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeroSlideController::show
* @see app/Http/Controllers/HeroSlideController.php:64
* @route '/settings/hero-slides/{heroSlide}'
*/
show.get = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::show
* @see app/Http/Controllers/HeroSlideController.php:64
* @route '/settings/hero-slides/{heroSlide}'
*/
show.head = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HeroSlideController::show
* @see app/Http/Controllers/HeroSlideController.php:64
* @route '/settings/hero-slides/{heroSlide}'
*/
const showForm = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::show
* @see app/Http/Controllers/HeroSlideController.php:64
* @route '/settings/hero-slides/{heroSlide}'
*/
showForm.get = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::show
* @see app/Http/Controllers/HeroSlideController.php:64
* @route '/settings/hero-slides/{heroSlide}'
*/
showForm.head = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\HeroSlideController::edit
* @see app/Http/Controllers/HeroSlideController.php:72
* @route '/settings/hero-slides/{heroSlide}/edit'
*/
export const edit = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/hero-slides/{heroSlide}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeroSlideController::edit
* @see app/Http/Controllers/HeroSlideController.php:72
* @route '/settings/hero-slides/{heroSlide}/edit'
*/
edit.url = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { heroSlide: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { heroSlide: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            heroSlide: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        heroSlide: typeof args.heroSlide === 'object'
        ? args.heroSlide.id
        : args.heroSlide,
    }

    return edit.definition.url
            .replace('{heroSlide}', parsedArgs.heroSlide.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeroSlideController::edit
* @see app/Http/Controllers/HeroSlideController.php:72
* @route '/settings/hero-slides/{heroSlide}/edit'
*/
edit.get = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::edit
* @see app/Http/Controllers/HeroSlideController.php:72
* @route '/settings/hero-slides/{heroSlide}/edit'
*/
edit.head = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HeroSlideController::edit
* @see app/Http/Controllers/HeroSlideController.php:72
* @route '/settings/hero-slides/{heroSlide}/edit'
*/
const editForm = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::edit
* @see app/Http/Controllers/HeroSlideController.php:72
* @route '/settings/hero-slides/{heroSlide}/edit'
*/
editForm.get = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HeroSlideController::edit
* @see app/Http/Controllers/HeroSlideController.php:72
* @route '/settings/hero-slides/{heroSlide}/edit'
*/
editForm.head = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\HeroSlideController::update
* @see app/Http/Controllers/HeroSlideController.php:80
* @route '/settings/hero-slides/{heroSlide}'
*/
export const update = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/hero-slides/{heroSlide}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\HeroSlideController::update
* @see app/Http/Controllers/HeroSlideController.php:80
* @route '/settings/hero-slides/{heroSlide}'
*/
update.url = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { heroSlide: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { heroSlide: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            heroSlide: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        heroSlide: typeof args.heroSlide === 'object'
        ? args.heroSlide.id
        : args.heroSlide,
    }

    return update.definition.url
            .replace('{heroSlide}', parsedArgs.heroSlide.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeroSlideController::update
* @see app/Http/Controllers/HeroSlideController.php:80
* @route '/settings/hero-slides/{heroSlide}'
*/
update.put = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\HeroSlideController::update
* @see app/Http/Controllers/HeroSlideController.php:80
* @route '/settings/hero-slides/{heroSlide}'
*/
const updateForm = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HeroSlideController::update
* @see app/Http/Controllers/HeroSlideController.php:80
* @route '/settings/hero-slides/{heroSlide}'
*/
updateForm.put = (args: { heroSlide: number | { id: number } } | [heroSlide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\HeroSlideController::destroy
* @see app/Http/Controllers/HeroSlideController.php:114
* @route '/settings/hero-slides/{heroSlide}'
*/
export const destroy = (args: { heroSlide: string | number } | [heroSlide: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/settings/hero-slides/{heroSlide}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\HeroSlideController::destroy
* @see app/Http/Controllers/HeroSlideController.php:114
* @route '/settings/hero-slides/{heroSlide}'
*/
destroy.url = (args: { heroSlide: string | number } | [heroSlide: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { heroSlide: args }
    }

    if (Array.isArray(args)) {
        args = {
            heroSlide: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        heroSlide: args.heroSlide,
    }

    return destroy.definition.url
            .replace('{heroSlide}', parsedArgs.heroSlide.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeroSlideController::destroy
* @see app/Http/Controllers/HeroSlideController.php:114
* @route '/settings/hero-slides/{heroSlide}'
*/
destroy.delete = (args: { heroSlide: string | number } | [heroSlide: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\HeroSlideController::destroy
* @see app/Http/Controllers/HeroSlideController.php:114
* @route '/settings/hero-slides/{heroSlide}'
*/
const destroyForm = (args: { heroSlide: string | number } | [heroSlide: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\HeroSlideController::destroy
* @see app/Http/Controllers/HeroSlideController.php:114
* @route '/settings/hero-slides/{heroSlide}'
*/
destroyForm.delete = (args: { heroSlide: string | number } | [heroSlide: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const HeroSlideController = { index, create, store, updateSortOrder, show, edit, update, destroy }

export default HeroSlideController