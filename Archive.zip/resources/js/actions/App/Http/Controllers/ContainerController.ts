import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ContainerController::indexCrud
* @see app/Http/Controllers/ContainerController.php:32
* @route '/containers-crud'
*/
export const indexCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

indexCrud.definition = {
    methods: ["get","head"],
    url: '/containers-crud',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContainerController::indexCrud
* @see app/Http/Controllers/ContainerController.php:32
* @route '/containers-crud'
*/
indexCrud.url = (options?: RouteQueryOptions) => {
    return indexCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::indexCrud
* @see app/Http/Controllers/ContainerController.php:32
* @route '/containers-crud'
*/
indexCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::indexCrud
* @see app/Http/Controllers/ContainerController.php:32
* @route '/containers-crud'
*/
indexCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ContainerController::indexCrud
* @see app/Http/Controllers/ContainerController.php:32
* @route '/containers-crud'
*/
const indexCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::indexCrud
* @see app/Http/Controllers/ContainerController.php:32
* @route '/containers-crud'
*/
indexCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::indexCrud
* @see app/Http/Controllers/ContainerController.php:32
* @route '/containers-crud'
*/
indexCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexCrud.form = indexCrudForm

/**
* @see \App\Http\Controllers\ContainerController::createCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/create'
*/
export const createCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

createCrud.definition = {
    methods: ["get","head"],
    url: '/containers-crud/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContainerController::createCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/create'
*/
createCrud.url = (options?: RouteQueryOptions) => {
    return createCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::createCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/create'
*/
createCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::createCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/create'
*/
createCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ContainerController::createCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/create'
*/
const createCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::createCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/create'
*/
createCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::createCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/create'
*/
createCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

createCrud.form = createCrudForm

/**
* @see \App\Http\Controllers\ContainerController::storeCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud'
*/
export const storeCrud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

storeCrud.definition = {
    methods: ["post"],
    url: '/containers-crud',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ContainerController::storeCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud'
*/
storeCrud.url = (options?: RouteQueryOptions) => {
    return storeCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::storeCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud'
*/
storeCrud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContainerController::storeCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud'
*/
const storeCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContainerController::storeCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud'
*/
storeCrudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

storeCrud.form = storeCrudForm

/**
* @see \App\Http\Controllers\ContainerController::showCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
export const showCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

showCrud.definition = {
    methods: ["get","head"],
    url: '/containers-crud/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContainerController::showCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
showCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return showCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::showCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
showCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::showCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
showCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ContainerController::showCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
const showCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::showCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
showCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::showCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
showCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showCrud.form = showCrudForm

/**
* @see \App\Http\Controllers\ContainerController::editCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}/edit'
*/
export const editCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

editCrud.definition = {
    methods: ["get","head"],
    url: '/containers-crud/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContainerController::editCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}/edit'
*/
editCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return editCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::editCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}/edit'
*/
editCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::editCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}/edit'
*/
editCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ContainerController::editCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}/edit'
*/
const editCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::editCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}/edit'
*/
editCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::editCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}/edit'
*/
editCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editCrud.form = editCrudForm

/**
* @see \App\Http\Controllers\ContainerController::updateCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
export const updateCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

updateCrud.definition = {
    methods: ["put"],
    url: '/containers-crud/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ContainerController::updateCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
updateCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::updateCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
updateCrud.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ContainerController::updateCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
const updateCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContainerController::updateCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
updateCrudForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateCrud.form = updateCrudForm

/**
* @see \App\Http\Controllers\ContainerController::destroyCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
export const destroyCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

destroyCrud.definition = {
    methods: ["delete"],
    url: '/containers-crud/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ContainerController::destroyCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
destroyCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroyCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::destroyCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
destroyCrud.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ContainerController::destroyCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
const destroyCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContainerController::destroyCrud
* @see app/Http/Controllers/ContainerController.php:0
* @route '/containers-crud/{id}'
*/
destroyCrudForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyCrud.form = destroyCrudForm

/**
* @see \App\Http\Controllers\ContainerController::index
* @see app/Http/Controllers/ContainerController.php:14
* @route '/containers'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/containers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContainerController::index
* @see app/Http/Controllers/ContainerController.php:14
* @route '/containers'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::index
* @see app/Http/Controllers/ContainerController.php:14
* @route '/containers'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::index
* @see app/Http/Controllers/ContainerController.php:14
* @route '/containers'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ContainerController::index
* @see app/Http/Controllers/ContainerController.php:14
* @route '/containers'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::index
* @see app/Http/Controllers/ContainerController.php:14
* @route '/containers'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::index
* @see app/Http/Controllers/ContainerController.php:14
* @route '/containers'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ContainerController::create
* @see app/Http/Controllers/ContainerController.php:43
* @route '/containers/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/containers/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContainerController::create
* @see app/Http/Controllers/ContainerController.php:43
* @route '/containers/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::create
* @see app/Http/Controllers/ContainerController.php:43
* @route '/containers/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::create
* @see app/Http/Controllers/ContainerController.php:43
* @route '/containers/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ContainerController::create
* @see app/Http/Controllers/ContainerController.php:43
* @route '/containers/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::create
* @see app/Http/Controllers/ContainerController.php:43
* @route '/containers/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::create
* @see app/Http/Controllers/ContainerController.php:43
* @route '/containers/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\ContainerController::store
* @see app/Http/Controllers/ContainerController.php:51
* @route '/containers'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/containers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ContainerController::store
* @see app/Http/Controllers/ContainerController.php:51
* @route '/containers'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::store
* @see app/Http/Controllers/ContainerController.php:51
* @route '/containers'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContainerController::store
* @see app/Http/Controllers/ContainerController.php:51
* @route '/containers'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContainerController::store
* @see app/Http/Controllers/ContainerController.php:51
* @route '/containers'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\ContainerController::show
* @see app/Http/Controllers/ContainerController.php:78
* @route '/containers/{container}'
*/
export const show = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/containers/{container}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContainerController::show
* @see app/Http/Controllers/ContainerController.php:78
* @route '/containers/{container}'
*/
show.url = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { container: args }
    }

    if (Array.isArray(args)) {
        args = {
            container: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        container: args.container,
    }

    return show.definition.url
            .replace('{container}', parsedArgs.container.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::show
* @see app/Http/Controllers/ContainerController.php:78
* @route '/containers/{container}'
*/
show.get = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::show
* @see app/Http/Controllers/ContainerController.php:78
* @route '/containers/{container}'
*/
show.head = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ContainerController::show
* @see app/Http/Controllers/ContainerController.php:78
* @route '/containers/{container}'
*/
const showForm = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::show
* @see app/Http/Controllers/ContainerController.php:78
* @route '/containers/{container}'
*/
showForm.get = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::show
* @see app/Http/Controllers/ContainerController.php:78
* @route '/containers/{container}'
*/
showForm.head = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\ContainerController::edit
* @see app/Http/Controllers/ContainerController.php:91
* @route '/containers/{container}/edit'
*/
export const edit = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/containers/{container}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContainerController::edit
* @see app/Http/Controllers/ContainerController.php:91
* @route '/containers/{container}/edit'
*/
edit.url = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { container: args }
    }

    if (Array.isArray(args)) {
        args = {
            container: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        container: args.container,
    }

    return edit.definition.url
            .replace('{container}', parsedArgs.container.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::edit
* @see app/Http/Controllers/ContainerController.php:91
* @route '/containers/{container}/edit'
*/
edit.get = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::edit
* @see app/Http/Controllers/ContainerController.php:91
* @route '/containers/{container}/edit'
*/
edit.head = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ContainerController::edit
* @see app/Http/Controllers/ContainerController.php:91
* @route '/containers/{container}/edit'
*/
const editForm = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::edit
* @see app/Http/Controllers/ContainerController.php:91
* @route '/containers/{container}/edit'
*/
editForm.get = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContainerController::edit
* @see app/Http/Controllers/ContainerController.php:91
* @route '/containers/{container}/edit'
*/
editForm.head = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\ContainerController::update
* @see app/Http/Controllers/ContainerController.php:102
* @route '/containers/{container}'
*/
export const update = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/containers/{container}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ContainerController::update
* @see app/Http/Controllers/ContainerController.php:102
* @route '/containers/{container}'
*/
update.url = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { container: args }
    }

    if (Array.isArray(args)) {
        args = {
            container: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        container: args.container,
    }

    return update.definition.url
            .replace('{container}', parsedArgs.container.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::update
* @see app/Http/Controllers/ContainerController.php:102
* @route '/containers/{container}'
*/
update.put = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ContainerController::update
* @see app/Http/Controllers/ContainerController.php:102
* @route '/containers/{container}'
*/
update.patch = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\ContainerController::update
* @see app/Http/Controllers/ContainerController.php:102
* @route '/containers/{container}'
*/
const updateForm = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContainerController::update
* @see app/Http/Controllers/ContainerController.php:102
* @route '/containers/{container}'
*/
updateForm.put = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContainerController::update
* @see app/Http/Controllers/ContainerController.php:102
* @route '/containers/{container}'
*/
updateForm.patch = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\ContainerController::destroy
* @see app/Http/Controllers/ContainerController.php:130
* @route '/containers/{container}'
*/
export const destroy = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/containers/{container}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ContainerController::destroy
* @see app/Http/Controllers/ContainerController.php:130
* @route '/containers/{container}'
*/
destroy.url = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { container: args }
    }

    if (Array.isArray(args)) {
        args = {
            container: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        container: args.container,
    }

    return destroy.definition.url
            .replace('{container}', parsedArgs.container.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContainerController::destroy
* @see app/Http/Controllers/ContainerController.php:130
* @route '/containers/{container}'
*/
destroy.delete = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ContainerController::destroy
* @see app/Http/Controllers/ContainerController.php:130
* @route '/containers/{container}'
*/
const destroyForm = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContainerController::destroy
* @see app/Http/Controllers/ContainerController.php:130
* @route '/containers/{container}'
*/
destroyForm.delete = (args: { container: string | number } | [container: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const ContainerController = { indexCrud, createCrud, storeCrud, showCrud, editCrud, updateCrud, destroyCrud, index, create, store, show, edit, update, destroy }

export default ContainerController