import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProductionOrderController::indexCrud
* @see app/Http/Controllers/ProductionOrderController.php:195
* @route '/production-orders-new'
*/
export const indexCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

indexCrud.definition = {
    methods: ["get","head"],
    url: '/production-orders-new',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::indexCrud
* @see app/Http/Controllers/ProductionOrderController.php:195
* @route '/production-orders-new'
*/
indexCrud.url = (options?: RouteQueryOptions) => {
    return indexCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::indexCrud
* @see app/Http/Controllers/ProductionOrderController.php:195
* @route '/production-orders-new'
*/
indexCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::indexCrud
* @see app/Http/Controllers/ProductionOrderController.php:195
* @route '/production-orders-new'
*/
indexCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::indexCrud
* @see app/Http/Controllers/ProductionOrderController.php:195
* @route '/production-orders-new'
*/
const indexCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::indexCrud
* @see app/Http/Controllers/ProductionOrderController.php:195
* @route '/production-orders-new'
*/
indexCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::indexCrud
* @see app/Http/Controllers/ProductionOrderController.php:195
* @route '/production-orders-new'
*/
indexCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexCrud.form = indexCrudForm

/**
* @see \App\Http\Controllers\ProductionOrderController::createCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/create'
*/
export const createCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

createCrud.definition = {
    methods: ["get","head"],
    url: '/production-orders-new/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::createCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/create'
*/
createCrud.url = (options?: RouteQueryOptions) => {
    return createCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::createCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/create'
*/
createCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::createCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/create'
*/
createCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::createCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/create'
*/
const createCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::createCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/create'
*/
createCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::createCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/create'
*/
createCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

createCrud.form = createCrudForm

/**
* @see \App\Http\Controllers\ProductionOrderController::storeCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new'
*/
export const storeCrud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

storeCrud.definition = {
    methods: ["post"],
    url: '/production-orders-new',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::storeCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new'
*/
storeCrud.url = (options?: RouteQueryOptions) => {
    return storeCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::storeCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new'
*/
storeCrud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::storeCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new'
*/
const storeCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::storeCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new'
*/
storeCrudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

storeCrud.form = storeCrudForm

/**
* @see \App\Http\Controllers\ProductionOrderController::showCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
export const showCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

showCrud.definition = {
    methods: ["get","head"],
    url: '/production-orders-new/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::showCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
showCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return showCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::showCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
showCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::showCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
showCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::showCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
const showCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::showCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
showCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::showCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
showCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showCrud.form = showCrudForm

/**
* @see \App\Http\Controllers\ProductionOrderController::editCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}/edit'
*/
export const editCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

editCrud.definition = {
    methods: ["get","head"],
    url: '/production-orders-new/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::editCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}/edit'
*/
editCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return editCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::editCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}/edit'
*/
editCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::editCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}/edit'
*/
editCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::editCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}/edit'
*/
const editCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::editCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}/edit'
*/
editCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::editCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}/edit'
*/
editCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editCrud.form = editCrudForm

/**
* @see \App\Http\Controllers\ProductionOrderController::updateCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
export const updateCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

updateCrud.definition = {
    methods: ["put"],
    url: '/production-orders-new/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::updateCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
updateCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::updateCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
updateCrud.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::updateCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
const updateCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::updateCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
updateCrudForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateCrud.form = updateCrudForm

/**
* @see \App\Http\Controllers\ProductionOrderController::destroyCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
export const destroyCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

destroyCrud.definition = {
    methods: ["delete"],
    url: '/production-orders-new/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::destroyCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
destroyCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroyCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::destroyCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
destroyCrud.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::destroyCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
const destroyCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::destroyCrud
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders-new/{id}'
*/
destroyCrudForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyCrud.form = destroyCrudForm

/**
* @see \App\Http\Controllers\ProductionOrderController::rawMaterialHistory
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
export const rawMaterialHistory = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialHistory.url(options),
    method: 'get',
})

rawMaterialHistory.definition = {
    methods: ["get","head"],
    url: '/raw-material-history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::rawMaterialHistory
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
rawMaterialHistory.url = (options?: RouteQueryOptions) => {
    return rawMaterialHistory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::rawMaterialHistory
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
rawMaterialHistory.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rawMaterialHistory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::rawMaterialHistory
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
rawMaterialHistory.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: rawMaterialHistory.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::rawMaterialHistory
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
const rawMaterialHistoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialHistory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::rawMaterialHistory
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
rawMaterialHistoryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialHistory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::rawMaterialHistory
* @see app/Http/Controllers/ProductionOrderController.php:187
* @route '/raw-material-history'
*/
rawMaterialHistoryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rawMaterialHistory.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

rawMaterialHistory.form = rawMaterialHistoryForm

/**
* @see \App\Http\Controllers\ProductionOrderController::show
* @see app/Http/Controllers/ProductionOrderController.php:252
* @route '/production-orders/{id}'
*/
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/production-orders/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::show
* @see app/Http/Controllers/ProductionOrderController.php:252
* @route '/production-orders/{id}'
*/
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::show
* @see app/Http/Controllers/ProductionOrderController.php:252
* @route '/production-orders/{id}'
*/
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::show
* @see app/Http/Controllers/ProductionOrderController.php:252
* @route '/production-orders/{id}'
*/
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::show
* @see app/Http/Controllers/ProductionOrderController.php:252
* @route '/production-orders/{id}'
*/
const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::show
* @see app/Http/Controllers/ProductionOrderController.php:252
* @route '/production-orders/{id}'
*/
showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::show
* @see app/Http/Controllers/ProductionOrderController.php:252
* @route '/production-orders/{id}'
*/
showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\ProductionOrderController::edit
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}/edit'
*/
export const edit = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/production-orders/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::edit
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}/edit'
*/
edit.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return edit.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::edit
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}/edit'
*/
edit.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::edit
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}/edit'
*/
edit.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::edit
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}/edit'
*/
const editForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::edit
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}/edit'
*/
editForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::edit
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}/edit'
*/
editForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\ProductionOrderController::update
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/production-orders/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::update
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::update
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::update
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::update
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\ProductionOrderController::destroy
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/production-orders/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::destroy
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::destroy
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::destroy
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::destroy
* @see app/Http/Controllers/ProductionOrderController.php:0
* @route '/production-orders/{id}'
*/
destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\ProductionOrderController::updateStatus
* @see app/Http/Controllers/ProductionOrderController.php:266
* @route '/production-orders/{id}/status'
*/
export const updateStatus = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStatus.url(args, options),
    method: 'post',
})

updateStatus.definition = {
    methods: ["post"],
    url: '/production-orders/{id}/status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductionOrderController::updateStatus
* @see app/Http/Controllers/ProductionOrderController.php:266
* @route '/production-orders/{id}/status'
*/
updateStatus.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateStatus.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductionOrderController::updateStatus
* @see app/Http/Controllers/ProductionOrderController.php:266
* @route '/production-orders/{id}/status'
*/
updateStatus.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStatus.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::updateStatus
* @see app/Http/Controllers/ProductionOrderController.php:266
* @route '/production-orders/{id}/status'
*/
const updateStatusForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateStatus.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductionOrderController::updateStatus
* @see app/Http/Controllers/ProductionOrderController.php:266
* @route '/production-orders/{id}/status'
*/
updateStatusForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateStatus.url(args, options),
    method: 'post',
})

updateStatus.form = updateStatusForm

const ProductionOrderController = { indexCrud, createCrud, storeCrud, showCrud, editCrud, updateCrud, destroyCrud, rawMaterialHistory, show, edit, update, destroy, updateStatus }

export default ProductionOrderController