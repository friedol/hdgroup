import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults, validateParameters } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
const view_all5d12892da997f6d93277a9b17df5c880 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view_all5d12892da997f6d93277a9b17df5c880.url(options),
    method: 'get',
})

view_all5d12892da997f6d93277a9b17df5c880.definition = {
    methods: ["get","head"],
    url: '/shop',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
view_all5d12892da997f6d93277a9b17df5c880.url = (options?: RouteQueryOptions) => {
    return view_all5d12892da997f6d93277a9b17df5c880.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
view_all5d12892da997f6d93277a9b17df5c880.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view_all5d12892da997f6d93277a9b17df5c880.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
view_all5d12892da997f6d93277a9b17df5c880.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: view_all5d12892da997f6d93277a9b17df5c880.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
const view_all5d12892da997f6d93277a9b17df5c880Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: view_all5d12892da997f6d93277a9b17df5c880.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
view_all5d12892da997f6d93277a9b17df5c880Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: view_all5d12892da997f6d93277a9b17df5c880.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/shop'
*/
view_all5d12892da997f6d93277a9b17df5c880Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: view_all5d12892da997f6d93277a9b17df5c880.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

view_all5d12892da997f6d93277a9b17df5c880.form = view_all5d12892da997f6d93277a9b17df5c880Form
/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
const view_alld215c8ccffdced7bf4cdc79b1a3c85f9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view_alld215c8ccffdced7bf4cdc79b1a3c85f9.url(options),
    method: 'get',
})

view_alld215c8ccffdced7bf4cdc79b1a3c85f9.definition = {
    methods: ["get","head"],
    url: '/product/all',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
view_alld215c8ccffdced7bf4cdc79b1a3c85f9.url = (options?: RouteQueryOptions) => {
    return view_alld215c8ccffdced7bf4cdc79b1a3c85f9.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
view_alld215c8ccffdced7bf4cdc79b1a3c85f9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view_alld215c8ccffdced7bf4cdc79b1a3c85f9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
view_alld215c8ccffdced7bf4cdc79b1a3c85f9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: view_alld215c8ccffdced7bf4cdc79b1a3c85f9.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
const view_alld215c8ccffdced7bf4cdc79b1a3c85f9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: view_alld215c8ccffdced7bf4cdc79b1a3c85f9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
view_alld215c8ccffdced7bf4cdc79b1a3c85f9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: view_alld215c8ccffdced7bf4cdc79b1a3c85f9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::view_all
* @see app/Http/Controllers/CartController.php:27
* @route '/product/all'
*/
view_alld215c8ccffdced7bf4cdc79b1a3c85f9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: view_alld215c8ccffdced7bf4cdc79b1a3c85f9.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

view_alld215c8ccffdced7bf4cdc79b1a3c85f9.form = view_alld215c8ccffdced7bf4cdc79b1a3c85f9Form

export const view_all = {
    '/shop': view_all5d12892da997f6d93277a9b17df5c880,
    '/product/all': view_alld215c8ccffdced7bf4cdc79b1a3c85f9,
}

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
const showCart6e2074bc2918e1f17afed4c7e123a500 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCart6e2074bc2918e1f17afed4c7e123a500.url(options),
    method: 'get',
})

showCart6e2074bc2918e1f17afed4c7e123a500.definition = {
    methods: ["get","head"],
    url: '/cart',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
showCart6e2074bc2918e1f17afed4c7e123a500.url = (options?: RouteQueryOptions) => {
    return showCart6e2074bc2918e1f17afed4c7e123a500.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
showCart6e2074bc2918e1f17afed4c7e123a500.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCart6e2074bc2918e1f17afed4c7e123a500.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
showCart6e2074bc2918e1f17afed4c7e123a500.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showCart6e2074bc2918e1f17afed4c7e123a500.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
const showCart6e2074bc2918e1f17afed4c7e123a500Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCart6e2074bc2918e1f17afed4c7e123a500.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
showCart6e2074bc2918e1f17afed4c7e123a500Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCart6e2074bc2918e1f17afed4c7e123a500.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/cart'
*/
showCart6e2074bc2918e1f17afed4c7e123a500Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCart6e2074bc2918e1f17afed4c7e123a500.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showCart6e2074bc2918e1f17afed4c7e123a500.form = showCart6e2074bc2918e1f17afed4c7e123a500Form
/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/my-carts'
*/
const showCartaa1081a274bf962ffcd92681eaef347c = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCartaa1081a274bf962ffcd92681eaef347c.url(options),
    method: 'get',
})

showCartaa1081a274bf962ffcd92681eaef347c.definition = {
    methods: ["get","head"],
    url: '/my-carts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/my-carts'
*/
showCartaa1081a274bf962ffcd92681eaef347c.url = (options?: RouteQueryOptions) => {
    return showCartaa1081a274bf962ffcd92681eaef347c.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/my-carts'
*/
showCartaa1081a274bf962ffcd92681eaef347c.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCartaa1081a274bf962ffcd92681eaef347c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/my-carts'
*/
showCartaa1081a274bf962ffcd92681eaef347c.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showCartaa1081a274bf962ffcd92681eaef347c.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/my-carts'
*/
const showCartaa1081a274bf962ffcd92681eaef347cForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCartaa1081a274bf962ffcd92681eaef347c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/my-carts'
*/
showCartaa1081a274bf962ffcd92681eaef347cForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCartaa1081a274bf962ffcd92681eaef347c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::showCart
* @see app/Http/Controllers/CartController.php:159
* @route '/my-carts'
*/
showCartaa1081a274bf962ffcd92681eaef347cForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCartaa1081a274bf962ffcd92681eaef347c.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showCartaa1081a274bf962ffcd92681eaef347c.form = showCartaa1081a274bf962ffcd92681eaef347cForm

export const showCart = {
    '/cart': showCart6e2074bc2918e1f17afed4c7e123a500,
    '/my-carts': showCartaa1081a274bf962ffcd92681eaef347c,
}

/**
* @see \App\Http\Controllers\CartController::add
* @see app/Http/Controllers/CartController.php:49
* @route '/cart/add/{productId?}'
*/
export const add = (args?: { productId?: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(args, options),
    method: 'post',
})

add.definition = {
    methods: ["post"],
    url: '/cart/add/{productId?}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::add
* @see app/Http/Controllers/CartController.php:49
* @route '/cart/add/{productId?}'
*/
add.url = (args?: { productId?: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
        "productId",
    ])

    const parsedArgs = {
        productId: args?.productId,
    }

    return add.definition.url
            .replace('{productId?}', parsedArgs.productId?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::add
* @see app/Http/Controllers/CartController.php:49
* @route '/cart/add/{productId?}'
*/
add.post = (args?: { productId?: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::add
* @see app/Http/Controllers/CartController.php:49
* @route '/cart/add/{productId?}'
*/
const addForm = (args?: { productId?: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: add.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::add
* @see app/Http/Controllers/CartController.php:49
* @route '/cart/add/{productId?}'
*/
addForm.post = (args?: { productId?: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: add.url(args, options),
    method: 'post',
})

add.form = addForm

/**
* @see \App\Http\Controllers\CartController::removeFromCart
* @see app/Http/Controllers/CartController.php:164
* @route '/cart/{productId}'
*/
export const removeFromCart = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeFromCart.url(args, options),
    method: 'delete',
})

removeFromCart.definition = {
    methods: ["delete"],
    url: '/cart/{productId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CartController::removeFromCart
* @see app/Http/Controllers/CartController.php:164
* @route '/cart/{productId}'
*/
removeFromCart.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return removeFromCart.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::removeFromCart
* @see app/Http/Controllers/CartController.php:164
* @route '/cart/{productId}'
*/
removeFromCart.delete = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeFromCart.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CartController::removeFromCart
* @see app/Http/Controllers/CartController.php:164
* @route '/cart/{productId}'
*/
const removeFromCartForm = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeFromCart.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::removeFromCart
* @see app/Http/Controllers/CartController.php:164
* @route '/cart/{productId}'
*/
removeFromCartForm.delete = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeFromCart.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

removeFromCart.form = removeFromCartForm

/**
* @see \App\Http\Controllers\CartController::updateCart
* @see app/Http/Controllers/CartController.php:175
* @route '/cart/{id}'
*/
export const updateCart = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCart.url(args, options),
    method: 'put',
})

updateCart.definition = {
    methods: ["put"],
    url: '/cart/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CartController::updateCart
* @see app/Http/Controllers/CartController.php:175
* @route '/cart/{id}'
*/
updateCart.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateCart.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::updateCart
* @see app/Http/Controllers/CartController.php:175
* @route '/cart/{id}'
*/
updateCart.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCart.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\CartController::updateCart
* @see app/Http/Controllers/CartController.php:175
* @route '/cart/{id}'
*/
const updateCartForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCart.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::updateCart
* @see app/Http/Controllers/CartController.php:175
* @route '/cart/{id}'
*/
updateCartForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCart.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateCart.form = updateCartForm

/**
* @see \App\Http\Controllers\CartController::applyPromo
* @see app/Http/Controllers/CartController.php:472
* @route '/cart/promo/apply'
*/
export const applyPromo = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: applyPromo.url(options),
    method: 'post',
})

applyPromo.definition = {
    methods: ["post"],
    url: '/cart/promo/apply',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::applyPromo
* @see app/Http/Controllers/CartController.php:472
* @route '/cart/promo/apply'
*/
applyPromo.url = (options?: RouteQueryOptions) => {
    return applyPromo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::applyPromo
* @see app/Http/Controllers/CartController.php:472
* @route '/cart/promo/apply'
*/
applyPromo.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: applyPromo.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::applyPromo
* @see app/Http/Controllers/CartController.php:472
* @route '/cart/promo/apply'
*/
const applyPromoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: applyPromo.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::applyPromo
* @see app/Http/Controllers/CartController.php:472
* @route '/cart/promo/apply'
*/
applyPromoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: applyPromo.url(options),
    method: 'post',
})

applyPromo.form = applyPromoForm

/**
* @see \App\Http\Controllers\CartController::removePromo
* @see app/Http/Controllers/CartController.php:501
* @route '/cart/promo/remove'
*/
export const removePromo = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: removePromo.url(options),
    method: 'post',
})

removePromo.definition = {
    methods: ["post"],
    url: '/cart/promo/remove',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::removePromo
* @see app/Http/Controllers/CartController.php:501
* @route '/cart/promo/remove'
*/
removePromo.url = (options?: RouteQueryOptions) => {
    return removePromo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::removePromo
* @see app/Http/Controllers/CartController.php:501
* @route '/cart/promo/remove'
*/
removePromo.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: removePromo.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::removePromo
* @see app/Http/Controllers/CartController.php:501
* @route '/cart/promo/remove'
*/
const removePromoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removePromo.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::removePromo
* @see app/Http/Controllers/CartController.php:501
* @route '/cart/promo/remove'
*/
removePromoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removePromo.url(options),
    method: 'post',
})

removePromo.form = removePromoForm

/**
* @see \App\Http\Controllers\CartController::clearCart
* @see app/Http/Controllers/CartController.php:197
* @route '/cart/clear'
*/
export const clearCart = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clearCart.url(options),
    method: 'post',
})

clearCart.definition = {
    methods: ["post"],
    url: '/cart/clear',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::clearCart
* @see app/Http/Controllers/CartController.php:197
* @route '/cart/clear'
*/
clearCart.url = (options?: RouteQueryOptions) => {
    return clearCart.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::clearCart
* @see app/Http/Controllers/CartController.php:197
* @route '/cart/clear'
*/
clearCart.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clearCart.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::clearCart
* @see app/Http/Controllers/CartController.php:197
* @route '/cart/clear'
*/
const clearCartForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clearCart.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::clearCart
* @see app/Http/Controllers/CartController.php:197
* @route '/cart/clear'
*/
clearCartForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clearCart.url(options),
    method: 'post',
})

clearCart.form = clearCartForm

/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:203
* @route '/checkout'
*/
export const checkout = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkout.url(options),
    method: 'get',
})

checkout.definition = {
    methods: ["get","head"],
    url: '/checkout',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:203
* @route '/checkout'
*/
checkout.url = (options?: RouteQueryOptions) => {
    return checkout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:203
* @route '/checkout'
*/
checkout.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkout.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:203
* @route '/checkout'
*/
checkout.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: checkout.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:203
* @route '/checkout'
*/
const checkoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: checkout.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:203
* @route '/checkout'
*/
checkoutForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: checkout.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::checkout
* @see app/Http/Controllers/CartController.php:203
* @route '/checkout'
*/
checkoutForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: checkout.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

checkout.form = checkoutForm

/**
* @see \App\Http\Controllers\CartController::store_checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/store/checkout'
*/
const store_checkoutd986f630879d26a6e90b07933a1f5871 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store_checkoutd986f630879d26a6e90b07933a1f5871.url(options),
    method: 'post',
})

store_checkoutd986f630879d26a6e90b07933a1f5871.definition = {
    methods: ["post"],
    url: '/store/checkout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::store_checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/store/checkout'
*/
store_checkoutd986f630879d26a6e90b07933a1f5871.url = (options?: RouteQueryOptions) => {
    return store_checkoutd986f630879d26a6e90b07933a1f5871.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::store_checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/store/checkout'
*/
store_checkoutd986f630879d26a6e90b07933a1f5871.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store_checkoutd986f630879d26a6e90b07933a1f5871.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::store_checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/store/checkout'
*/
const store_checkoutd986f630879d26a6e90b07933a1f5871Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store_checkoutd986f630879d26a6e90b07933a1f5871.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::store_checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/store/checkout'
*/
store_checkoutd986f630879d26a6e90b07933a1f5871Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store_checkoutd986f630879d26a6e90b07933a1f5871.url(options),
    method: 'post',
})

store_checkoutd986f630879d26a6e90b07933a1f5871.form = store_checkoutd986f630879d26a6e90b07933a1f5871Form
/**
* @see \App\Http\Controllers\CartController::store_checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/checkout/process'
*/
const store_checkout9402fd173d227135a00ac448b707d23a = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store_checkout9402fd173d227135a00ac448b707d23a.url(options),
    method: 'post',
})

store_checkout9402fd173d227135a00ac448b707d23a.definition = {
    methods: ["post"],
    url: '/checkout/process',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::store_checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/checkout/process'
*/
store_checkout9402fd173d227135a00ac448b707d23a.url = (options?: RouteQueryOptions) => {
    return store_checkout9402fd173d227135a00ac448b707d23a.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::store_checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/checkout/process'
*/
store_checkout9402fd173d227135a00ac448b707d23a.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store_checkout9402fd173d227135a00ac448b707d23a.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::store_checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/checkout/process'
*/
const store_checkout9402fd173d227135a00ac448b707d23aForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store_checkout9402fd173d227135a00ac448b707d23a.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::store_checkout
* @see app/Http/Controllers/CartController.php:235
* @route '/checkout/process'
*/
store_checkout9402fd173d227135a00ac448b707d23aForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store_checkout9402fd173d227135a00ac448b707d23a.url(options),
    method: 'post',
})

store_checkout9402fd173d227135a00ac448b707d23a.form = store_checkout9402fd173d227135a00ac448b707d23aForm

export const store_checkout = {
    '/store/checkout': store_checkoutd986f630879d26a6e90b07933a1f5871,
    '/checkout/process': store_checkout9402fd173d227135a00ac448b707d23a,
}

/**
* @see \App\Http\Controllers\CartController::order_confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
export const order_confirmation = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_confirmation.url(args, options),
    method: 'get',
})

order_confirmation.definition = {
    methods: ["get","head"],
    url: '/order/confirmation/{unique_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::order_confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
order_confirmation.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return order_confirmation.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::order_confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
order_confirmation.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order_confirmation.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::order_confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
order_confirmation.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: order_confirmation.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::order_confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
const order_confirmationForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_confirmation.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::order_confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
order_confirmationForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_confirmation.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::order_confirmation
* @see app/Http/Controllers/CartController.php:374
* @route '/order/confirmation/{unique_id}'
*/
order_confirmationForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order_confirmation.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

order_confirmation.form = order_confirmationForm

/**
* @see \App\Http\Controllers\CartController::track_order_lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
export const track_order_lookup = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track_order_lookup.url(options),
    method: 'get',
})

track_order_lookup.definition = {
    methods: ["get","head"],
    url: '/order/track',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::track_order_lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
track_order_lookup.url = (options?: RouteQueryOptions) => {
    return track_order_lookup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::track_order_lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
track_order_lookup.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track_order_lookup.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::track_order_lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
track_order_lookup.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: track_order_lookup.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::track_order_lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
const track_order_lookupForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track_order_lookup.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::track_order_lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
track_order_lookupForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track_order_lookup.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::track_order_lookup
* @see app/Http/Controllers/CartController.php:417
* @route '/order/track'
*/
track_order_lookupForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track_order_lookup.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

track_order_lookup.form = track_order_lookupForm

/**
* @see \App\Http\Controllers\CartController::track_order_submit
* @see app/Http/Controllers/CartController.php:424
* @route '/order/track'
*/
export const track_order_submit = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: track_order_submit.url(options),
    method: 'post',
})

track_order_submit.definition = {
    methods: ["post"],
    url: '/order/track',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::track_order_submit
* @see app/Http/Controllers/CartController.php:424
* @route '/order/track'
*/
track_order_submit.url = (options?: RouteQueryOptions) => {
    return track_order_submit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::track_order_submit
* @see app/Http/Controllers/CartController.php:424
* @route '/order/track'
*/
track_order_submit.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: track_order_submit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::track_order_submit
* @see app/Http/Controllers/CartController.php:424
* @route '/order/track'
*/
const track_order_submitForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: track_order_submit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::track_order_submit
* @see app/Http/Controllers/CartController.php:424
* @route '/order/track'
*/
track_order_submitForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: track_order_submit.url(options),
    method: 'post',
})

track_order_submit.form = track_order_submitForm

/**
* @see \App\Http\Controllers\CartController::track_order
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
export const track_order = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track_order.url(args, options),
    method: 'get',
})

track_order.definition = {
    methods: ["get","head"],
    url: '/order/track/{unique_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::track_order
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
track_order.url = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unique_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            unique_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unique_id: args.unique_id,
    }

    return track_order.definition.url
            .replace('{unique_id}', parsedArgs.unique_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::track_order
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
track_order.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track_order.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::track_order
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
track_order.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: track_order.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::track_order
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
const track_orderForm = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track_order.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::track_order
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
track_orderForm.get = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track_order.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::track_order
* @see app/Http/Controllers/CartController.php:433
* @route '/order/track/{unique_id}'
*/
track_orderForm.head = (args: { unique_id: string | number } | [unique_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: track_order.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

track_order.form = track_orderForm

/**
* @see \App\Http\Controllers\CartController::product_view
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
export const product_view = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product_view.url(args, options),
    method: 'get',
})

product_view.definition = {
    methods: ["get","head"],
    url: '/order-product/{product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::product_view
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
product_view.url = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: args.product,
    }

    return product_view.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::product_view
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
product_view.get = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product_view.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::product_view
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
product_view.head = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: product_view.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::product_view
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
const product_viewForm = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product_view.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::product_view
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
product_viewForm.get = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product_view.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::product_view
* @see app/Http/Controllers/CartController.php:629
* @route '/order-product/{product}'
*/
product_viewForm.head = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product_view.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

product_view.form = product_viewForm

/**
* @see \App\Http\Controllers\CartController::my_orders
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
export const my_orders = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my_orders.url(options),
    method: 'get',
})

my_orders.definition = {
    methods: ["get","head"],
    url: '/order/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::my_orders
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
my_orders.url = (options?: RouteQueryOptions) => {
    return my_orders.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::my_orders
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
my_orders.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my_orders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::my_orders
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
my_orders.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: my_orders.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::my_orders
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
const my_ordersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: my_orders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::my_orders
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
my_ordersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: my_orders.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::my_orders
* @see app/Http/Controllers/CartController.php:674
* @route '/order/history'
*/
my_ordersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: my_orders.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

my_orders.form = my_ordersForm

const CartController = { view_all, showCart, add, removeFromCart, updateCart, applyPromo, removePromo, clearCart, checkout, store_checkout, order_confirmation, track_order_lookup, track_order_submit, track_order, product_view, my_orders }

export default CartController