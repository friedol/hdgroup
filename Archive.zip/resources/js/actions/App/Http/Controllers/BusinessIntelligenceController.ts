import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/analytics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::dashboard
* @see app/Http/Controllers/BusinessIntelligenceController.php:19
* @route '/analytics'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSalesForecast
* @see app/Http/Controllers/BusinessIntelligenceController.php:103
* @route '/analytics/sales-forecast'
*/
export const getSalesForecast = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getSalesForecast.url(options),
    method: 'get',
})

getSalesForecast.definition = {
    methods: ["get","head"],
    url: '/analytics/sales-forecast',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSalesForecast
* @see app/Http/Controllers/BusinessIntelligenceController.php:103
* @route '/analytics/sales-forecast'
*/
getSalesForecast.url = (options?: RouteQueryOptions) => {
    return getSalesForecast.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSalesForecast
* @see app/Http/Controllers/BusinessIntelligenceController.php:103
* @route '/analytics/sales-forecast'
*/
getSalesForecast.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getSalesForecast.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSalesForecast
* @see app/Http/Controllers/BusinessIntelligenceController.php:103
* @route '/analytics/sales-forecast'
*/
getSalesForecast.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getSalesForecast.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSalesForecast
* @see app/Http/Controllers/BusinessIntelligenceController.php:103
* @route '/analytics/sales-forecast'
*/
const getSalesForecastForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getSalesForecast.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSalesForecast
* @see app/Http/Controllers/BusinessIntelligenceController.php:103
* @route '/analytics/sales-forecast'
*/
getSalesForecastForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getSalesForecast.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSalesForecast
* @see app/Http/Controllers/BusinessIntelligenceController.php:103
* @route '/analytics/sales-forecast'
*/
getSalesForecastForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getSalesForecast.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getSalesForecast.form = getSalesForecastForm

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getProductionCostAnalysis
* @see app/Http/Controllers/BusinessIntelligenceController.php:118
* @route '/analytics/production-costs'
*/
export const getProductionCostAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProductionCostAnalysis.url(options),
    method: 'get',
})

getProductionCostAnalysis.definition = {
    methods: ["get","head"],
    url: '/analytics/production-costs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getProductionCostAnalysis
* @see app/Http/Controllers/BusinessIntelligenceController.php:118
* @route '/analytics/production-costs'
*/
getProductionCostAnalysis.url = (options?: RouteQueryOptions) => {
    return getProductionCostAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getProductionCostAnalysis
* @see app/Http/Controllers/BusinessIntelligenceController.php:118
* @route '/analytics/production-costs'
*/
getProductionCostAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProductionCostAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getProductionCostAnalysis
* @see app/Http/Controllers/BusinessIntelligenceController.php:118
* @route '/analytics/production-costs'
*/
getProductionCostAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getProductionCostAnalysis.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getProductionCostAnalysis
* @see app/Http/Controllers/BusinessIntelligenceController.php:118
* @route '/analytics/production-costs'
*/
const getProductionCostAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductionCostAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getProductionCostAnalysis
* @see app/Http/Controllers/BusinessIntelligenceController.php:118
* @route '/analytics/production-costs'
*/
getProductionCostAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductionCostAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getProductionCostAnalysis
* @see app/Http/Controllers/BusinessIntelligenceController.php:118
* @route '/analytics/production-costs'
*/
getProductionCostAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductionCostAnalysis.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getProductionCostAnalysis.form = getProductionCostAnalysisForm

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getBranchPerformanceRanking
* @see app/Http/Controllers/BusinessIntelligenceController.php:137
* @route '/analytics/branch-ranking'
*/
export const getBranchPerformanceRanking = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getBranchPerformanceRanking.url(options),
    method: 'get',
})

getBranchPerformanceRanking.definition = {
    methods: ["get","head"],
    url: '/analytics/branch-ranking',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getBranchPerformanceRanking
* @see app/Http/Controllers/BusinessIntelligenceController.php:137
* @route '/analytics/branch-ranking'
*/
getBranchPerformanceRanking.url = (options?: RouteQueryOptions) => {
    return getBranchPerformanceRanking.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getBranchPerformanceRanking
* @see app/Http/Controllers/BusinessIntelligenceController.php:137
* @route '/analytics/branch-ranking'
*/
getBranchPerformanceRanking.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getBranchPerformanceRanking.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getBranchPerformanceRanking
* @see app/Http/Controllers/BusinessIntelligenceController.php:137
* @route '/analytics/branch-ranking'
*/
getBranchPerformanceRanking.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getBranchPerformanceRanking.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getBranchPerformanceRanking
* @see app/Http/Controllers/BusinessIntelligenceController.php:137
* @route '/analytics/branch-ranking'
*/
const getBranchPerformanceRankingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getBranchPerformanceRanking.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getBranchPerformanceRanking
* @see app/Http/Controllers/BusinessIntelligenceController.php:137
* @route '/analytics/branch-ranking'
*/
getBranchPerformanceRankingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getBranchPerformanceRanking.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getBranchPerformanceRanking
* @see app/Http/Controllers/BusinessIntelligenceController.php:137
* @route '/analytics/branch-ranking'
*/
getBranchPerformanceRankingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getBranchPerformanceRanking.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getBranchPerformanceRanking.form = getBranchPerformanceRankingForm

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getTopMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:162
* @route '/analytics/top-margin-products'
*/
export const getTopMarginProducts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTopMarginProducts.url(options),
    method: 'get',
})

getTopMarginProducts.definition = {
    methods: ["get","head"],
    url: '/analytics/top-margin-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getTopMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:162
* @route '/analytics/top-margin-products'
*/
getTopMarginProducts.url = (options?: RouteQueryOptions) => {
    return getTopMarginProducts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getTopMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:162
* @route '/analytics/top-margin-products'
*/
getTopMarginProducts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTopMarginProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getTopMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:162
* @route '/analytics/top-margin-products'
*/
getTopMarginProducts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTopMarginProducts.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getTopMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:162
* @route '/analytics/top-margin-products'
*/
const getTopMarginProductsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getTopMarginProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getTopMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:162
* @route '/analytics/top-margin-products'
*/
getTopMarginProductsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getTopMarginProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getTopMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:162
* @route '/analytics/top-margin-products'
*/
getTopMarginProductsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getTopMarginProducts.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getTopMarginProducts.form = getTopMarginProductsForm

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getLowMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:187
* @route '/analytics/low-margin-products'
*/
export const getLowMarginProducts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getLowMarginProducts.url(options),
    method: 'get',
})

getLowMarginProducts.definition = {
    methods: ["get","head"],
    url: '/analytics/low-margin-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getLowMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:187
* @route '/analytics/low-margin-products'
*/
getLowMarginProducts.url = (options?: RouteQueryOptions) => {
    return getLowMarginProducts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getLowMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:187
* @route '/analytics/low-margin-products'
*/
getLowMarginProducts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getLowMarginProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getLowMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:187
* @route '/analytics/low-margin-products'
*/
getLowMarginProducts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getLowMarginProducts.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getLowMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:187
* @route '/analytics/low-margin-products'
*/
const getLowMarginProductsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getLowMarginProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getLowMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:187
* @route '/analytics/low-margin-products'
*/
getLowMarginProductsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getLowMarginProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getLowMarginProducts
* @see app/Http/Controllers/BusinessIntelligenceController.php:187
* @route '/analytics/low-margin-products'
*/
getLowMarginProductsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getLowMarginProducts.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getLowMarginProducts.form = getLowMarginProductsForm

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getDeadStockDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:212
* @route '/analytics/dead-stock'
*/
export const getDeadStockDetection = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDeadStockDetection.url(options),
    method: 'get',
})

getDeadStockDetection.definition = {
    methods: ["get","head"],
    url: '/analytics/dead-stock',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getDeadStockDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:212
* @route '/analytics/dead-stock'
*/
getDeadStockDetection.url = (options?: RouteQueryOptions) => {
    return getDeadStockDetection.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getDeadStockDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:212
* @route '/analytics/dead-stock'
*/
getDeadStockDetection.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDeadStockDetection.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getDeadStockDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:212
* @route '/analytics/dead-stock'
*/
getDeadStockDetection.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getDeadStockDetection.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getDeadStockDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:212
* @route '/analytics/dead-stock'
*/
const getDeadStockDetectionForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDeadStockDetection.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getDeadStockDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:212
* @route '/analytics/dead-stock'
*/
getDeadStockDetectionForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDeadStockDetection.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getDeadStockDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:212
* @route '/analytics/dead-stock'
*/
getDeadStockDetectionForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDeadStockDetection.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getDeadStockDetection.form = getDeadStockDetectionForm

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getOverproductionDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:237
* @route '/analytics/overproduction'
*/
export const getOverproductionDetection = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getOverproductionDetection.url(options),
    method: 'get',
})

getOverproductionDetection.definition = {
    methods: ["get","head"],
    url: '/analytics/overproduction',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getOverproductionDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:237
* @route '/analytics/overproduction'
*/
getOverproductionDetection.url = (options?: RouteQueryOptions) => {
    return getOverproductionDetection.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getOverproductionDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:237
* @route '/analytics/overproduction'
*/
getOverproductionDetection.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getOverproductionDetection.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getOverproductionDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:237
* @route '/analytics/overproduction'
*/
getOverproductionDetection.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getOverproductionDetection.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getOverproductionDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:237
* @route '/analytics/overproduction'
*/
const getOverproductionDetectionForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getOverproductionDetection.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getOverproductionDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:237
* @route '/analytics/overproduction'
*/
getOverproductionDetectionForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getOverproductionDetection.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getOverproductionDetection
* @see app/Http/Controllers/BusinessIntelligenceController.php:237
* @route '/analytics/overproduction'
*/
getOverproductionDetectionForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getOverproductionDetection.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getOverproductionDetection.form = getOverproductionDetectionForm

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSeasonalDemandPrediction
* @see app/Http/Controllers/BusinessIntelligenceController.php:261
* @route '/analytics/seasonal-demand'
*/
export const getSeasonalDemandPrediction = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getSeasonalDemandPrediction.url(options),
    method: 'get',
})

getSeasonalDemandPrediction.definition = {
    methods: ["get","head"],
    url: '/analytics/seasonal-demand',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSeasonalDemandPrediction
* @see app/Http/Controllers/BusinessIntelligenceController.php:261
* @route '/analytics/seasonal-demand'
*/
getSeasonalDemandPrediction.url = (options?: RouteQueryOptions) => {
    return getSeasonalDemandPrediction.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSeasonalDemandPrediction
* @see app/Http/Controllers/BusinessIntelligenceController.php:261
* @route '/analytics/seasonal-demand'
*/
getSeasonalDemandPrediction.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getSeasonalDemandPrediction.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSeasonalDemandPrediction
* @see app/Http/Controllers/BusinessIntelligenceController.php:261
* @route '/analytics/seasonal-demand'
*/
getSeasonalDemandPrediction.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getSeasonalDemandPrediction.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSeasonalDemandPrediction
* @see app/Http/Controllers/BusinessIntelligenceController.php:261
* @route '/analytics/seasonal-demand'
*/
const getSeasonalDemandPredictionForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getSeasonalDemandPrediction.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSeasonalDemandPrediction
* @see app/Http/Controllers/BusinessIntelligenceController.php:261
* @route '/analytics/seasonal-demand'
*/
getSeasonalDemandPredictionForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getSeasonalDemandPrediction.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getSeasonalDemandPrediction
* @see app/Http/Controllers/BusinessIntelligenceController.php:261
* @route '/analytics/seasonal-demand'
*/
getSeasonalDemandPredictionForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getSeasonalDemandPrediction.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getSeasonalDemandPrediction.form = getSeasonalDemandPredictionForm

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getAISummary
* @see app/Http/Controllers/BusinessIntelligenceController.php:301
* @route '/analytics/ai-summary'
*/
export const getAISummary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAISummary.url(options),
    method: 'get',
})

getAISummary.definition = {
    methods: ["get","head"],
    url: '/analytics/ai-summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getAISummary
* @see app/Http/Controllers/BusinessIntelligenceController.php:301
* @route '/analytics/ai-summary'
*/
getAISummary.url = (options?: RouteQueryOptions) => {
    return getAISummary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getAISummary
* @see app/Http/Controllers/BusinessIntelligenceController.php:301
* @route '/analytics/ai-summary'
*/
getAISummary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAISummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getAISummary
* @see app/Http/Controllers/BusinessIntelligenceController.php:301
* @route '/analytics/ai-summary'
*/
getAISummary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAISummary.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getAISummary
* @see app/Http/Controllers/BusinessIntelligenceController.php:301
* @route '/analytics/ai-summary'
*/
const getAISummaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAISummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getAISummary
* @see app/Http/Controllers/BusinessIntelligenceController.php:301
* @route '/analytics/ai-summary'
*/
getAISummaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAISummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\BusinessIntelligenceController::getAISummary
* @see app/Http/Controllers/BusinessIntelligenceController.php:301
* @route '/analytics/ai-summary'
*/
getAISummaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAISummary.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getAISummary.form = getAISummaryForm

const BusinessIntelligenceController = { dashboard, getSalesForecast, getProductionCostAnalysis, getBranchPerformanceRanking, getTopMarginProducts, getLowMarginProducts, getDeadStockDetection, getOverproductionDetection, getSeasonalDemandPrediction, getAISummary }

export default BusinessIntelligenceController