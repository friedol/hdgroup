import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\UpcomingProductController::index
* @see app/Http/Controllers/UpcomingProductController.php:29
* @route '/upcoming-products'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/upcoming-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UpcomingProductController::index
* @see app/Http/Controllers/UpcomingProductController.php:29
* @route '/upcoming-products'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingProductController::index
* @see app/Http/Controllers/UpcomingProductController.php:29
* @route '/upcoming-products'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::index
* @see app/Http/Controllers/UpcomingProductController.php:29
* @route '/upcoming-products'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::index
* @see app/Http/Controllers/UpcomingProductController.php:29
* @route '/upcoming-products'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::index
* @see app/Http/Controllers/UpcomingProductController.php:29
* @route '/upcoming-products'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::index
* @see app/Http/Controllers/UpcomingProductController.php:29
* @route '/upcoming-products'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\UpcomingProductController::store
* @see app/Http/Controllers/UpcomingProductController.php:59
* @route '/upcoming-products'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/upcoming-products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UpcomingProductController::store
* @see app/Http/Controllers/UpcomingProductController.php:59
* @route '/upcoming-products'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingProductController::store
* @see app/Http/Controllers/UpcomingProductController.php:59
* @route '/upcoming-products'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::store
* @see app/Http/Controllers/UpcomingProductController.php:59
* @route '/upcoming-products'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::store
* @see app/Http/Controllers/UpcomingProductController.php:59
* @route '/upcoming-products'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\UpcomingProductController::show
* @see app/Http/Controllers/UpcomingProductController.php:0
* @route '/upcoming-products/{upcoming_product}'
*/
export const show = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/upcoming-products/{upcoming_product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UpcomingProductController::show
* @see app/Http/Controllers/UpcomingProductController.php:0
* @route '/upcoming-products/{upcoming_product}'
*/
show.url = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { upcoming_product: args }
    }

    if (Array.isArray(args)) {
        args = {
            upcoming_product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        upcoming_product: args.upcoming_product,
    }

    return show.definition.url
            .replace('{upcoming_product}', parsedArgs.upcoming_product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingProductController::show
* @see app/Http/Controllers/UpcomingProductController.php:0
* @route '/upcoming-products/{upcoming_product}'
*/
show.get = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::show
* @see app/Http/Controllers/UpcomingProductController.php:0
* @route '/upcoming-products/{upcoming_product}'
*/
show.head = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::show
* @see app/Http/Controllers/UpcomingProductController.php:0
* @route '/upcoming-products/{upcoming_product}'
*/
const showForm = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::show
* @see app/Http/Controllers/UpcomingProductController.php:0
* @route '/upcoming-products/{upcoming_product}'
*/
showForm.get = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::show
* @see app/Http/Controllers/UpcomingProductController.php:0
* @route '/upcoming-products/{upcoming_product}'
*/
showForm.head = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\UpcomingProductController::edit
* @see app/Http/Controllers/UpcomingProductController.php:100
* @route '/upcoming-products/{upcoming_product}/edit'
*/
export const edit = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/upcoming-products/{upcoming_product}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UpcomingProductController::edit
* @see app/Http/Controllers/UpcomingProductController.php:100
* @route '/upcoming-products/{upcoming_product}/edit'
*/
edit.url = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { upcoming_product: args }
    }

    if (Array.isArray(args)) {
        args = {
            upcoming_product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        upcoming_product: args.upcoming_product,
    }

    return edit.definition.url
            .replace('{upcoming_product}', parsedArgs.upcoming_product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingProductController::edit
* @see app/Http/Controllers/UpcomingProductController.php:100
* @route '/upcoming-products/{upcoming_product}/edit'
*/
edit.get = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::edit
* @see app/Http/Controllers/UpcomingProductController.php:100
* @route '/upcoming-products/{upcoming_product}/edit'
*/
edit.head = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::edit
* @see app/Http/Controllers/UpcomingProductController.php:100
* @route '/upcoming-products/{upcoming_product}/edit'
*/
const editForm = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::edit
* @see app/Http/Controllers/UpcomingProductController.php:100
* @route '/upcoming-products/{upcoming_product}/edit'
*/
editForm.get = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::edit
* @see app/Http/Controllers/UpcomingProductController.php:100
* @route '/upcoming-products/{upcoming_product}/edit'
*/
editForm.head = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\UpcomingProductController::update
* @see app/Http/Controllers/UpcomingProductController.php:110
* @route '/upcoming-products/{upcoming_product}'
*/
export const update = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/upcoming-products/{upcoming_product}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\UpcomingProductController::update
* @see app/Http/Controllers/UpcomingProductController.php:110
* @route '/upcoming-products/{upcoming_product}'
*/
update.url = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { upcoming_product: args }
    }

    if (Array.isArray(args)) {
        args = {
            upcoming_product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        upcoming_product: args.upcoming_product,
    }

    return update.definition.url
            .replace('{upcoming_product}', parsedArgs.upcoming_product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingProductController::update
* @see app/Http/Controllers/UpcomingProductController.php:110
* @route '/upcoming-products/{upcoming_product}'
*/
update.put = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::update
* @see app/Http/Controllers/UpcomingProductController.php:110
* @route '/upcoming-products/{upcoming_product}'
*/
update.patch = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::update
* @see app/Http/Controllers/UpcomingProductController.php:110
* @route '/upcoming-products/{upcoming_product}'
*/
const updateForm = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::update
* @see app/Http/Controllers/UpcomingProductController.php:110
* @route '/upcoming-products/{upcoming_product}'
*/
updateForm.put = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::update
* @see app/Http/Controllers/UpcomingProductController.php:110
* @route '/upcoming-products/{upcoming_product}'
*/
updateForm.patch = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\UpcomingProductController::destroy
* @see app/Http/Controllers/UpcomingProductController.php:239
* @route '/upcoming-products/{upcoming_product}'
*/
export const destroy = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/upcoming-products/{upcoming_product}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\UpcomingProductController::destroy
* @see app/Http/Controllers/UpcomingProductController.php:239
* @route '/upcoming-products/{upcoming_product}'
*/
destroy.url = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { upcoming_product: args }
    }

    if (Array.isArray(args)) {
        args = {
            upcoming_product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        upcoming_product: args.upcoming_product,
    }

    return destroy.definition.url
            .replace('{upcoming_product}', parsedArgs.upcoming_product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingProductController::destroy
* @see app/Http/Controllers/UpcomingProductController.php:239
* @route '/upcoming-products/{upcoming_product}'
*/
destroy.delete = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::destroy
* @see app/Http/Controllers/UpcomingProductController.php:239
* @route '/upcoming-products/{upcoming_product}'
*/
const destroyForm = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::destroy
* @see app/Http/Controllers/UpcomingProductController.php:239
* @route '/upcoming-products/{upcoming_product}'
*/
destroyForm.delete = (args: { upcoming_product: string | number } | [upcoming_product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\UpcomingProductController::publish
* @see app/Http/Controllers/UpcomingProductController.php:249
* @route '/upcoming-products/publish/{product_id}'
*/
export const publish = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: publish.url(args, options),
    method: 'put',
})

publish.definition = {
    methods: ["put"],
    url: '/upcoming-products/publish/{product_id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UpcomingProductController::publish
* @see app/Http/Controllers/UpcomingProductController.php:249
* @route '/upcoming-products/publish/{product_id}'
*/
publish.url = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            product_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product_id: args.product_id,
    }

    return publish.definition.url
            .replace('{product_id}', parsedArgs.product_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UpcomingProductController::publish
* @see app/Http/Controllers/UpcomingProductController.php:249
* @route '/upcoming-products/publish/{product_id}'
*/
publish.put = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: publish.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::publish
* @see app/Http/Controllers/UpcomingProductController.php:249
* @route '/upcoming-products/publish/{product_id}'
*/
const publishForm = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: publish.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UpcomingProductController::publish
* @see app/Http/Controllers/UpcomingProductController.php:249
* @route '/upcoming-products/publish/{product_id}'
*/
publishForm.put = (args: { product_id: string | number } | [product_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: publish.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

publish.form = publishForm

const UpcomingProductController = { index, store, show, edit, update, destroy, publish }

export default UpcomingProductController