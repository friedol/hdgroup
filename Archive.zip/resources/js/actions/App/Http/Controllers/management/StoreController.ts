import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\management\StoreController::index
* @see app/Http/Controllers/management/StoreController.php:16
* @route '/all-stores'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/all-stores',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\StoreController::index
* @see app/Http/Controllers/management/StoreController.php:16
* @route '/all-stores'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\StoreController::index
* @see app/Http/Controllers/management/StoreController.php:16
* @route '/all-stores'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::index
* @see app/Http/Controllers/management/StoreController.php:16
* @route '/all-stores'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\StoreController::index
* @see app/Http/Controllers/management/StoreController.php:16
* @route '/all-stores'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::index
* @see app/Http/Controllers/management/StoreController.php:16
* @route '/all-stores'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::index
* @see app/Http/Controllers/management/StoreController.php:16
* @route '/all-stores'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\management\StoreController::store
* @see app/Http/Controllers/management/StoreController.php:30
* @route '/all-stores'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/all-stores',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\management\StoreController::store
* @see app/Http/Controllers/management/StoreController.php:30
* @route '/all-stores'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\StoreController::store
* @see app/Http/Controllers/management/StoreController.php:30
* @route '/all-stores'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\StoreController::store
* @see app/Http/Controllers/management/StoreController.php:30
* @route '/all-stores'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\StoreController::store
* @see app/Http/Controllers/management/StoreController.php:30
* @route '/all-stores'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\management\StoreController::show
* @see app/Http/Controllers/management/StoreController.php:78
* @route '/all-stores/{all_store}'
*/
export const show = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/all-stores/{all_store}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\StoreController::show
* @see app/Http/Controllers/management/StoreController.php:78
* @route '/all-stores/{all_store}'
*/
show.url = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { all_store: args }
    }

    if (Array.isArray(args)) {
        args = {
            all_store: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        all_store: args.all_store,
    }

    return show.definition.url
            .replace('{all_store}', parsedArgs.all_store.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\StoreController::show
* @see app/Http/Controllers/management/StoreController.php:78
* @route '/all-stores/{all_store}'
*/
show.get = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::show
* @see app/Http/Controllers/management/StoreController.php:78
* @route '/all-stores/{all_store}'
*/
show.head = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\StoreController::show
* @see app/Http/Controllers/management/StoreController.php:78
* @route '/all-stores/{all_store}'
*/
const showForm = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::show
* @see app/Http/Controllers/management/StoreController.php:78
* @route '/all-stores/{all_store}'
*/
showForm.get = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::show
* @see app/Http/Controllers/management/StoreController.php:78
* @route '/all-stores/{all_store}'
*/
showForm.head = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\management\StoreController::edit
* @see app/Http/Controllers/management/StoreController.php:66
* @route '/all-stores/{all_store}/edit'
*/
export const edit = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/all-stores/{all_store}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\StoreController::edit
* @see app/Http/Controllers/management/StoreController.php:66
* @route '/all-stores/{all_store}/edit'
*/
edit.url = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { all_store: args }
    }

    if (Array.isArray(args)) {
        args = {
            all_store: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        all_store: args.all_store,
    }

    return edit.definition.url
            .replace('{all_store}', parsedArgs.all_store.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\StoreController::edit
* @see app/Http/Controllers/management/StoreController.php:66
* @route '/all-stores/{all_store}/edit'
*/
edit.get = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::edit
* @see app/Http/Controllers/management/StoreController.php:66
* @route '/all-stores/{all_store}/edit'
*/
edit.head = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\StoreController::edit
* @see app/Http/Controllers/management/StoreController.php:66
* @route '/all-stores/{all_store}/edit'
*/
const editForm = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::edit
* @see app/Http/Controllers/management/StoreController.php:66
* @route '/all-stores/{all_store}/edit'
*/
editForm.get = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::edit
* @see app/Http/Controllers/management/StoreController.php:66
* @route '/all-stores/{all_store}/edit'
*/
editForm.head = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\management\StoreController::update
* @see app/Http/Controllers/management/StoreController.php:256
* @route '/all-stores/{all_store}'
*/
export const update = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/all-stores/{all_store}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\management\StoreController::update
* @see app/Http/Controllers/management/StoreController.php:256
* @route '/all-stores/{all_store}'
*/
update.url = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { all_store: args }
    }

    if (Array.isArray(args)) {
        args = {
            all_store: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        all_store: args.all_store,
    }

    return update.definition.url
            .replace('{all_store}', parsedArgs.all_store.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\StoreController::update
* @see app/Http/Controllers/management/StoreController.php:256
* @route '/all-stores/{all_store}'
*/
update.put = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\management\StoreController::update
* @see app/Http/Controllers/management/StoreController.php:256
* @route '/all-stores/{all_store}'
*/
update.patch = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\management\StoreController::update
* @see app/Http/Controllers/management/StoreController.php:256
* @route '/all-stores/{all_store}'
*/
const updateForm = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\StoreController::update
* @see app/Http/Controllers/management/StoreController.php:256
* @route '/all-stores/{all_store}'
*/
updateForm.put = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\StoreController::update
* @see app/Http/Controllers/management/StoreController.php:256
* @route '/all-stores/{all_store}'
*/
updateForm.patch = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\management\StoreController::destroy
* @see app/Http/Controllers/management/StoreController.php:295
* @route '/all-stores/{all_store}'
*/
export const destroy = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/all-stores/{all_store}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\management\StoreController::destroy
* @see app/Http/Controllers/management/StoreController.php:295
* @route '/all-stores/{all_store}'
*/
destroy.url = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { all_store: args }
    }

    if (Array.isArray(args)) {
        args = {
            all_store: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        all_store: args.all_store,
    }

    return destroy.definition.url
            .replace('{all_store}', parsedArgs.all_store.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\StoreController::destroy
* @see app/Http/Controllers/management/StoreController.php:295
* @route '/all-stores/{all_store}'
*/
destroy.delete = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\management\StoreController::destroy
* @see app/Http/Controllers/management/StoreController.php:295
* @route '/all-stores/{all_store}'
*/
const destroyForm = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\StoreController::destroy
* @see app/Http/Controllers/management/StoreController.php:295
* @route '/all-stores/{all_store}'
*/
destroyForm.delete = (args: { all_store: string | number } | [all_store: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\management\StoreController::intelligenceReport
* @see app/Http/Controllers/management/StoreController.php:309
* @route '/all-stores/{identifier}/intelligence/{type}'
*/
export const intelligenceReport = (args: { identifier: string | number, type: string | number } | [identifier: string | number, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: intelligenceReport.url(args, options),
    method: 'get',
})

intelligenceReport.definition = {
    methods: ["get","head"],
    url: '/all-stores/{identifier}/intelligence/{type}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\StoreController::intelligenceReport
* @see app/Http/Controllers/management/StoreController.php:309
* @route '/all-stores/{identifier}/intelligence/{type}'
*/
intelligenceReport.url = (args: { identifier: string | number, type: string | number } | [identifier: string | number, type: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            identifier: args[0],
            type: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        identifier: args.identifier,
        type: args.type,
    }

    return intelligenceReport.definition.url
            .replace('{identifier}', parsedArgs.identifier.toString())
            .replace('{type}', parsedArgs.type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\StoreController::intelligenceReport
* @see app/Http/Controllers/management/StoreController.php:309
* @route '/all-stores/{identifier}/intelligence/{type}'
*/
intelligenceReport.get = (args: { identifier: string | number, type: string | number } | [identifier: string | number, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: intelligenceReport.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::intelligenceReport
* @see app/Http/Controllers/management/StoreController.php:309
* @route '/all-stores/{identifier}/intelligence/{type}'
*/
intelligenceReport.head = (args: { identifier: string | number, type: string | number } | [identifier: string | number, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: intelligenceReport.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\StoreController::intelligenceReport
* @see app/Http/Controllers/management/StoreController.php:309
* @route '/all-stores/{identifier}/intelligence/{type}'
*/
const intelligenceReportForm = (args: { identifier: string | number, type: string | number } | [identifier: string | number, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: intelligenceReport.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::intelligenceReport
* @see app/Http/Controllers/management/StoreController.php:309
* @route '/all-stores/{identifier}/intelligence/{type}'
*/
intelligenceReportForm.get = (args: { identifier: string | number, type: string | number } | [identifier: string | number, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: intelligenceReport.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::intelligenceReport
* @see app/Http/Controllers/management/StoreController.php:309
* @route '/all-stores/{identifier}/intelligence/{type}'
*/
intelligenceReportForm.head = (args: { identifier: string | number, type: string | number } | [identifier: string | number, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: intelligenceReport.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

intelligenceReport.form = intelligenceReportForm

/**
* @see \App\Http\Controllers\management\StoreController::getProductList
* @see app/Http/Controllers/management/StoreController.php:229
* @route '/get-products-store/{storeName}'
*/
export const getProductList = (args: { storeName: string | number } | [storeName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProductList.url(args, options),
    method: 'get',
})

getProductList.definition = {
    methods: ["get","head"],
    url: '/get-products-store/{storeName}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\StoreController::getProductList
* @see app/Http/Controllers/management/StoreController.php:229
* @route '/get-products-store/{storeName}'
*/
getProductList.url = (args: { storeName: string | number } | [storeName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { storeName: args }
    }

    if (Array.isArray(args)) {
        args = {
            storeName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        storeName: args.storeName,
    }

    return getProductList.definition.url
            .replace('{storeName}', parsedArgs.storeName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\StoreController::getProductList
* @see app/Http/Controllers/management/StoreController.php:229
* @route '/get-products-store/{storeName}'
*/
getProductList.get = (args: { storeName: string | number } | [storeName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProductList.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::getProductList
* @see app/Http/Controllers/management/StoreController.php:229
* @route '/get-products-store/{storeName}'
*/
getProductList.head = (args: { storeName: string | number } | [storeName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getProductList.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\StoreController::getProductList
* @see app/Http/Controllers/management/StoreController.php:229
* @route '/get-products-store/{storeName}'
*/
const getProductListForm = (args: { storeName: string | number } | [storeName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductList.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::getProductList
* @see app/Http/Controllers/management/StoreController.php:229
* @route '/get-products-store/{storeName}'
*/
getProductListForm.get = (args: { storeName: string | number } | [storeName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductList.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\StoreController::getProductList
* @see app/Http/Controllers/management/StoreController.php:229
* @route '/get-products-store/{storeName}'
*/
getProductListForm.head = (args: { storeName: string | number } | [storeName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductList.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getProductList.form = getProductListForm

const StoreController = { index, store, show, edit, update, destroy, intelligenceReport, getProductList }

export default StoreController