import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\management\UnitController::index
* @see app/Http/Controllers/management/UnitController.php:14
* @route '/units'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/units',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\UnitController::index
* @see app/Http/Controllers/management/UnitController.php:14
* @route '/units'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\UnitController::index
* @see app/Http/Controllers/management/UnitController.php:14
* @route '/units'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\UnitController::index
* @see app/Http/Controllers/management/UnitController.php:14
* @route '/units'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\UnitController::index
* @see app/Http/Controllers/management/UnitController.php:14
* @route '/units'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\UnitController::index
* @see app/Http/Controllers/management/UnitController.php:14
* @route '/units'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\UnitController::index
* @see app/Http/Controllers/management/UnitController.php:14
* @route '/units'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\management\UnitController::store
* @see app/Http/Controllers/management/UnitController.php:28
* @route '/units'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/units',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\management\UnitController::store
* @see app/Http/Controllers/management/UnitController.php:28
* @route '/units'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\UnitController::store
* @see app/Http/Controllers/management/UnitController.php:28
* @route '/units'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\UnitController::store
* @see app/Http/Controllers/management/UnitController.php:28
* @route '/units'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\UnitController::store
* @see app/Http/Controllers/management/UnitController.php:28
* @route '/units'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\management\UnitController::show
* @see app/Http/Controllers/management/UnitController.php:55
* @route '/units/{unit}'
*/
export const show = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/units/{unit}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\UnitController::show
* @see app/Http/Controllers/management/UnitController.php:55
* @route '/units/{unit}'
*/
show.url = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

    if (Array.isArray(args)) {
        args = {
            unit: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unit: args.unit,
    }

    return show.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\UnitController::show
* @see app/Http/Controllers/management/UnitController.php:55
* @route '/units/{unit}'
*/
show.get = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\UnitController::show
* @see app/Http/Controllers/management/UnitController.php:55
* @route '/units/{unit}'
*/
show.head = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\UnitController::show
* @see app/Http/Controllers/management/UnitController.php:55
* @route '/units/{unit}'
*/
const showForm = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\UnitController::show
* @see app/Http/Controllers/management/UnitController.php:55
* @route '/units/{unit}'
*/
showForm.get = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\UnitController::show
* @see app/Http/Controllers/management/UnitController.php:55
* @route '/units/{unit}'
*/
showForm.head = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\management\UnitController::edit
* @see app/Http/Controllers/management/UnitController.php:64
* @route '/units/{unit}/edit'
*/
export const edit = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/units/{unit}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\UnitController::edit
* @see app/Http/Controllers/management/UnitController.php:64
* @route '/units/{unit}/edit'
*/
edit.url = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

    if (Array.isArray(args)) {
        args = {
            unit: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unit: args.unit,
    }

    return edit.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\UnitController::edit
* @see app/Http/Controllers/management/UnitController.php:64
* @route '/units/{unit}/edit'
*/
edit.get = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\UnitController::edit
* @see app/Http/Controllers/management/UnitController.php:64
* @route '/units/{unit}/edit'
*/
edit.head = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\UnitController::edit
* @see app/Http/Controllers/management/UnitController.php:64
* @route '/units/{unit}/edit'
*/
const editForm = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\UnitController::edit
* @see app/Http/Controllers/management/UnitController.php:64
* @route '/units/{unit}/edit'
*/
editForm.get = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\UnitController::edit
* @see app/Http/Controllers/management/UnitController.php:64
* @route '/units/{unit}/edit'
*/
editForm.head = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\management\UnitController::update
* @see app/Http/Controllers/management/UnitController.php:72
* @route '/units/{unit}'
*/
export const update = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/units/{unit}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\management\UnitController::update
* @see app/Http/Controllers/management/UnitController.php:72
* @route '/units/{unit}'
*/
update.url = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

    if (Array.isArray(args)) {
        args = {
            unit: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unit: args.unit,
    }

    return update.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\UnitController::update
* @see app/Http/Controllers/management/UnitController.php:72
* @route '/units/{unit}'
*/
update.put = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\management\UnitController::update
* @see app/Http/Controllers/management/UnitController.php:72
* @route '/units/{unit}'
*/
update.patch = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\management\UnitController::update
* @see app/Http/Controllers/management/UnitController.php:72
* @route '/units/{unit}'
*/
const updateForm = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\UnitController::update
* @see app/Http/Controllers/management/UnitController.php:72
* @route '/units/{unit}'
*/
updateForm.put = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\UnitController::update
* @see app/Http/Controllers/management/UnitController.php:72
* @route '/units/{unit}'
*/
updateForm.patch = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\management\UnitController::destroy
* @see app/Http/Controllers/management/UnitController.php:93
* @route '/units/{unit}'
*/
export const destroy = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/units/{unit}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\management\UnitController::destroy
* @see app/Http/Controllers/management/UnitController.php:93
* @route '/units/{unit}'
*/
destroy.url = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

    if (Array.isArray(args)) {
        args = {
            unit: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        unit: args.unit,
    }

    return destroy.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\UnitController::destroy
* @see app/Http/Controllers/management/UnitController.php:93
* @route '/units/{unit}'
*/
destroy.delete = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\management\UnitController::destroy
* @see app/Http/Controllers/management/UnitController.php:93
* @route '/units/{unit}'
*/
const destroyForm = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\UnitController::destroy
* @see app/Http/Controllers/management/UnitController.php:93
* @route '/units/{unit}'
*/
destroyForm.delete = (args: { unit: string | number } | [unit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const UnitController = { index, store, show, edit, update, destroy }

export default UnitController