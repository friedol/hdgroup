import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\management\CategoryController::index
* @see app/Http/Controllers/management/CategoryController.php:15
* @route '/categories'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\CategoryController::index
* @see app/Http/Controllers/management/CategoryController.php:15
* @route '/categories'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::index
* @see app/Http/Controllers/management/CategoryController.php:15
* @route '/categories'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::index
* @see app/Http/Controllers/management/CategoryController.php:15
* @route '/categories'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\CategoryController::index
* @see app/Http/Controllers/management/CategoryController.php:15
* @route '/categories'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::index
* @see app/Http/Controllers/management/CategoryController.php:15
* @route '/categories'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::index
* @see app/Http/Controllers/management/CategoryController.php:15
* @route '/categories'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\management\CategoryController::indexCrud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
export const indexCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

indexCrud.definition = {
    methods: ["get","head"],
    url: '/categories-crud',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\CategoryController::indexCrud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
indexCrud.url = (options?: RouteQueryOptions) => {
    return indexCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::indexCrud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
indexCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::indexCrud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
indexCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\CategoryController::indexCrud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
const indexCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::indexCrud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
indexCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::indexCrud
* @see app/Http/Controllers/management/CategoryController.php:24
* @route '/categories-crud'
*/
indexCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexCrud.form = indexCrudForm

/**
* @see \App\Http\Controllers\management\CategoryController::createCrud
* @see app/Http/Controllers/management/CategoryController.php:29
* @route '/categories-crud/create'
*/
export const createCrud = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

createCrud.definition = {
    methods: ["get","head"],
    url: '/categories-crud/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\CategoryController::createCrud
* @see app/Http/Controllers/management/CategoryController.php:29
* @route '/categories-crud/create'
*/
createCrud.url = (options?: RouteQueryOptions) => {
    return createCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::createCrud
* @see app/Http/Controllers/management/CategoryController.php:29
* @route '/categories-crud/create'
*/
createCrud.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::createCrud
* @see app/Http/Controllers/management/CategoryController.php:29
* @route '/categories-crud/create'
*/
createCrud.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createCrud.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\CategoryController::createCrud
* @see app/Http/Controllers/management/CategoryController.php:29
* @route '/categories-crud/create'
*/
const createCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::createCrud
* @see app/Http/Controllers/management/CategoryController.php:29
* @route '/categories-crud/create'
*/
createCrudForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::createCrud
* @see app/Http/Controllers/management/CategoryController.php:29
* @route '/categories-crud/create'
*/
createCrudForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCrud.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

createCrud.form = createCrudForm

/**
* @see \App\Http\Controllers\management\CategoryController::storeCrud
* @see app/Http/Controllers/management/CategoryController.php:34
* @route '/categories-crud'
*/
export const storeCrud = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

storeCrud.definition = {
    methods: ["post"],
    url: '/categories-crud',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\management\CategoryController::storeCrud
* @see app/Http/Controllers/management/CategoryController.php:34
* @route '/categories-crud'
*/
storeCrud.url = (options?: RouteQueryOptions) => {
    return storeCrud.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::storeCrud
* @see app/Http/Controllers/management/CategoryController.php:34
* @route '/categories-crud'
*/
storeCrud.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\CategoryController::storeCrud
* @see app/Http/Controllers/management/CategoryController.php:34
* @route '/categories-crud'
*/
const storeCrudForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\CategoryController::storeCrud
* @see app/Http/Controllers/management/CategoryController.php:34
* @route '/categories-crud'
*/
storeCrudForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCrud.url(options),
    method: 'post',
})

storeCrud.form = storeCrudForm

/**
* @see \App\Http\Controllers\management\CategoryController::showCrud
* @see app/Http/Controllers/management/CategoryController.php:58
* @route '/categories-crud/{id}'
*/
export const showCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

showCrud.definition = {
    methods: ["get","head"],
    url: '/categories-crud/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\CategoryController::showCrud
* @see app/Http/Controllers/management/CategoryController.php:58
* @route '/categories-crud/{id}'
*/
showCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return showCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::showCrud
* @see app/Http/Controllers/management/CategoryController.php:58
* @route '/categories-crud/{id}'
*/
showCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::showCrud
* @see app/Http/Controllers/management/CategoryController.php:58
* @route '/categories-crud/{id}'
*/
showCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\CategoryController::showCrud
* @see app/Http/Controllers/management/CategoryController.php:58
* @route '/categories-crud/{id}'
*/
const showCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::showCrud
* @see app/Http/Controllers/management/CategoryController.php:58
* @route '/categories-crud/{id}'
*/
showCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::showCrud
* @see app/Http/Controllers/management/CategoryController.php:58
* @route '/categories-crud/{id}'
*/
showCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showCrud.form = showCrudForm

/**
* @see \App\Http\Controllers\management\CategoryController::editCrud
* @see app/Http/Controllers/management/CategoryController.php:63
* @route '/categories-crud/{id}/edit'
*/
export const editCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

editCrud.definition = {
    methods: ["get","head"],
    url: '/categories-crud/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\CategoryController::editCrud
* @see app/Http/Controllers/management/CategoryController.php:63
* @route '/categories-crud/{id}/edit'
*/
editCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return editCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::editCrud
* @see app/Http/Controllers/management/CategoryController.php:63
* @route '/categories-crud/{id}/edit'
*/
editCrud.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::editCrud
* @see app/Http/Controllers/management/CategoryController.php:63
* @route '/categories-crud/{id}/edit'
*/
editCrud.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editCrud.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\CategoryController::editCrud
* @see app/Http/Controllers/management/CategoryController.php:63
* @route '/categories-crud/{id}/edit'
*/
const editCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::editCrud
* @see app/Http/Controllers/management/CategoryController.php:63
* @route '/categories-crud/{id}/edit'
*/
editCrudForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::editCrud
* @see app/Http/Controllers/management/CategoryController.php:63
* @route '/categories-crud/{id}/edit'
*/
editCrudForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editCrud.form = editCrudForm

/**
* @see \App\Http\Controllers\management\CategoryController::updateCrud
* @see app/Http/Controllers/management/CategoryController.php:71
* @route '/categories-crud/{id}'
*/
export const updateCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

updateCrud.definition = {
    methods: ["put"],
    url: '/categories-crud/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\management\CategoryController::updateCrud
* @see app/Http/Controllers/management/CategoryController.php:71
* @route '/categories-crud/{id}'
*/
updateCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::updateCrud
* @see app/Http/Controllers/management/CategoryController.php:71
* @route '/categories-crud/{id}'
*/
updateCrud.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCrud.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\management\CategoryController::updateCrud
* @see app/Http/Controllers/management/CategoryController.php:71
* @route '/categories-crud/{id}'
*/
const updateCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\CategoryController::updateCrud
* @see app/Http/Controllers/management/CategoryController.php:71
* @route '/categories-crud/{id}'
*/
updateCrudForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateCrud.form = updateCrudForm

/**
* @see \App\Http\Controllers\management\CategoryController::destroyCrud
* @see app/Http/Controllers/management/CategoryController.php:97
* @route '/categories-crud/{id}'
*/
export const destroyCrud = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

destroyCrud.definition = {
    methods: ["delete"],
    url: '/categories-crud/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\management\CategoryController::destroyCrud
* @see app/Http/Controllers/management/CategoryController.php:97
* @route '/categories-crud/{id}'
*/
destroyCrud.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroyCrud.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::destroyCrud
* @see app/Http/Controllers/management/CategoryController.php:97
* @route '/categories-crud/{id}'
*/
destroyCrud.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCrud.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\management\CategoryController::destroyCrud
* @see app/Http/Controllers/management/CategoryController.php:97
* @route '/categories-crud/{id}'
*/
const destroyCrudForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\CategoryController::destroyCrud
* @see app/Http/Controllers/management/CategoryController.php:97
* @route '/categories-crud/{id}'
*/
destroyCrudForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCrud.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyCrud.form = destroyCrudForm

/**
* @see \App\Http\Controllers\management\CategoryController::store
* @see app/Http/Controllers/management/CategoryController.php:121
* @route '/categories'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\management\CategoryController::store
* @see app/Http/Controllers/management/CategoryController.php:121
* @route '/categories'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::store
* @see app/Http/Controllers/management/CategoryController.php:121
* @route '/categories'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\CategoryController::store
* @see app/Http/Controllers/management/CategoryController.php:121
* @route '/categories'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\CategoryController::store
* @see app/Http/Controllers/management/CategoryController.php:121
* @route '/categories'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\management\CategoryController::show
* @see app/Http/Controllers/management/CategoryController.php:140
* @route '/categories/{category}'
*/
export const show = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/categories/{category}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\CategoryController::show
* @see app/Http/Controllers/management/CategoryController.php:140
* @route '/categories/{category}'
*/
show.url = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: args.category,
    }

    return show.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::show
* @see app/Http/Controllers/management/CategoryController.php:140
* @route '/categories/{category}'
*/
show.get = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::show
* @see app/Http/Controllers/management/CategoryController.php:140
* @route '/categories/{category}'
*/
show.head = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\CategoryController::show
* @see app/Http/Controllers/management/CategoryController.php:140
* @route '/categories/{category}'
*/
const showForm = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::show
* @see app/Http/Controllers/management/CategoryController.php:140
* @route '/categories/{category}'
*/
showForm.get = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::show
* @see app/Http/Controllers/management/CategoryController.php:140
* @route '/categories/{category}'
*/
showForm.head = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\management\CategoryController::edit
* @see app/Http/Controllers/management/CategoryController.php:163
* @route '/categories/{category}/edit'
*/
export const edit = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/categories/{category}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\management\CategoryController::edit
* @see app/Http/Controllers/management/CategoryController.php:163
* @route '/categories/{category}/edit'
*/
edit.url = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: args.category,
    }

    return edit.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::edit
* @see app/Http/Controllers/management/CategoryController.php:163
* @route '/categories/{category}/edit'
*/
edit.get = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::edit
* @see app/Http/Controllers/management/CategoryController.php:163
* @route '/categories/{category}/edit'
*/
edit.head = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\management\CategoryController::edit
* @see app/Http/Controllers/management/CategoryController.php:163
* @route '/categories/{category}/edit'
*/
const editForm = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::edit
* @see app/Http/Controllers/management/CategoryController.php:163
* @route '/categories/{category}/edit'
*/
editForm.get = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\management\CategoryController::edit
* @see app/Http/Controllers/management/CategoryController.php:163
* @route '/categories/{category}/edit'
*/
editForm.head = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\management\CategoryController::update
* @see app/Http/Controllers/management/CategoryController.php:174
* @route '/categories/{category}'
*/
export const update = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/categories/{category}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\management\CategoryController::update
* @see app/Http/Controllers/management/CategoryController.php:174
* @route '/categories/{category}'
*/
update.url = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: args.category,
    }

    return update.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::update
* @see app/Http/Controllers/management/CategoryController.php:174
* @route '/categories/{category}'
*/
update.put = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\management\CategoryController::update
* @see app/Http/Controllers/management/CategoryController.php:174
* @route '/categories/{category}'
*/
update.patch = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\management\CategoryController::update
* @see app/Http/Controllers/management/CategoryController.php:174
* @route '/categories/{category}'
*/
const updateForm = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\CategoryController::update
* @see app/Http/Controllers/management/CategoryController.php:174
* @route '/categories/{category}'
*/
updateForm.put = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\CategoryController::update
* @see app/Http/Controllers/management/CategoryController.php:174
* @route '/categories/{category}'
*/
updateForm.patch = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\management\CategoryController::destroy
* @see app/Http/Controllers/management/CategoryController.php:198
* @route '/categories/{category}'
*/
export const destroy = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/categories/{category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\management\CategoryController::destroy
* @see app/Http/Controllers/management/CategoryController.php:198
* @route '/categories/{category}'
*/
destroy.url = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: args.category,
    }

    return destroy.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\management\CategoryController::destroy
* @see app/Http/Controllers/management/CategoryController.php:198
* @route '/categories/{category}'
*/
destroy.delete = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\management\CategoryController::destroy
* @see app/Http/Controllers/management/CategoryController.php:198
* @route '/categories/{category}'
*/
const destroyForm = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\management\CategoryController::destroy
* @see app/Http/Controllers/management/CategoryController.php:198
* @route '/categories/{category}'
*/
destroyForm.delete = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const CategoryController = { index, indexCrud, createCrud, storeCrud, showCrud, editCrud, updateCrud, destroyCrud, store, show, edit, update, destroy }

export default CategoryController