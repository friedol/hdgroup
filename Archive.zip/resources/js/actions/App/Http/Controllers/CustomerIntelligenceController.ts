import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/customer-intelligence',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::dashboard
* @see app/Http/Controllers/CustomerIntelligenceController.php:15
* @route '/customer-intelligence'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerSegments
* @see app/Http/Controllers/CustomerIntelligenceController.php:20
* @route '/customer-intelligence/segments'
*/
export const getCustomerSegments = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCustomerSegments.url(options),
    method: 'get',
})

getCustomerSegments.definition = {
    methods: ["get","head"],
    url: '/customer-intelligence/segments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerSegments
* @see app/Http/Controllers/CustomerIntelligenceController.php:20
* @route '/customer-intelligence/segments'
*/
getCustomerSegments.url = (options?: RouteQueryOptions) => {
    return getCustomerSegments.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerSegments
* @see app/Http/Controllers/CustomerIntelligenceController.php:20
* @route '/customer-intelligence/segments'
*/
getCustomerSegments.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCustomerSegments.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerSegments
* @see app/Http/Controllers/CustomerIntelligenceController.php:20
* @route '/customer-intelligence/segments'
*/
getCustomerSegments.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getCustomerSegments.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerSegments
* @see app/Http/Controllers/CustomerIntelligenceController.php:20
* @route '/customer-intelligence/segments'
*/
const getCustomerSegmentsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCustomerSegments.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerSegments
* @see app/Http/Controllers/CustomerIntelligenceController.php:20
* @route '/customer-intelligence/segments'
*/
getCustomerSegmentsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCustomerSegments.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerSegments
* @see app/Http/Controllers/CustomerIntelligenceController.php:20
* @route '/customer-intelligence/segments'
*/
getCustomerSegmentsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCustomerSegments.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getCustomerSegments.form = getCustomerSegmentsForm

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerLifetimeValueAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:68
* @route '/customer-intelligence/clv'
*/
export const getCustomerLifetimeValueAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCustomerLifetimeValueAnalysis.url(options),
    method: 'get',
})

getCustomerLifetimeValueAnalysis.definition = {
    methods: ["get","head"],
    url: '/customer-intelligence/clv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerLifetimeValueAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:68
* @route '/customer-intelligence/clv'
*/
getCustomerLifetimeValueAnalysis.url = (options?: RouteQueryOptions) => {
    return getCustomerLifetimeValueAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerLifetimeValueAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:68
* @route '/customer-intelligence/clv'
*/
getCustomerLifetimeValueAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCustomerLifetimeValueAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerLifetimeValueAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:68
* @route '/customer-intelligence/clv'
*/
getCustomerLifetimeValueAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getCustomerLifetimeValueAnalysis.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerLifetimeValueAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:68
* @route '/customer-intelligence/clv'
*/
const getCustomerLifetimeValueAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCustomerLifetimeValueAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerLifetimeValueAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:68
* @route '/customer-intelligence/clv'
*/
getCustomerLifetimeValueAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCustomerLifetimeValueAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerLifetimeValueAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:68
* @route '/customer-intelligence/clv'
*/
getCustomerLifetimeValueAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCustomerLifetimeValueAnalysis.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getCustomerLifetimeValueAnalysis.form = getCustomerLifetimeValueAnalysisForm

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getPurchaseFrequencyAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:98
* @route '/customer-intelligence/frequency'
*/
export const getPurchaseFrequencyAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPurchaseFrequencyAnalysis.url(options),
    method: 'get',
})

getPurchaseFrequencyAnalysis.definition = {
    methods: ["get","head"],
    url: '/customer-intelligence/frequency',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getPurchaseFrequencyAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:98
* @route '/customer-intelligence/frequency'
*/
getPurchaseFrequencyAnalysis.url = (options?: RouteQueryOptions) => {
    return getPurchaseFrequencyAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getPurchaseFrequencyAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:98
* @route '/customer-intelligence/frequency'
*/
getPurchaseFrequencyAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPurchaseFrequencyAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getPurchaseFrequencyAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:98
* @route '/customer-intelligence/frequency'
*/
getPurchaseFrequencyAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getPurchaseFrequencyAnalysis.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getPurchaseFrequencyAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:98
* @route '/customer-intelligence/frequency'
*/
const getPurchaseFrequencyAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPurchaseFrequencyAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getPurchaseFrequencyAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:98
* @route '/customer-intelligence/frequency'
*/
getPurchaseFrequencyAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPurchaseFrequencyAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getPurchaseFrequencyAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:98
* @route '/customer-intelligence/frequency'
*/
getPurchaseFrequencyAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getPurchaseFrequencyAnalysis.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getPurchaseFrequencyAnalysis.form = getPurchaseFrequencyAnalysisForm

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getRetentionRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:143
* @route '/customer-intelligence/retention-risk'
*/
export const getRetentionRiskAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getRetentionRiskAnalysis.url(options),
    method: 'get',
})

getRetentionRiskAnalysis.definition = {
    methods: ["get","head"],
    url: '/customer-intelligence/retention-risk',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getRetentionRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:143
* @route '/customer-intelligence/retention-risk'
*/
getRetentionRiskAnalysis.url = (options?: RouteQueryOptions) => {
    return getRetentionRiskAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getRetentionRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:143
* @route '/customer-intelligence/retention-risk'
*/
getRetentionRiskAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getRetentionRiskAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getRetentionRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:143
* @route '/customer-intelligence/retention-risk'
*/
getRetentionRiskAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getRetentionRiskAnalysis.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getRetentionRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:143
* @route '/customer-intelligence/retention-risk'
*/
const getRetentionRiskAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getRetentionRiskAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getRetentionRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:143
* @route '/customer-intelligence/retention-risk'
*/
getRetentionRiskAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getRetentionRiskAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getRetentionRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:143
* @route '/customer-intelligence/retention-risk'
*/
getRetentionRiskAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getRetentionRiskAnalysis.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getRetentionRiskAnalysis.form = getRetentionRiskAnalysisForm

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getVIPCustomers
* @see app/Http/Controllers/CustomerIntelligenceController.php:177
* @route '/customer-intelligence/vip'
*/
export const getVIPCustomers = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getVIPCustomers.url(options),
    method: 'get',
})

getVIPCustomers.definition = {
    methods: ["get","head"],
    url: '/customer-intelligence/vip',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getVIPCustomers
* @see app/Http/Controllers/CustomerIntelligenceController.php:177
* @route '/customer-intelligence/vip'
*/
getVIPCustomers.url = (options?: RouteQueryOptions) => {
    return getVIPCustomers.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getVIPCustomers
* @see app/Http/Controllers/CustomerIntelligenceController.php:177
* @route '/customer-intelligence/vip'
*/
getVIPCustomers.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getVIPCustomers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getVIPCustomers
* @see app/Http/Controllers/CustomerIntelligenceController.php:177
* @route '/customer-intelligence/vip'
*/
getVIPCustomers.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getVIPCustomers.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getVIPCustomers
* @see app/Http/Controllers/CustomerIntelligenceController.php:177
* @route '/customer-intelligence/vip'
*/
const getVIPCustomersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getVIPCustomers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getVIPCustomers
* @see app/Http/Controllers/CustomerIntelligenceController.php:177
* @route '/customer-intelligence/vip'
*/
getVIPCustomersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getVIPCustomers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getVIPCustomers
* @see app/Http/Controllers/CustomerIntelligenceController.php:177
* @route '/customer-intelligence/vip'
*/
getVIPCustomersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getVIPCustomers.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getVIPCustomers.form = getVIPCustomersForm

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getDiscountBehaviorAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:215
* @route '/customer-intelligence/discounts'
*/
export const getDiscountBehaviorAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDiscountBehaviorAnalysis.url(options),
    method: 'get',
})

getDiscountBehaviorAnalysis.definition = {
    methods: ["get","head"],
    url: '/customer-intelligence/discounts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getDiscountBehaviorAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:215
* @route '/customer-intelligence/discounts'
*/
getDiscountBehaviorAnalysis.url = (options?: RouteQueryOptions) => {
    return getDiscountBehaviorAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getDiscountBehaviorAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:215
* @route '/customer-intelligence/discounts'
*/
getDiscountBehaviorAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDiscountBehaviorAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getDiscountBehaviorAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:215
* @route '/customer-intelligence/discounts'
*/
getDiscountBehaviorAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getDiscountBehaviorAnalysis.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getDiscountBehaviorAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:215
* @route '/customer-intelligence/discounts'
*/
const getDiscountBehaviorAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDiscountBehaviorAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getDiscountBehaviorAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:215
* @route '/customer-intelligence/discounts'
*/
getDiscountBehaviorAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDiscountBehaviorAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getDiscountBehaviorAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:215
* @route '/customer-intelligence/discounts'
*/
getDiscountBehaviorAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDiscountBehaviorAnalysis.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getDiscountBehaviorAnalysis.form = getDiscountBehaviorAnalysisForm

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCreditRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:262
* @route '/customer-intelligence/credit-risk'
*/
export const getCreditRiskAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCreditRiskAnalysis.url(options),
    method: 'get',
})

getCreditRiskAnalysis.definition = {
    methods: ["get","head"],
    url: '/customer-intelligence/credit-risk',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCreditRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:262
* @route '/customer-intelligence/credit-risk'
*/
getCreditRiskAnalysis.url = (options?: RouteQueryOptions) => {
    return getCreditRiskAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCreditRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:262
* @route '/customer-intelligence/credit-risk'
*/
getCreditRiskAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCreditRiskAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCreditRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:262
* @route '/customer-intelligence/credit-risk'
*/
getCreditRiskAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getCreditRiskAnalysis.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCreditRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:262
* @route '/customer-intelligence/credit-risk'
*/
const getCreditRiskAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCreditRiskAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCreditRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:262
* @route '/customer-intelligence/credit-risk'
*/
getCreditRiskAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCreditRiskAnalysis.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCreditRiskAnalysis
* @see app/Http/Controllers/CustomerIntelligenceController.php:262
* @route '/customer-intelligence/credit-risk'
*/
getCreditRiskAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCreditRiskAnalysis.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getCreditRiskAnalysis.form = getCreditRiskAnalysisForm

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerIntelligenceSummary
* @see app/Http/Controllers/CustomerIntelligenceController.php:295
* @route '/customer-intelligence/summary'
*/
export const getCustomerIntelligenceSummary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCustomerIntelligenceSummary.url(options),
    method: 'get',
})

getCustomerIntelligenceSummary.definition = {
    methods: ["get","head"],
    url: '/customer-intelligence/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerIntelligenceSummary
* @see app/Http/Controllers/CustomerIntelligenceController.php:295
* @route '/customer-intelligence/summary'
*/
getCustomerIntelligenceSummary.url = (options?: RouteQueryOptions) => {
    return getCustomerIntelligenceSummary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerIntelligenceSummary
* @see app/Http/Controllers/CustomerIntelligenceController.php:295
* @route '/customer-intelligence/summary'
*/
getCustomerIntelligenceSummary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCustomerIntelligenceSummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerIntelligenceSummary
* @see app/Http/Controllers/CustomerIntelligenceController.php:295
* @route '/customer-intelligence/summary'
*/
getCustomerIntelligenceSummary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getCustomerIntelligenceSummary.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerIntelligenceSummary
* @see app/Http/Controllers/CustomerIntelligenceController.php:295
* @route '/customer-intelligence/summary'
*/
const getCustomerIntelligenceSummaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCustomerIntelligenceSummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerIntelligenceSummary
* @see app/Http/Controllers/CustomerIntelligenceController.php:295
* @route '/customer-intelligence/summary'
*/
getCustomerIntelligenceSummaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCustomerIntelligenceSummary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CustomerIntelligenceController::getCustomerIntelligenceSummary
* @see app/Http/Controllers/CustomerIntelligenceController.php:295
* @route '/customer-intelligence/summary'
*/
getCustomerIntelligenceSummaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getCustomerIntelligenceSummary.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getCustomerIntelligenceSummary.form = getCustomerIntelligenceSummaryForm

const CustomerIntelligenceController = { dashboard, getCustomerSegments, getCustomerLifetimeValueAnalysis, getPurchaseFrequencyAnalysis, getRetentionRiskAnalysis, getVIPCustomers, getDiscountBehaviorAnalysis, getCreditRiskAnalysis, getCustomerIntelligenceSummary }

export default CustomerIntelligenceController