import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RequisitionController::index
* @see app/Http/Controllers/RequisitionController.php:10
* @route '/requisitions'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/requisitions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RequisitionController::index
* @see app/Http/Controllers/RequisitionController.php:10
* @route '/requisitions'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RequisitionController::index
* @see app/Http/Controllers/RequisitionController.php:10
* @route '/requisitions'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RequisitionController::index
* @see app/Http/Controllers/RequisitionController.php:10
* @route '/requisitions'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RequisitionController::index
* @see app/Http/Controllers/RequisitionController.php:10
* @route '/requisitions'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RequisitionController::index
* @see app/Http/Controllers/RequisitionController.php:10
* @route '/requisitions'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RequisitionController::index
* @see app/Http/Controllers/RequisitionController.php:10
* @route '/requisitions'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\RequisitionController::create
* @see app/Http/Controllers/RequisitionController.php:20
* @route '/requisitions/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/requisitions/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RequisitionController::create
* @see app/Http/Controllers/RequisitionController.php:20
* @route '/requisitions/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RequisitionController::create
* @see app/Http/Controllers/RequisitionController.php:20
* @route '/requisitions/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RequisitionController::create
* @see app/Http/Controllers/RequisitionController.php:20
* @route '/requisitions/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RequisitionController::create
* @see app/Http/Controllers/RequisitionController.php:20
* @route '/requisitions/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RequisitionController::create
* @see app/Http/Controllers/RequisitionController.php:20
* @route '/requisitions/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RequisitionController::create
* @see app/Http/Controllers/RequisitionController.php:20
* @route '/requisitions/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\RequisitionController::store
* @see app/Http/Controllers/RequisitionController.php:42
* @route '/requisitions'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/requisitions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RequisitionController::store
* @see app/Http/Controllers/RequisitionController.php:42
* @route '/requisitions'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RequisitionController::store
* @see app/Http/Controllers/RequisitionController.php:42
* @route '/requisitions'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RequisitionController::store
* @see app/Http/Controllers/RequisitionController.php:42
* @route '/requisitions'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RequisitionController::store
* @see app/Http/Controllers/RequisitionController.php:42
* @route '/requisitions'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\RequisitionController::show
* @see app/Http/Controllers/RequisitionController.php:72
* @route '/requisitions/{requisition}'
*/
export const show = (args: { requisition: number | { id: number } } | [requisition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/requisitions/{requisition}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RequisitionController::show
* @see app/Http/Controllers/RequisitionController.php:72
* @route '/requisitions/{requisition}'
*/
show.url = (args: { requisition: number | { id: number } } | [requisition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { requisition: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { requisition: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            requisition: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        requisition: typeof args.requisition === 'object'
        ? args.requisition.id
        : args.requisition,
    }

    return show.definition.url
            .replace('{requisition}', parsedArgs.requisition.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RequisitionController::show
* @see app/Http/Controllers/RequisitionController.php:72
* @route '/requisitions/{requisition}'
*/
show.get = (args: { requisition: number | { id: number } } | [requisition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RequisitionController::show
* @see app/Http/Controllers/RequisitionController.php:72
* @route '/requisitions/{requisition}'
*/
show.head = (args: { requisition: number | { id: number } } | [requisition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RequisitionController::show
* @see app/Http/Controllers/RequisitionController.php:72
* @route '/requisitions/{requisition}'
*/
const showForm = (args: { requisition: number | { id: number } } | [requisition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RequisitionController::show
* @see app/Http/Controllers/RequisitionController.php:72
* @route '/requisitions/{requisition}'
*/
showForm.get = (args: { requisition: number | { id: number } } | [requisition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RequisitionController::show
* @see app/Http/Controllers/RequisitionController.php:72
* @route '/requisitions/{requisition}'
*/
showForm.head = (args: { requisition: number | { id: number } } | [requisition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const RequisitionController = { index, create, store, show }

export default RequisitionController