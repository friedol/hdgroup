import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::inventory_index
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
export const inventory_index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: inventory_index.url(options),
    method: 'get',
})

inventory_index.definition = {
    methods: ["get","head"],
    url: '/report_inventory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::inventory_index
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
inventory_index.url = (options?: RouteQueryOptions) => {
    return inventory_index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::inventory_index
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
inventory_index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: inventory_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::inventory_index
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
inventory_index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: inventory_index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::inventory_index
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
const inventory_indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: inventory_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::inventory_index
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
inventory_indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: inventory_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::inventory_index
* @see app/Http/Controllers/ReportController.php:27
* @route '/report_inventory'
*/
inventory_indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: inventory_index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

inventory_index.form = inventory_indexForm

/**
* @see \App\Http\Controllers\ReportController::Filter_inventory_by_Date
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
export const Filter_inventory_by_Date = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Filter_inventory_by_Date.url(options),
    method: 'get',
})

Filter_inventory_by_Date.definition = {
    methods: ["get","head"],
    url: '/report_inventory/Filter',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::Filter_inventory_by_Date
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
Filter_inventory_by_Date.url = (options?: RouteQueryOptions) => {
    return Filter_inventory_by_Date.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::Filter_inventory_by_Date
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
Filter_inventory_by_Date.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Filter_inventory_by_Date.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::Filter_inventory_by_Date
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
Filter_inventory_by_Date.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Filter_inventory_by_Date.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::Filter_inventory_by_Date
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
const Filter_inventory_by_DateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Filter_inventory_by_Date.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::Filter_inventory_by_Date
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
Filter_inventory_by_DateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Filter_inventory_by_Date.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::Filter_inventory_by_Date
* @see app/Http/Controllers/ReportController.php:46
* @route '/report_inventory/Filter'
*/
Filter_inventory_by_DateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Filter_inventory_by_Date.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Filter_inventory_by_Date.form = Filter_inventory_by_DateForm

/**
* @see \App\Http\Controllers\ReportController::profit_index
* @see app/Http/Controllers/ReportController.php:68
* @route '/report_profit'
*/
export const profit_index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profit_index.url(options),
    method: 'get',
})

profit_index.definition = {
    methods: ["get","head"],
    url: '/report_profit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::profit_index
* @see app/Http/Controllers/ReportController.php:68
* @route '/report_profit'
*/
profit_index.url = (options?: RouteQueryOptions) => {
    return profit_index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::profit_index
* @see app/Http/Controllers/ReportController.php:68
* @route '/report_profit'
*/
profit_index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profit_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::profit_index
* @see app/Http/Controllers/ReportController.php:68
* @route '/report_profit'
*/
profit_index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profit_index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::profit_index
* @see app/Http/Controllers/ReportController.php:68
* @route '/report_profit'
*/
const profit_indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profit_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::profit_index
* @see app/Http/Controllers/ReportController.php:68
* @route '/report_profit'
*/
profit_indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profit_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::profit_index
* @see app/Http/Controllers/ReportController.php:68
* @route '/report_profit'
*/
profit_indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profit_index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

profit_index.form = profit_indexForm

/**
* @see \App\Http\Controllers\ReportController::profit_print
* @see app/Http/Controllers/ReportController.php:243
* @route '/report_profit/print'
*/
export const profit_print = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profit_print.url(options),
    method: 'get',
})

profit_print.definition = {
    methods: ["get","head"],
    url: '/report_profit/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::profit_print
* @see app/Http/Controllers/ReportController.php:243
* @route '/report_profit/print'
*/
profit_print.url = (options?: RouteQueryOptions) => {
    return profit_print.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::profit_print
* @see app/Http/Controllers/ReportController.php:243
* @route '/report_profit/print'
*/
profit_print.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profit_print.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::profit_print
* @see app/Http/Controllers/ReportController.php:243
* @route '/report_profit/print'
*/
profit_print.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profit_print.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::profit_print
* @see app/Http/Controllers/ReportController.php:243
* @route '/report_profit/print'
*/
const profit_printForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profit_print.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::profit_print
* @see app/Http/Controllers/ReportController.php:243
* @route '/report_profit/print'
*/
profit_printForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profit_print.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::profit_print
* @see app/Http/Controllers/ReportController.php:243
* @route '/report_profit/print'
*/
profit_printForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profit_print.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

profit_print.form = profit_printForm

/**
* @see \App\Http\Controllers\ReportController::loans_index
* @see app/Http/Controllers/ReportController.php:335
* @route '/report_loan'
*/
export const loans_index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loans_index.url(options),
    method: 'get',
})

loans_index.definition = {
    methods: ["get","head"],
    url: '/report_loan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::loans_index
* @see app/Http/Controllers/ReportController.php:335
* @route '/report_loan'
*/
loans_index.url = (options?: RouteQueryOptions) => {
    return loans_index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::loans_index
* @see app/Http/Controllers/ReportController.php:335
* @route '/report_loan'
*/
loans_index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loans_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::loans_index
* @see app/Http/Controllers/ReportController.php:335
* @route '/report_loan'
*/
loans_index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: loans_index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::loans_index
* @see app/Http/Controllers/ReportController.php:335
* @route '/report_loan'
*/
const loans_indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loans_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::loans_index
* @see app/Http/Controllers/ReportController.php:335
* @route '/report_loan'
*/
loans_indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loans_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::loans_index
* @see app/Http/Controllers/ReportController.php:335
* @route '/report_loan'
*/
loans_indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loans_index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

loans_index.form = loans_indexForm

/**
* @see \App\Http\Controllers\ReportController::sales_index
* @see app/Http/Controllers/ReportController.php:354
* @route '/report_sales'
*/
export const sales_index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sales_index.url(options),
    method: 'get',
})

sales_index.definition = {
    methods: ["get","head"],
    url: '/report_sales',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::sales_index
* @see app/Http/Controllers/ReportController.php:354
* @route '/report_sales'
*/
sales_index.url = (options?: RouteQueryOptions) => {
    return sales_index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::sales_index
* @see app/Http/Controllers/ReportController.php:354
* @route '/report_sales'
*/
sales_index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sales_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::sales_index
* @see app/Http/Controllers/ReportController.php:354
* @route '/report_sales'
*/
sales_index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sales_index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::sales_index
* @see app/Http/Controllers/ReportController.php:354
* @route '/report_sales'
*/
const sales_indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sales_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::sales_index
* @see app/Http/Controllers/ReportController.php:354
* @route '/report_sales'
*/
sales_indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sales_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::sales_index
* @see app/Http/Controllers/ReportController.php:354
* @route '/report_sales'
*/
sales_indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sales_index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

sales_index.form = sales_indexForm

/**
* @see \App\Http\Controllers\ReportController::product_sales
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
export const product_sales = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product_sales.url(args, options),
    method: 'get',
})

product_sales.definition = {
    methods: ["get","head"],
    url: '/report_sales/single_product/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::product_sales
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
product_sales.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return product_sales.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::product_sales
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
product_sales.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product_sales.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::product_sales
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
product_sales.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: product_sales.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::product_sales
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
const product_salesForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product_sales.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::product_sales
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
product_salesForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product_sales.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::product_sales
* @see app/Http/Controllers/ReportController.php:644
* @route '/report_sales/single_product/{id}'
*/
product_salesForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: product_sales.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

product_sales.form = product_salesForm

/**
* @see \App\Http\Controllers\ReportController::expenses_index
* @see app/Http/Controllers/ReportController.php:656
* @route '/report_expenses'
*/
export const expenses_index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expenses_index.url(options),
    method: 'get',
})

expenses_index.definition = {
    methods: ["get","head"],
    url: '/report_expenses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::expenses_index
* @see app/Http/Controllers/ReportController.php:656
* @route '/report_expenses'
*/
expenses_index.url = (options?: RouteQueryOptions) => {
    return expenses_index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::expenses_index
* @see app/Http/Controllers/ReportController.php:656
* @route '/report_expenses'
*/
expenses_index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expenses_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::expenses_index
* @see app/Http/Controllers/ReportController.php:656
* @route '/report_expenses'
*/
expenses_index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: expenses_index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::expenses_index
* @see app/Http/Controllers/ReportController.php:656
* @route '/report_expenses'
*/
const expenses_indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: expenses_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::expenses_index
* @see app/Http/Controllers/ReportController.php:656
* @route '/report_expenses'
*/
expenses_indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: expenses_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::expenses_index
* @see app/Http/Controllers/ReportController.php:656
* @route '/report_expenses'
*/
expenses_indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: expenses_index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

expenses_index.form = expenses_indexForm

/**
* @see \App\Http\Controllers\ReportController::general_index
* @see app/Http/Controllers/ReportController.php:711
* @route '/report_general'
*/
export const general_index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: general_index.url(options),
    method: 'get',
})

general_index.definition = {
    methods: ["get","head"],
    url: '/report_general',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::general_index
* @see app/Http/Controllers/ReportController.php:711
* @route '/report_general'
*/
general_index.url = (options?: RouteQueryOptions) => {
    return general_index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::general_index
* @see app/Http/Controllers/ReportController.php:711
* @route '/report_general'
*/
general_index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: general_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::general_index
* @see app/Http/Controllers/ReportController.php:711
* @route '/report_general'
*/
general_index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: general_index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::general_index
* @see app/Http/Controllers/ReportController.php:711
* @route '/report_general'
*/
const general_indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: general_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::general_index
* @see app/Http/Controllers/ReportController.php:711
* @route '/report_general'
*/
general_indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: general_index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::general_index
* @see app/Http/Controllers/ReportController.php:711
* @route '/report_general'
*/
general_indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: general_index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

general_index.form = general_indexForm

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:813
* @route '/balance_sheet'
*/
export const balance_sheet = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balance_sheet.url(options),
    method: 'get',
})

balance_sheet.definition = {
    methods: ["get","head"],
    url: '/balance_sheet',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:813
* @route '/balance_sheet'
*/
balance_sheet.url = (options?: RouteQueryOptions) => {
    return balance_sheet.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:813
* @route '/balance_sheet'
*/
balance_sheet.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: balance_sheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:813
* @route '/balance_sheet'
*/
balance_sheet.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: balance_sheet.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:813
* @route '/balance_sheet'
*/
const balance_sheetForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balance_sheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:813
* @route '/balance_sheet'
*/
balance_sheetForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balance_sheet.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReportController::balance_sheet
* @see app/Http/Controllers/ReportController.php:813
* @route '/balance_sheet'
*/
balance_sheetForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: balance_sheet.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

balance_sheet.form = balance_sheetForm

const ReportController = { inventory_index, Filter_inventory_by_Date, profit_index, profit_print, loans_index, sales_index, product_sales, expenses_index, general_index, balance_sheet }

export default ReportController