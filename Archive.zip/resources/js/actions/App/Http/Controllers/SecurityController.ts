import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SecurityController::system_logs
* @see app/Http/Controllers/SecurityController.php:10
* @route '/logs'
*/
export const system_logs = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: system_logs.url(options),
    method: 'get',
})

system_logs.definition = {
    methods: ["get","head"],
    url: '/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SecurityController::system_logs
* @see app/Http/Controllers/SecurityController.php:10
* @route '/logs'
*/
system_logs.url = (options?: RouteQueryOptions) => {
    return system_logs.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SecurityController::system_logs
* @see app/Http/Controllers/SecurityController.php:10
* @route '/logs'
*/
system_logs.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: system_logs.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SecurityController::system_logs
* @see app/Http/Controllers/SecurityController.php:10
* @route '/logs'
*/
system_logs.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: system_logs.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SecurityController::system_logs
* @see app/Http/Controllers/SecurityController.php:10
* @route '/logs'
*/
const system_logsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: system_logs.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SecurityController::system_logs
* @see app/Http/Controllers/SecurityController.php:10
* @route '/logs'
*/
system_logsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: system_logs.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SecurityController::system_logs
* @see app/Http/Controllers/SecurityController.php:10
* @route '/logs'
*/
system_logsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: system_logs.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

system_logs.form = system_logsForm

const SecurityController = { system_logs }

export default SecurityController