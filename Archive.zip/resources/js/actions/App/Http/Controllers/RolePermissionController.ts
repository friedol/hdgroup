import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/roles-permissions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::index
* @see app/Http/Controllers/RolePermissionController.php:11
* @route '/roles-permissions'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\RolePermissionController::roleCreate
* @see app/Http/Controllers/RolePermissionController.php:19
* @route '/roles-permissions/roles/create'
*/
export const roleCreate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: roleCreate.url(options),
    method: 'get',
})

roleCreate.definition = {
    methods: ["get","head"],
    url: '/roles-permissions/roles/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RolePermissionController::roleCreate
* @see app/Http/Controllers/RolePermissionController.php:19
* @route '/roles-permissions/roles/create'
*/
roleCreate.url = (options?: RouteQueryOptions) => {
    return roleCreate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::roleCreate
* @see app/Http/Controllers/RolePermissionController.php:19
* @route '/roles-permissions/roles/create'
*/
roleCreate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: roleCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleCreate
* @see app/Http/Controllers/RolePermissionController.php:19
* @route '/roles-permissions/roles/create'
*/
roleCreate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: roleCreate.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleCreate
* @see app/Http/Controllers/RolePermissionController.php:19
* @route '/roles-permissions/roles/create'
*/
const roleCreateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: roleCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleCreate
* @see app/Http/Controllers/RolePermissionController.php:19
* @route '/roles-permissions/roles/create'
*/
roleCreateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: roleCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleCreate
* @see app/Http/Controllers/RolePermissionController.php:19
* @route '/roles-permissions/roles/create'
*/
roleCreateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: roleCreate.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

roleCreate.form = roleCreateForm

/**
* @see \App\Http\Controllers\RolePermissionController::roleStore
* @see app/Http/Controllers/RolePermissionController.php:26
* @route '/roles-permissions/roles'
*/
export const roleStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: roleStore.url(options),
    method: 'post',
})

roleStore.definition = {
    methods: ["post"],
    url: '/roles-permissions/roles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RolePermissionController::roleStore
* @see app/Http/Controllers/RolePermissionController.php:26
* @route '/roles-permissions/roles'
*/
roleStore.url = (options?: RouteQueryOptions) => {
    return roleStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::roleStore
* @see app/Http/Controllers/RolePermissionController.php:26
* @route '/roles-permissions/roles'
*/
roleStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: roleStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleStore
* @see app/Http/Controllers/RolePermissionController.php:26
* @route '/roles-permissions/roles'
*/
const roleStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: roleStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleStore
* @see app/Http/Controllers/RolePermissionController.php:26
* @route '/roles-permissions/roles'
*/
roleStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: roleStore.url(options),
    method: 'post',
})

roleStore.form = roleStoreForm

/**
* @see \App\Http\Controllers\RolePermissionController::roleEdit
* @see app/Http/Controllers/RolePermissionController.php:41
* @route '/roles-permissions/roles/{role}/edit'
*/
export const roleEdit = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: roleEdit.url(args, options),
    method: 'get',
})

roleEdit.definition = {
    methods: ["get","head"],
    url: '/roles-permissions/roles/{role}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RolePermissionController::roleEdit
* @see app/Http/Controllers/RolePermissionController.php:41
* @route '/roles-permissions/roles/{role}/edit'
*/
roleEdit.url = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { role: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { role: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            role: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        role: typeof args.role === 'object'
        ? args.role.id
        : args.role,
    }

    return roleEdit.definition.url
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::roleEdit
* @see app/Http/Controllers/RolePermissionController.php:41
* @route '/roles-permissions/roles/{role}/edit'
*/
roleEdit.get = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: roleEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleEdit
* @see app/Http/Controllers/RolePermissionController.php:41
* @route '/roles-permissions/roles/{role}/edit'
*/
roleEdit.head = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: roleEdit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleEdit
* @see app/Http/Controllers/RolePermissionController.php:41
* @route '/roles-permissions/roles/{role}/edit'
*/
const roleEditForm = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: roleEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleEdit
* @see app/Http/Controllers/RolePermissionController.php:41
* @route '/roles-permissions/roles/{role}/edit'
*/
roleEditForm.get = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: roleEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleEdit
* @see app/Http/Controllers/RolePermissionController.php:41
* @route '/roles-permissions/roles/{role}/edit'
*/
roleEditForm.head = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: roleEdit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

roleEdit.form = roleEditForm

/**
* @see \App\Http\Controllers\RolePermissionController::roleUpdate
* @see app/Http/Controllers/RolePermissionController.php:50
* @route '/roles-permissions/roles/{role}'
*/
export const roleUpdate = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: roleUpdate.url(args, options),
    method: 'put',
})

roleUpdate.definition = {
    methods: ["put"],
    url: '/roles-permissions/roles/{role}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\RolePermissionController::roleUpdate
* @see app/Http/Controllers/RolePermissionController.php:50
* @route '/roles-permissions/roles/{role}'
*/
roleUpdate.url = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { role: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { role: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            role: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        role: typeof args.role === 'object'
        ? args.role.id
        : args.role,
    }

    return roleUpdate.definition.url
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::roleUpdate
* @see app/Http/Controllers/RolePermissionController.php:50
* @route '/roles-permissions/roles/{role}'
*/
roleUpdate.put = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: roleUpdate.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleUpdate
* @see app/Http/Controllers/RolePermissionController.php:50
* @route '/roles-permissions/roles/{role}'
*/
const roleUpdateForm = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: roleUpdate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleUpdate
* @see app/Http/Controllers/RolePermissionController.php:50
* @route '/roles-permissions/roles/{role}'
*/
roleUpdateForm.put = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: roleUpdate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

roleUpdate.form = roleUpdateForm

/**
* @see \App\Http\Controllers\RolePermissionController::roleDestroy
* @see app/Http/Controllers/RolePermissionController.php:63
* @route '/roles-permissions/roles/{role}'
*/
export const roleDestroy = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: roleDestroy.url(args, options),
    method: 'delete',
})

roleDestroy.definition = {
    methods: ["delete"],
    url: '/roles-permissions/roles/{role}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\RolePermissionController::roleDestroy
* @see app/Http/Controllers/RolePermissionController.php:63
* @route '/roles-permissions/roles/{role}'
*/
roleDestroy.url = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { role: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { role: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            role: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        role: typeof args.role === 'object'
        ? args.role.id
        : args.role,
    }

    return roleDestroy.definition.url
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::roleDestroy
* @see app/Http/Controllers/RolePermissionController.php:63
* @route '/roles-permissions/roles/{role}'
*/
roleDestroy.delete = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: roleDestroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleDestroy
* @see app/Http/Controllers/RolePermissionController.php:63
* @route '/roles-permissions/roles/{role}'
*/
const roleDestroyForm = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: roleDestroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RolePermissionController::roleDestroy
* @see app/Http/Controllers/RolePermissionController.php:63
* @route '/roles-permissions/roles/{role}'
*/
roleDestroyForm.delete = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: roleDestroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

roleDestroy.form = roleDestroyForm

/**
* @see \App\Http\Controllers\RolePermissionController::permissionCreate
* @see app/Http/Controllers/RolePermissionController.php:76
* @route '/roles-permissions/permissions/create'
*/
export const permissionCreate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: permissionCreate.url(options),
    method: 'get',
})

permissionCreate.definition = {
    methods: ["get","head"],
    url: '/roles-permissions/permissions/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RolePermissionController::permissionCreate
* @see app/Http/Controllers/RolePermissionController.php:76
* @route '/roles-permissions/permissions/create'
*/
permissionCreate.url = (options?: RouteQueryOptions) => {
    return permissionCreate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::permissionCreate
* @see app/Http/Controllers/RolePermissionController.php:76
* @route '/roles-permissions/permissions/create'
*/
permissionCreate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: permissionCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionCreate
* @see app/Http/Controllers/RolePermissionController.php:76
* @route '/roles-permissions/permissions/create'
*/
permissionCreate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: permissionCreate.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionCreate
* @see app/Http/Controllers/RolePermissionController.php:76
* @route '/roles-permissions/permissions/create'
*/
const permissionCreateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: permissionCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionCreate
* @see app/Http/Controllers/RolePermissionController.php:76
* @route '/roles-permissions/permissions/create'
*/
permissionCreateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: permissionCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionCreate
* @see app/Http/Controllers/RolePermissionController.php:76
* @route '/roles-permissions/permissions/create'
*/
permissionCreateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: permissionCreate.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

permissionCreate.form = permissionCreateForm

/**
* @see \App\Http\Controllers\RolePermissionController::permissionStore
* @see app/Http/Controllers/RolePermissionController.php:81
* @route '/roles-permissions/permissions'
*/
export const permissionStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: permissionStore.url(options),
    method: 'post',
})

permissionStore.definition = {
    methods: ["post"],
    url: '/roles-permissions/permissions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RolePermissionController::permissionStore
* @see app/Http/Controllers/RolePermissionController.php:81
* @route '/roles-permissions/permissions'
*/
permissionStore.url = (options?: RouteQueryOptions) => {
    return permissionStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::permissionStore
* @see app/Http/Controllers/RolePermissionController.php:81
* @route '/roles-permissions/permissions'
*/
permissionStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: permissionStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionStore
* @see app/Http/Controllers/RolePermissionController.php:81
* @route '/roles-permissions/permissions'
*/
const permissionStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: permissionStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionStore
* @see app/Http/Controllers/RolePermissionController.php:81
* @route '/roles-permissions/permissions'
*/
permissionStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: permissionStore.url(options),
    method: 'post',
})

permissionStore.form = permissionStoreForm

/**
* @see \App\Http\Controllers\RolePermissionController::permissionEdit
* @see app/Http/Controllers/RolePermissionController.php:95
* @route '/roles-permissions/permissions/{permission}/edit'
*/
export const permissionEdit = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: permissionEdit.url(args, options),
    method: 'get',
})

permissionEdit.definition = {
    methods: ["get","head"],
    url: '/roles-permissions/permissions/{permission}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RolePermissionController::permissionEdit
* @see app/Http/Controllers/RolePermissionController.php:95
* @route '/roles-permissions/permissions/{permission}/edit'
*/
permissionEdit.url = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { permission: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { permission: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            permission: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        permission: typeof args.permission === 'object'
        ? args.permission.id
        : args.permission,
    }

    return permissionEdit.definition.url
            .replace('{permission}', parsedArgs.permission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::permissionEdit
* @see app/Http/Controllers/RolePermissionController.php:95
* @route '/roles-permissions/permissions/{permission}/edit'
*/
permissionEdit.get = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: permissionEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionEdit
* @see app/Http/Controllers/RolePermissionController.php:95
* @route '/roles-permissions/permissions/{permission}/edit'
*/
permissionEdit.head = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: permissionEdit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionEdit
* @see app/Http/Controllers/RolePermissionController.php:95
* @route '/roles-permissions/permissions/{permission}/edit'
*/
const permissionEditForm = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: permissionEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionEdit
* @see app/Http/Controllers/RolePermissionController.php:95
* @route '/roles-permissions/permissions/{permission}/edit'
*/
permissionEditForm.get = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: permissionEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionEdit
* @see app/Http/Controllers/RolePermissionController.php:95
* @route '/roles-permissions/permissions/{permission}/edit'
*/
permissionEditForm.head = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: permissionEdit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

permissionEdit.form = permissionEditForm

/**
* @see \App\Http\Controllers\RolePermissionController::permissionUpdate
* @see app/Http/Controllers/RolePermissionController.php:100
* @route '/roles-permissions/permissions/{permission}'
*/
export const permissionUpdate = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: permissionUpdate.url(args, options),
    method: 'put',
})

permissionUpdate.definition = {
    methods: ["put"],
    url: '/roles-permissions/permissions/{permission}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\RolePermissionController::permissionUpdate
* @see app/Http/Controllers/RolePermissionController.php:100
* @route '/roles-permissions/permissions/{permission}'
*/
permissionUpdate.url = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { permission: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { permission: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            permission: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        permission: typeof args.permission === 'object'
        ? args.permission.id
        : args.permission,
    }

    return permissionUpdate.definition.url
            .replace('{permission}', parsedArgs.permission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::permissionUpdate
* @see app/Http/Controllers/RolePermissionController.php:100
* @route '/roles-permissions/permissions/{permission}'
*/
permissionUpdate.put = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: permissionUpdate.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionUpdate
* @see app/Http/Controllers/RolePermissionController.php:100
* @route '/roles-permissions/permissions/{permission}'
*/
const permissionUpdateForm = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: permissionUpdate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionUpdate
* @see app/Http/Controllers/RolePermissionController.php:100
* @route '/roles-permissions/permissions/{permission}'
*/
permissionUpdateForm.put = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: permissionUpdate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

permissionUpdate.form = permissionUpdateForm

/**
* @see \App\Http\Controllers\RolePermissionController::permissionDestroy
* @see app/Http/Controllers/RolePermissionController.php:114
* @route '/roles-permissions/permissions/{permission}'
*/
export const permissionDestroy = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: permissionDestroy.url(args, options),
    method: 'delete',
})

permissionDestroy.definition = {
    methods: ["delete"],
    url: '/roles-permissions/permissions/{permission}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\RolePermissionController::permissionDestroy
* @see app/Http/Controllers/RolePermissionController.php:114
* @route '/roles-permissions/permissions/{permission}'
*/
permissionDestroy.url = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { permission: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { permission: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            permission: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        permission: typeof args.permission === 'object'
        ? args.permission.id
        : args.permission,
    }

    return permissionDestroy.definition.url
            .replace('{permission}', parsedArgs.permission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RolePermissionController::permissionDestroy
* @see app/Http/Controllers/RolePermissionController.php:114
* @route '/roles-permissions/permissions/{permission}'
*/
permissionDestroy.delete = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: permissionDestroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionDestroy
* @see app/Http/Controllers/RolePermissionController.php:114
* @route '/roles-permissions/permissions/{permission}'
*/
const permissionDestroyForm = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: permissionDestroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RolePermissionController::permissionDestroy
* @see app/Http/Controllers/RolePermissionController.php:114
* @route '/roles-permissions/permissions/{permission}'
*/
permissionDestroyForm.delete = (args: { permission: number | { id: number } } | [permission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: permissionDestroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

permissionDestroy.form = permissionDestroyForm

const RolePermissionController = { index, roleCreate, roleStore, roleEdit, roleUpdate, roleDestroy, permissionCreate, permissionStore, permissionEdit, permissionUpdate, permissionDestroy }

export default RolePermissionController