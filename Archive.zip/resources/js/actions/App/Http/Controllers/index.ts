import PageController from './PageController'
import ProfileController from './ProfileController'
import HomeController from './HomeController'
import CartController from './CartController'
import management from './management'
import Account from './Account'
import ReviewController from './ReviewController'
import DashboardController from './DashboardController'
import RequisitionController from './RequisitionController'
import FeedbackController from './FeedbackController'
import ProductController from './ProductController'
import CustomerController from './CustomerController'
import SupplierController from './SupplierController'
import LoanController from './LoanController'
import PaymentController from './PaymentController'
import ExpensesController from './ExpensesController'
import ProductionOrderController from './ProductionOrderController'
import BomController from './BomController'
import CustomerOrderController from './CustomerOrderController'
import ContainerController from './ContainerController'
import UserController from './UserController'
import ProductionController from './ProductionController'
import RollProductionController from './RollProductionController'
import ProductionBenchmarkController from './ProductionBenchmarkController'
import UpcomingOrderController from './UpcomingOrderController'
import UpcomingProductController from './UpcomingProductController'
import ExportController from './ExportController'
import TransferController from './TransferController'
import RegisterProductController from './RegisterProductController'
import ParkingOrderController from './ParkingOrderController'
import DeliveryController from './DeliveryController'
import DeliveryPersonController from './DeliveryPersonController'
import DeliveryTrackingController from './DeliveryTrackingController'
import GatekeeperController from './GatekeeperController'
import InventoryController from './InventoryController'
import SecurityController from './SecurityController'
import ReportController from './ReportController'
import SystemSettingController from './SystemSettingController'
import SalesTargetController from './SalesTargetController'
import PaymentRequestController from './PaymentRequestController'
import PromoCodeController from './PromoCodeController'
import BranchSmsConfigController from './BranchSmsConfigController'
import PosController from './PosController'
import StockAdjustmentController from './StockAdjustmentController'
import BranchController from './BranchController'
import RolePermissionController from './RolePermissionController'
import BusinessIntelligenceController from './BusinessIntelligenceController'
import SmartReorderController from './SmartReorderController'
import FinancialAnalyticsController from './FinancialAnalyticsController'
import ProductionEfficiencyController from './ProductionEfficiencyController'
import HumanResourceController from './HumanResourceController'
import StaffPerformanceController from './StaffPerformanceController'
import CustomerIntelligenceController from './CustomerIntelligenceController'
import Admin from './Admin'
import HeroSlideController from './HeroSlideController'
import PopupAdController from './PopupAdController'
import NotificationController from './NotificationController'

const Controllers = {
    PageController: Object.assign(PageController, PageController),
    ProfileController: Object.assign(ProfileController, ProfileController),
    HomeController: Object.assign(HomeController, HomeController),
    CartController: Object.assign(CartController, CartController),
    management: Object.assign(management, management),
    Account: Object.assign(Account, Account),
    ReviewController: Object.assign(ReviewController, ReviewController),
    DashboardController: Object.assign(DashboardController, DashboardController),
    RequisitionController: Object.assign(RequisitionController, RequisitionController),
    FeedbackController: Object.assign(FeedbackController, FeedbackController),
    ProductController: Object.assign(ProductController, ProductController),
    CustomerController: Object.assign(CustomerController, CustomerController),
    SupplierController: Object.assign(SupplierController, SupplierController),
    LoanController: Object.assign(LoanController, LoanController),
    PaymentController: Object.assign(PaymentController, PaymentController),
    ExpensesController: Object.assign(ExpensesController, ExpensesController),
    ProductionOrderController: Object.assign(ProductionOrderController, ProductionOrderController),
    BomController: Object.assign(BomController, BomController),
    CustomerOrderController: Object.assign(CustomerOrderController, CustomerOrderController),
    ContainerController: Object.assign(ContainerController, ContainerController),
    UserController: Object.assign(UserController, UserController),
    ProductionController: Object.assign(ProductionController, ProductionController),
    RollProductionController: Object.assign(RollProductionController, RollProductionController),
    ProductionBenchmarkController: Object.assign(ProductionBenchmarkController, ProductionBenchmarkController),
    UpcomingOrderController: Object.assign(UpcomingOrderController, UpcomingOrderController),
    UpcomingProductController: Object.assign(UpcomingProductController, UpcomingProductController),
    ExportController: Object.assign(ExportController, ExportController),
    TransferController: Object.assign(TransferController, TransferController),
    RegisterProductController: Object.assign(RegisterProductController, RegisterProductController),
    ParkingOrderController: Object.assign(ParkingOrderController, ParkingOrderController),
    DeliveryController: Object.assign(DeliveryController, DeliveryController),
    DeliveryPersonController: Object.assign(DeliveryPersonController, DeliveryPersonController),
    DeliveryTrackingController: Object.assign(DeliveryTrackingController, DeliveryTrackingController),
    GatekeeperController: Object.assign(GatekeeperController, GatekeeperController),
    InventoryController: Object.assign(InventoryController, InventoryController),
    SecurityController: Object.assign(SecurityController, SecurityController),
    ReportController: Object.assign(ReportController, ReportController),
    SystemSettingController: Object.assign(SystemSettingController, SystemSettingController),
    SalesTargetController: Object.assign(SalesTargetController, SalesTargetController),
    PaymentRequestController: Object.assign(PaymentRequestController, PaymentRequestController),
    PromoCodeController: Object.assign(PromoCodeController, PromoCodeController),
    BranchSmsConfigController: Object.assign(BranchSmsConfigController, BranchSmsConfigController),
    PosController: Object.assign(PosController, PosController),
    StockAdjustmentController: Object.assign(StockAdjustmentController, StockAdjustmentController),
    BranchController: Object.assign(BranchController, BranchController),
    RolePermissionController: Object.assign(RolePermissionController, RolePermissionController),
    BusinessIntelligenceController: Object.assign(BusinessIntelligenceController, BusinessIntelligenceController),
    SmartReorderController: Object.assign(SmartReorderController, SmartReorderController),
    FinancialAnalyticsController: Object.assign(FinancialAnalyticsController, FinancialAnalyticsController),
    ProductionEfficiencyController: Object.assign(ProductionEfficiencyController, ProductionEfficiencyController),
    HumanResourceController: Object.assign(HumanResourceController, HumanResourceController),
    StaffPerformanceController: Object.assign(StaffPerformanceController, StaffPerformanceController),
    CustomerIntelligenceController: Object.assign(CustomerIntelligenceController, CustomerIntelligenceController),
    Admin: Object.assign(Admin, Admin),
    HeroSlideController: Object.assign(HeroSlideController, HeroSlideController),
    PopupAdController: Object.assign(PopupAdController, PopupAdController),
    NotificationController: Object.assign(NotificationController, NotificationController),
}

export default Controllers