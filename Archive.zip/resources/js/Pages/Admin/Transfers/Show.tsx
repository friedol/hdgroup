import { Head } from "@inertiajs/react";
import { ArrowRightLeft, Store as StoreIcon, User as UserIcon, Calendar, Package } from "lucide-react";
import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import AppLayout from "@/layouts/app-layout";

interface TransferItem {
  id: number;
  unique_id: string;
  product_id: number;
  product_name: string;
  product_quantity: number;
  unit_factor?: number;
  base_unit?: string;
  source_store: string;
  store_name: string;
  staff_name: string;
  staff_recommeded: string;
  reason: string;
  created_at: string;
}

interface Props {
  transfers: TransferItem[];
}

export default function TransfersShow({ transfers }: Props) {
  const firstTransfer = transfers[0];

  const breadcrumbs = [
    { title: "Dashboard", href: "/dashboard" },
    { title: "Transfers", href: "/transfers" },
    { title: firstTransfer ? firstTransfer.unique_id : "Transfer Detail", href: "#" },
  ];

  if (!firstTransfer) {
    return (
      <AppLayout breadcrumbs={breadcrumbs}>
        <div className="p-12 text-center text-slate-500 font-['Nunito_Sans']">Transfer record not found.</div>
      </AppLayout>
    );
  }

  return (
    <AppLayout breadcrumbs={breadcrumbs}>
      <Head title={`Transfer ${firstTransfer.unique_id}`} />

      <div className="space-y-8 animate-in fade-in duration-500 font-['Nunito_Sans']">
        <div className="flex justify-between items-center bg-white p-6 rounded-lg border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-md bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
              <ArrowRightLeft className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-slate-900">{firstTransfer.unique_id}</h1>
              <p className="text-xs text-slate-500">Initiated on {new Date(firstTransfer.created_at).toLocaleString()}</p>
            </div>
          </div>
          <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200 text-xs font-medium px-3 py-1">
            Completed
          </Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-slate-200 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Source Warehouse</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <StoreIcon className="h-4 w-4 text-slate-400" />
                <p className="text-base font-semibold text-slate-900 capitalize">{firstTransfer.source_store}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Destination Warehouse</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <StoreIcon className="h-4 w-4 text-emerald-600" />
                <p className="text-base font-semibold text-slate-900 capitalize">{firstTransfer.store_name}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Staff Verification</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <UserIcon className="h-4 w-4 text-slate-400" />
                <div>
                  <p className="text-sm font-semibold text-slate-900 capitalize">Rec: {firstTransfer.staff_recommeded}</p>
                  <p className="text-xs text-slate-500 capitalize">Operator: {firstTransfer.staff_name}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-100">
            <h2 className="text-sm font-semibold text-slate-900 capitalize">Transferred Items Breakdown</h2>
          </div>
          <Table>
            <TableHeader className="bg-slate-50/75">
              <TableRow className="hover:bg-transparent border-slate-100">
                <TableHead className="text-xs font-medium text-slate-500 py-3 pl-6">Product Item</TableHead>
                <TableHead className="text-xs font-medium text-slate-500 py-3 text-center">Quantity (Base Unit)</TableHead>
                <TableHead className="text-xs font-medium text-slate-500 py-3 text-center">Raw Pieces</TableHead>
                <TableHead className="text-xs font-medium text-slate-500 py-3">Reason</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transfers.map((item) => {
                const factor = item.unit_factor ?? 1;
                const unit   = item.base_unit || 'pcs';
                const rawPcs = Math.round(item.product_quantity * factor);
                return (
                <TableRow key={item.id} className="hover:bg-slate-50/50 transition-colors border-slate-100">
                  <TableCell className="pl-6 py-4">
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-slate-400" />
                      <span className="text-xs font-semibold text-slate-900 capitalize">{item.product_name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200 text-xs font-semibold px-2">
                      {item.product_quantity} {unit}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className="text-[11px] font-medium text-slate-500">
                      {factor > 1 ? `${rawPcs.toLocaleString()} pcs` : '—'}
                    </span>
                  </TableCell>
                  <TableCell className="text-xs text-slate-600 italic">
                    {item.reason}
                  </TableCell>
                </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>
    </AppLayout>
  );
}
